# DC-2 Helena Data Centre, Building A - Roof Deck Design Basis

Project DC2-2026-014. Roof deck: NORDECK B-36, 1-1/2 in wide-rib (Type B), 36 in cover, spanning 6 ft-0 in across 26K9 joists in 3-span continuous lengths. All coordinates are project grid feet from grid 1-A (x along grids 1 to 9, y along grids A to G).

## 1 Governing documents and how conflicts were resolved

* **Register of current revisions - Transmittal T-118.** Only the revisions listed there were used: EOR-DC-RD-01 Rev 2, LAT-2026-003 Rev 1, SNOW-2026-014 Rev 0, S-101 Rev 3, S-501 Rev 2, A-201 Rev C, M-401 Rev C, the DC2-A-STR roof structure model Rev C and cost plan CP-RD-2026 Rev 0.
* **Geometry of record - IFC model Rev C** (millimetres, converted at 304.8 mm/ft; origin at grid 1-A). Where the model and the 2-D drawings differ the model governs (model note 5, T-118 note 3.1). The current drawings S-101 Rev 3, A-201 Rev C and M-401 Rev C agree with the model for the openings, the enclosure, the screen walls and the rooftop units. **A-201 Rev B (archive) is superseded**: it shows SCR-N at y = 158 ft and SCR-E at y = 18-138 ft; the current position (model and A-201 Rev C) is SCR-N at y = 163.67-164.33 ft (x = 18-222 ft) and SCR-E at x = 215.67-216.33 ft (y = 24-144 ft). Drifts and zoning use the current position only (T-118 note 3.2). The screen wall thickness is taken from the model (8 in), not the 0.5 ft of the equipment schedule.
* **EOR-DC-RD-01 Rev 1 (archive) is withdrawn in its entirety** (T-118 note 3.3). In particular its reduced deck live load (Lr = 12 psf) and its effective seismic weight without snow were not used. Rev 2 governs: Lr = 20 psf unreduced on the deck (clause 4.2: tributary area 3 ft x 6 ft = 18 sq ft < 200 sq ft) and W includes 20 % of pf (clause 7.2).
* **UFC 3-301-01** overlays the adopted IBC (criteria 1.2/1.3): roof live load from UFC Table E-1 item 51 (20 psf), snow buildup at rooftop obstructions (para. 3-4.1), the case-study ground snow on a Risk Category II basis (1608.2.3).
* **Ground snow - SNOW-2026-014** (accepted by the AHJ) is the only source of pg = 63 psf. It is a Risk Category II value; the Risk Category III importance factor Is = 1.10 is applied once in pf (criteria 2.2). The Canyon Ferry station series is a supporting record only (study 4.1) and was not used as pg. The mapped USGS files were not used for snow; the 2019 preliminary ASCE 7-16 / RC II / Site Class C seismic file is not the project basis - the criteria 7.1 values (SDS = 0.44, SD1 = 0.24, Site Class D, SDC D), which match the ASCE 7-22 RC III Site D record, govern.
* **Owner's basis of design** fixes Risk Category III for every case and the 9-week release-to-site allowance. The supplier stock list gives 16 gage a 14-week mill lead time, so **16 gage is not available**; 22, 20 and 18 gage (2-4 weeks ex stock) are.
* **Non-governing / not applicable:** the 2019 Butte Hall A deck design (different building, discontinued product), the DC-1 Building B rows of the equipment schedule, and 29 CFR 1910 Subpart D (general industry). Temporary covers at openings follow 29 CFR 1926.754(e)(3) as required by criteria 10.5; no deck is left over an opening.
* **Deck end bearing:** S-501 detail 1 and criteria 10.6 require 1-1/2 in bearing at each panel end, while the joist top chord is 2.5 in wide and is shared by the two sheets at an end lap (joist schedule note N2). Deck end laps are therefore to be lapped (not butted) over the joist so each sheet bears the full chord width, or the condition reported to the EOR per note N1 before the deck is laid. The end reaction check below uses the catalogue allowable end reaction at 1.5 in bearing.

## 2 Gravity and snow basis (ASD, criteria 8.1)

* Dead load D = 10.5 psf collateral (4.5 roofing + 6.0 suspended MEP) + deck self weight (22 ga 1.6, 18 ga 2.5 psf). Roof live load Lr = 20 psf (not combined with snow).
* pf = 0.7 Ce Ct Is pg = 0.7 x 0.90 x 1.0 x 1.10 x 63 = **43.66 psf**; gamma = 0.13 x 63 + 14 = **22.19 pcf**; hb = 1.968 ft.
* Drifts per criteria 5.4 exactly as written: hd = 0.43 lu^(1/3) (pg + 10)^(1/4) - 1.5 (lu >= 20 ft); windward 0.75 hd with lu = fetch from the upwind roof edge; leeward hd with lu = along-wind length of the obstruction; triangular surcharge, truncated at hc = h - hb with w = min(4 hd^2/hc, 8 hc); four wind directions enveloped (not added); parapets by the windward rule with lu = roof dimension. All obstructions have hc > 2.0 ft (clause 5.5). Scenario grouping: S02 enclosure MEP-PH-1, S03 parapets, S04 rooftop units RTU-1 to RTU-12 and screen walls SCR-N and SCR-E.
* Each 6 ft x 6 ft cell carries the peak surcharge occurring anywhere inside it (clause 5.4.7); where drifts from different obstructions overlap in the same wind direction the larger governs.
* Reported drifts (Drifts sheet):

| location | face | case | lu (ft) | hd used (ft) | hc (ft) | peak (psf) | band (ft) |
|---|---|---|---|---|---|---|---|
| MEP-PH-1 | W | leeward | 120.0 | 4.700 | 10.032 | 104.28 | 60.00 to 41.20 |
| SCR-N | S | windward | 163.7 | 4.031 | 4.032 | 89.46 | 163.67 to 147.54 |
| PARAPET | N | windward | 180.0 | 4.198 | 1.532 | 34.01 | 179.33 to 167.07 |
| RTU-1 | E | windward | 204.0 | 4.424 | 5.032 | 98.17 | 36.00 to 53.70 |

* Deck capacities from the catalogue basis (clause 3.1, 6 ft span): allowable total load 1000 Fb Sn/(L^2 x 1.2) = 106.4 psf (22 ga), 130.3 psf (20 ga), 176.9 psf (18 ga); deflection 0.0069 w L^4/(E I) <= L/240 = 0.30 in under S or Lr, i.e. S <= 96.8 / 119.1 / 163.2 psf. End reaction 1.1 w L at interior supports and 0.4 w L at ends are well below Table 4-1 (1,180 / 2,310 lb/ft).
* Construction stage (clause 9.1): the bare 22 gage deck under a 20 psf uniform erection load plus self weight deflects 0.0069 x 21.6/12 x 72^4 / (29,500 x 0.169) = 0.07 in, far below the 0.75 in limit; 18 gage is stiffer.
* Peak surcharges reach 104.3 psf (MEP-PH-1 leeward faces, SCR-E end faces): those cells need 18 gage (S = 147.9 psf, D + S = 160.9 psf < 176.9 psf; deflection 0.27 in). 20 gage carries drift surcharge up to 73.9 psf and 22 gage up to 50.2 psf (strength governs, using the lower of the basis value and the printed table value).

## 3 Wind uplift (LRFD 0.9D + 1.0W, criteria 6.2)

* qh = 0.00256 x 1.04 x 1.0 x 0.85 x 1.0 x 115^2 = **29.93 psf**; a = min(0.1 x 180, 0.4 x 32) = **12.8 ft**. Net uplift: zone 3 101.2, zone 2 74.2, zone 1 47.3, zone 1-prime 32.3 psf. A cell takes the most severe pressure zone it overlaps (cells within 18 ft of an edge are zone 2, corner 18 ft squares zone 3, cells within 30 ft zone 1).
* Capacity = 0.9 x (deck + 4.5 psf roofing) + 0.50 x Pnov x n / (3 ft x 6 ft). The corner zone 3 requires 18 gage 36/9 (126.0 psf); 22 gage 36/9 gives 80.0 psf for zone 2; 22 gage 36/4 gives 38.6 psf for the interior.

## 4 Seismic basis

* SDS = 0.44, Ie = 1.25, R = 3.25 (OCBF), Omega_0 = 2.0, rho = 1.0. Because pf = 43.66 psf > 30 psf, clause 7.2 adds 20 % of pf: W = 18.0 + 0.2 x 43.66 = **26.73 psf** over 240 ft x 180 ft = 1154.8 kip. Cs = 0.44 x 1.25 / 3.25 = 0.1692 (between 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220), so **Fpx = 195.4 kip** (single storey: Fpx = V).
* Accidental torsion 0.05 x 180 = 9 ft (force along x) and 0.05 x 240 = 12 ft (along y), applied as a plan couple in both senses; collectors in S10 amplified by Omega_0 = 2.0 (unamplified for the diaphragm and chords).
* Wind: 118.0 kip along x and 152.0 kip along y (LAT Table 4-1), half on each wall line perpendicular to the force as a line load; Case 2 (75 % with 0.15 x plan dimension eccentricity) enveloped in S05/S06.

## 5 Diaphragm analysis and classification

* In-plane model per criteria 9.3 and LAT 6.3/7.1: nodes at every joist line (6 ft) and girder line (30 ft); shear panels 6 ft x 30 ft with constant shear flow, the panel G' being the series (harmonic) combination of the five 6 ft deck strips across its depth, each with the catalogue G' of its zone; axial bars on every joist line (EA = 87,580 kip) and girder line (221,850 kip) with the L5x3-1/2x5/16 edge member (74,240 kip) added on the four boundary lines; each braced frame as two springs of k/2 at its column lines. A panel containing any opening cell carries no shear (framed openings modelled as holes). A 1e-4 kip/in regularising spring on every DOF carries < 0.1 % of the load in every case, so a complete load path exists.
* Seismic load by tributary area over the plan; wind as wall line loads. Shear demand in each cell = envelope of the panel shear flow over all sub-cases (+/- eccentricity, case 1 and case 2 wind). Chord force = largest axial force on the perimeter chord lines parallel to the span; collector force = largest axial force on a perimeter line member within one bay of a braced frame of that direction (combined girder + edge line, conservatively).
* Deflection = largest nodal displacement relative to the braced-frame (support) displacements, checked three ways (relative to the average frame drift, to a rigid-body fit through the frame points, and to the line between the two frame lines) and the largest reported.

| scenario | dir | max shear (plf) | max deflection (in) | chord (kip) | collector (kip) | average frame drift (in) | class |
|---|---|---|---|---|---|---|---|
| S05 | X | 326 | 0.513 | 9.9 | 14.0 | 0.65 | semi-rigid |
| S06 | Y | 682 | 1.056 | 23.4 | 17.0 | 0.71 | semi-rigid |
| S07 | X | 536 | 0.869 | 16.7 | 28.0 | 1.54 | semi-rigid |
| S08 | Y | 946 | 1.411 | 30.7 | 22.5 | 1.33 | semi-rigid |
| S10 | X | 536 | 0.869 | 16.7 | 55.9 | 1.54 | semi-rigid |

* Limits: deflection 1.60 in (criteria 9.2); chord splice 38.0 kip; collector splice 58.0 kip with S10 amplified by 2.0 (LAT 6.2.1, criteria 7.4). In every scenario the maximum diaphragm deflection is less than 2.0 x the average drift of the braced frames, so the diaphragm is **semi-rigid** (computed, criteria 9.3) and was analysed with its finite stiffness. Frame drifts are far below 0.015 x 32 ft = 5.76 in.
* Stiffness was used deliberately: the deck near the BF-X1/BF-X2 bays and west/east ends is kept stiff and the deck between the south-wall frames softer, which keeps the amplified BF-X1/BF-X2 collector force below the 58 kip splice while the y-direction deflection stays below 1.60 in.

## 6 Zoning decisions

Constructability (criteria 10.2): 3 zones, 14 rectangles, 2 gages, 2 attachment patterns; boundaries on 6 ft joist and sidelap lines; no deck over the three framed openings (cells touched by RO-1, RO-2, RO-3 are excluded). Every zone that touches the roof perimeter or an opening edge carries at least 36/7 with 3 sidelap connectors per span (criteria 10.4); sidelap connectors are at <= 36 in centres (ns >= 2 on the 6 ft span); button punch, where used, only on 20 or 22 gage (catalogue 6.4).

| zone | gage | support | sidelap | area (sf) | rectangles | governing | driver |
|---|---|---|---|---|---|---|---|
| Z1 | 22 | 36/9 | SCREW-10 x 4 | 9036 | 4 | S09 | carries drift surcharge up to 34 psf; uplift perimeter zone 2 (74.2 psf); touches perimeter and openings: min 36/7 with 3 sidelaps; diaphragm shear (D/C 0.82) |
| Z2 | 18 | 36/9 | SCREW-10 x 4 | 7776 | 3 | S04 | drift surcharge up to 104 psf needs 18 ga; uplift corner zone 3 (101.2 psf); touches perimeter and openings: min 36/7 with 3 sidelaps; diaphragm shear (D/C 0.91) |
| Z3 | 18 | 36/7 | SCREW-10 x 3 | 25380 | 7 | S02 | drift surcharge up to 104 psf needs 18 ga; uplift perimeter zone 2 (74.2 psf); touches opening edge: min 36/7 with 3 sidelaps; diaphragm shear (D/C 0.82) |

Rectangles (x0, y0, x1, y1 in ft):

* Z1: (36, 0, 210, 18); (96, 18, 108, 48); (0, 42, 36, 132); (18, 168, 210, 180)
* Z2: (0, 0, 36, 42); (210, 0, 240, 180); (0, 132, 18, 180)
* Z3: (36, 18, 96, 132); (108, 18, 210, 60); (96, 60, 132, 132); (132, 60, 144, 120); (144, 60, 180, 132); (180, 84, 210, 132); (18, 132, 210, 168)

Per-zone demand / capacity (CalcSummary): 

| zone | shear demand / capacity (plf) | gravity D+S demand / allowable (psf) | uplift demand / capacity (psf) |
|---|---|---|---|
| Z1 | 566 / 694 | 89.8 / 106.4 | 74.2 / 80.0 |
| Z2 | 946 / 1040 | 160.9 / 176.9 | 101.2 / 126.0 |
| Z3 | 609 / 743 | 160.9 / 176.9 | 74.2 / 99.4 |

## 7 Compliance summary

| check | requirement | result |
|---|---|---|
| gravity strength and deflection (S01-S04) | D + S <= allowable total load; S or Lr deflection <= L/240 | max ratio 0.910 |
| end reaction / bearing | 1.1 w L <= Table 4-1 at 1.5 in bearing | Z1 592 <= 1180 lb/ft; Z2 1062 <= 2310 lb/ft; Z3 1062 <= 2310 lb/ft |
| diaphragm shear (S05-S08, S10) | panel shear <= 0.70 Sn | max ratio 0.910 |
| in-plane deflection | <= 1.60 in | max 1.411 in |
| chord force | <= 38.0 kip | max 30.7 kip |
| collector force | <= 58.0 kip (S10 amplified x 2.0) | S10 55.9 kip; unamplified max 28.0 kip |
| load path | regularising springs < 2 % of load | max 0.04 % |
| uplift (S09) | net uplift <= 0.9D + 0.5 Pnov n / 18 sf | max ratio 0.928 |
| attachment rules | >= 36/7 and 3 sidelaps at perimeter / openings; sidelaps <= 36 in; BP only <= 20 ga | satisfied |
| zoning rules | <= 2 gages, 3 patterns, 12 zones, 14 rectangles; 6 ft grid; no deck over openings | 2 / 2 / 3 / 14 |
| procurement | gages deliverable within 9 weeks | 18 and 22 gage (2-4 weeks) |

## 8 Interpretations adopted and robustness checks

* A cell is affected by a drift band or a framed opening when they overlap with positive area; a cell that only shares an edge with an obstruction face (e.g. the cells inside the enclosure walls) does not carry the exterior drift. The zoning was also checked with edge contact counted (closed intervals) and still passes.
* Where drift bands of different obstructions overlap in the same wind direction, the larger surcharge governs at the point (the four wind directions are never added, clause 5.4.5). Adding coincident bands would demand more than 18 gage at the north end of SCR-E and 16 gage is not available.
* Gravity strength uses the lower of the catalogue basis value and the printed Table 3-1 value; deflection is checked under the snow or live load as clause 9.1 states and was also checked under the total load D + S.
* Uplift capacity includes 0.9 x (deck + roofing) as clause 6.2.3 states; the suspended MEP allowance is excluded.
* Chord and collector forces are taken as the total axial force of the perimeter line (framing member plus edge angle), which is conservative against the 38.0 / 58.0 kip splice capacities. The y-direction collectors were also checked with the overstrength factor (2.0 x S08 collector force < 58 kip).
* Margins kept against independent re-analysis: shear demand/capacity <= 0.95, diaphragm deflection <= 1.50 in, amplified collector <= 56 kip, chord <= 36 kip.

## 9 Quantities and installed cost (CP-RD-2026)

* Deck material $174109; support fasteners $24673; sidelap connectors $9161; set-up (zones, rectangles, gages, patterns) $18740; **installed cost $226683**.
* Fastener count = area / (3 ft x 6 ft) x n; sidelap count = area / 18 sf x ns, per cost plan notes 3 and 4. Areas are net of the opening cells.
