# Method of Procedure - PCW Cleaning, Flushing and Passivation, Tull Creek Data Hall

Flushing contractor turnover package per Section 23 25 16 (Rev 3). Companion files: flush_plan.csv, chemistry_plan.csv, acceptance_matrix.csv, schedule.csv, resources.json, constraint_register.csv. All times are hours from mobilisation (TM-0 = hour 0, CX-01 Rev B).

## 1. Scope and governing documents

- Section 23 25 16 Rev 3 (this scope), 23 21 16 Rev 3 (materials, roughness, hydrostatic test), 01 91 13 Rev 2 (evidence, crews, utilities).
- UFC 3-230-13 (1 March 2023) is the governing water-treatment criteria document. Its closed-system provisions (Ch. 6) apply; the open cooling-tower provisions are used only where 23 25 16 invokes them: para 5-3.7 (suspension velocity, dispersant), para 5-7.3.2.2 (24 h circulation, 30 min recirculation, rinse criterion) and para 5-7.3.2.4 with Tables 5-14/5-15 (passivation).
- DOE-HDBK-1012/3-92 for all hydraulics (continuity, Reynolds number, Darcy equation with equivalent length, pumps in parallel); 40 CFR 403 for the POTW discharge; 29 CFR 1910.1200 for hazard communication.
- Drawings and schedules at their current revisions: M-PID-101..104 Rev C, M-ISO-201..204 Rev C, M-601/602/603 Rev C, E-701 Rev B, C-101 Rev B, SW-04 Rev B, CX-01 Rev B, VD-06 Rev B, SW-03 Rev B.

### Documents read and rejected (not used as authority)

- UFC 3-240-13FN (2005): cancelled; superseded by UFC 3-230-13 (stated in 23 25 16 cl.1.2 and on the UFC 3-230-13 cover). Its passivation tables are numerically the same but it is not cited anywhere.
- M-PID-103 Rev A: superseded by Rev C (title block and M-601 Note 5). Rev A showed line 4033 (x2) in the north circuit C4; Rev C (and M-601: 4033 has 3 legs) places 4033 x3 in C5. Rev C used.
- SW-03 original issue (Revision A): its programme total of 540,000 gal is superseded by Revision B (500,000 gal). Revision B cl.3 keeps the Rev A local limits and general conditions in force, so those limits are cited through Revision B.
- RFI-031 repeats the 540,000 gal cap: overtaken by SW-03 Rev B (issued 2026-07-21, after RFI-031 of 2026-07-06). RFI-031 is used only for the tanker rate ($168/kgal), MH-14 and the no-storm/no-creek instruction.
- 40 CFR 122 (NPDES): not adopted - the discharge is to the POTW under an industrial discharge authorization, not an NPDES permit (SW-03 general condition 2).
- Section 22 11 23 (domestic water pumps), VD-08 (comfort-cooling chiller) and RFI-009 (roofing): outside the PCW scope by their own text.
- VD-06 line NB-700 (nitrite-borax-azole) and MO-500 (molybdate): not used - see 3.4.

## 2. Circuits (read from the P&IDs)

| Circuit | Lines (legs) | Components | Tie-in / panel | Static lift ft | V_flush gal | V_system gal | Metallurgy |
|---|---|---|---|---|---|---|---|
| C1 | 1041, 1042, 1043 x4, 1044 x4 | PMP-101 (in path), BT-101 (in path) | MER-1 / 150 kW | 26 | 32,983.4 | 32,983.4 | carbon steel |
| C2 | 2011, 2012, 2013 x3 | HX-201A (bypass) | MER-1 / 150 kW | 22 | 5,596.0 | 7,946.0 | CS + stainless/nitrile PHE |
| C3 | 2021, 2022, 2023 x2 | HX-201B (bypass) | MER-2 / 95 kW | 22 | 6,203.2 | 8,553.2 | CS + stainless/nitrile PHE |
| C4 | 4021, 4022, 4023 x2, 4024 x4 | CDU-301 (bypass), CP-311 (bypass) | L3-N / 90 kW | 48 | 5,956.6 | 8,536.6 | CS + copper + SS CDU |
| C5 | 4031, 4032, 4033 x3, 4034 x4 | CDU-302 (bypass), CP-321 (bypass) | L3-S / 90 kW | 44 | 6,405.8 | 8,985.8 | CS + copper + SS CDU |
| C6 | 4041, 4042, 4043 x3 | CP-331 (bypass) | L3-W / 90 kW | 48 | 4,227.1 | 5,677.1 | CS + copper + aluminium cold plates |
| C7 | 5011, 5012, 5013 x4 | CL-401 (bypass) | ROOF / 45 kW | 72 | 4,086.0 | 6,036.0 | CS + copper (coil fins dry) |
| C8 | 6011, 6012, 6013 x2 | ST-601 (in path) | YARD / 120 kW | 14 | 5,790.8 | 5,790.8 | galvanized steel |

FLUSH volume = pipework + hold-up of components not bypassed; SYSTEM volume = pipework + all component hold-ups (23 25 16 cl.3.4, cl.3.6). Pipe volume = (pi/4) ID^2 x length per leg x legs x 7.4805 gal/ft3 (M-601 IDs, not re-derived).

## 3. Design basis

### 3.1 Flushing flow, governing segment and skid duty

Required velocity = max(3.28 ft/s, UFC 3-230-13 para 5-3.7; class minimum 4.0 ft/s for circuits serving a plate HX or cold-plate device, else 2.0 ft/s) in every leg of every line (23 25 16 cl.3.3). Velocity per leg v = (Q/legs)/A (cl.3.2 a). Friction factor by Colebrook-White (cl.3.2 b) with 23 21 16 cl.2.2 roughness; head loss with L + (sum L/D) D (cl.3.2 c). Required head (cl.3.2 d) = static lift (M-ISO) + single-leg main path at the circuit flow + components left in the path (dP_r (Q/Q_r)^2) + the skid's 300 ft lay-flat hose (VD-05, roughness 0.0008 ft, hose ID per skid) + its 40-mesh strainer (11 ft at 600 gpm scaled). One skid per circuit (no parallel operation needed); every duty point lies inside the published curve (cl.3.2 f), head interpolated linearly between tabulated points.

| Circuit | Q gpm | Governing segment (ID in.) | v ft/s | Re | Skid | Req. head ft (static / main / comp / hose / strainer) | Available ft | Head margin | kW / panel kW |
|---|---|---|---|---|---|---|---|---|---|
| C1 | 1182 | 1043 (6.065) | 3.282 | 153,572 | FS-1200-A | 88.31 (26 / 11.12 / 0.0 / 8.5 / 42.69) | 119.52 | 0.2611 | 75 / 150 |
| C2 | 624 | 2011 (7.981) | 4.002 | 246,440 | FS-1200-A | 48.82 (22 / 12.5 / 0 / 2.42 / 11.9) | 185.68 | 0.7371 | 75 / 150 |
| C3 | 721 | 2023 (6.065) | 4.003 | 187,352 | FS-1200-A | 56.71 (22 / 15.61 / 0 / 3.21 / 15.88) | 176.3 | 0.6783 | 75 / 95 |
| C4 | 361 | 4021 (6.065) | 4.009 | 187,612 | FS-600-B | 99.15 (48 / 18.27 / 0 / 28.9 / 3.98) | 154.05 | 0.3564 | 30 / 90 |
| C5 | 477 | 4033 (4.026) | 4.007 | 124,482 | FS-600-B | 130.17 (44 / 29.04 / 0 / 50.18 / 6.95) | 134.7 | 0.0336 | 30 / 90 |
| C6 | 361 | 4041 (6.065) | 4.009 | 187,612 | FS-600-B | 102.23 (48 / 21.35 / 0 / 28.9 / 3.98) | 154.05 | 0.3364 | 30 / 90 |
| C7 | 296 | 5011 (6.065) | 3.287 | 153,832 | FS-600-B | 107.28 (72 / 13.08 / 0 / 19.52 / 2.68) | 163.35 | 0.3433 | 30 / 45 |
| C8 | 152 | 6013 (3.068) | 3.298 | 78,081 | FS-600-B | 67.41 (14 / 37.8 / 9.63 / 5.27 / 0.71) | 175.83 | 0.6166 | 30 / 120 |

Notes: C1 needs the FS-1200 (two FS-600 in parallel give 124.5 ft required vs 108.2 ft available each; one FS-600 cannot reach 1,182 gpm). C3 (721 gpm) exceeds the FS-600 curve end (700 gpm). C7 can only take one FS-600: TP-ROOF has 45 kW (FS-1200 75 kW; two FS-600 60 kW). In C1 lines 1043 and 1044 give identical leg velocities (both 4 legs of 6 in.); 1043 recorded as the governing segment. In C8 the break tank ST-601 stays in the path: 9.63 ft at 152 gpm vs 25 ft allowable, 800 micron vs 380 micron strainer, 140 degF vs 68 degF water. PMP-101/BT-101 (C1) are full-bore items with zero drop (M-602 Note 5).

### 3.2 Hydrostatic tests

CX-02 lists all eight circuits as passed, but 01 91 13 cl.1.3 accepts a result only with its cited evidence on file. Charts on file: TR-0412 (C1), TR-0413 (C2), TR-0415 (C4), TR-0419 (C8). TR-0414 (C3), TR-0416 (C5), TR-0417 (C6) and TR-0418 (C7) are missing, so C3, C5, C6 and C7 are tested before chemical cleaning and by TM-1 (hour 144): 127.5 psig (1.5 x 85 psig, not less than 125 psig), 120 min, no pressure loss, no leakage (23 21 16 cl.3.3). 127.5 psig is below every rating in the circuits under test (lowest: HX-201B 230 psig; temporary hose/strainer 150 psig). C1, C2, C4 and C8 are not retested (retest = change of scope). Test water V_f is drawn and discharged per cl.3.9. The test pump is Contractor-furnished and unpriced (cl.3.10 f).

### 3.3 Chemical cleaning

- C6 (aluminium cold plates CP-331) and C8 (galvanized 6011-6013, ST-601; RFI-022) take CL-210 (neutral, pH 8.2) at 2.0 gal per 1,000 gal of system volume: UFC 10-1.1 bars pH > 8.5 procedures on galvanized steel and aluminium. All other circuits take CL-100 at 1.5 gal per 1,000 gal of system volume (VD-06). C7 is not an aluminium circuit: the CL-401 fins are air-side only, wetted path copper (VD-04 note 4).
- PD-45 polyacrylate carried with the cleaning charge at 4 ppm active on the system volume (UFC 5-3.7: 4 to 5 ppm).
- Circulation 24 occupied hours (UFC 5-7.3.2.2 b); bypass spools fitted on every component with a bypass provision for flush and clean (23 25 16 cl.3.4; VD-03 note 2; VD-04 note 2).

### 3.4 Treatment programme and passivation

- Makeup (SW-02): Cl 505 + SO4 355 = 860 mg/L > 800 mg/L, so nitrite-azole and nitrite-molybdate-azole are excluded (UFC 6-2.2.2, 6-2.2.4); NB-700 is not used. Sulfite-caustic is a hot-water programme (pH 9-10) and is not suitable with aluminium.
- Polysilicate-azole (UFC 6-2.2.5) is selected for all eight circuits: it is the programme the paragraph text recommends where aluminium is present (mandatory for C6 per VD-04 note 1), it suits steel, copper and galvanized steel (Table 5-10), natural silica 11 mg/L < 150 mg/L, it is cheaper than molybdate, and silica has no SW-03 local limit (molybdenum 0.5 mg/L would force hauling). Per 23 25 16 cl.3.5 the paragraph text governs and the selection table (Table 6-2, by system type) does not exclude it.
- Passivation per the tables UFC para 5-7.3.2.4 identifies for passivation (Tables 5-14/5-15, current edition): polysilicate 40 ppm as SiO2 (band 40-50), pH band 7.5-8.5; where copper is wetted (C4, C5, C6, C7) tolyltriazole 10 ppm (band 10-20), pH band 6.5-7.9, so those circuits are controlled at the intersection pH 7.5-7.9 (23 25 16 cl.3.8). Table 5-11 (10-12 days) is the cooling-tower maintenance/dosage table and is not used for the hold.
- Film-formation hold 14-21 days measured in occupied hours, unattended, skid released (see section 5 for each circuit).
- Maintenance (turnover): 80 ppm as SiO2 (UFC 6-2.2.5: 80-100), pH 7.5-8.9 (Cu circuits held 7.5-7.9; C6 also within VD-04 7.0-8.5), TTA >= 10 ppm where copper is present. All treatment doses referred to the SYSTEM volume (cl.3.5).
- Turnover method RETAIN_AND_TOP_UP for every circuit: maintenance residual (80 ppm SiO2, 10 ppm TTA) is not below the passivation residual (40 ppm, 10 ppm). The top-up adds the 40 ppm SiO2 increment and 0 ppm TTA on the system volume. Recirculate 30 min (UFC 5-7.3.2.2 d) and sample while circulating.

### 3.5 Rinse displacements

C_n = 615 + (C_0 - 615) exp(-eta n) <= 1.10 x 615 = 676.5 uS/cm (UFC 5-7.3.2.2 e: conductivity within +/-10 percent of makeup). eta = 0.45 where M-602 lists a cold-plate manifold bank or coil bank (C4 CP-311, C5 CP-321, C6 CP-331, C7 CL-401), 0.62 otherwise. Rinse pH acceptance 7.5-7.9 (intersection of 7.6 +/-0.3 and 7.5-8.5).

| Circuit | Cleaner (C_0) | eta | n required | n used | C_n uS/cm | margin (conductivity) | margin (displacements) |
|---|---|---|---|---|---|---|---|
| C1 | CL-100 (2600) | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 |
| C2 | CL-100 (2600) | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 |
| C3 | CL-100 (2600) | 0.62 | 5.604 | 6 | 663.1 | 0.0198 | 0.0707 |
| C4 | CL-100 (2600) | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 |
| C5 | CL-100 (2600) | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 |
| C6 | CL-210 (2150) | 0.45 | 7.149 | 8 | 656.9 | 0.0289 | 0.1190 |
| C7 | CL-100 (2600) | 0.45 | 7.721 | 8 | 669.2 | 0.0107 | 0.0362 |
| C8 | CL-210 (2150) | 0.62 | 5.189 | 6 | 652.2 | 0.0359 | 0.1563 |

### 3.6 Discharge routing and cascades

- Cascades (23 25 16 cl.3.6, cl.3.9): C3 -> C2 (5,596.0 gal, donor V_f 6,203.2 >= receiver); C4 -> C8 (5,790.8 gal, donor V_f 5,956.6 >= receiver); C6 -> C7 (4,086.0 gal, donor V_f 4,227.1 >= receiver); C8 -> C6 (4,227.1 gal, donor V_f 5,790.8 >= receiver); C5 -> C4 (5,956.6 gal, donor V_f 6,405.8 >= receiver); C1 -> C3 (6,203.2 gal, donor V_f 32,983.4 >= receiver). Each receiver takes exactly one cascaded displacement as the first displacement of its rinse, which starts after the donor rinse is complete; each donor donates once. The cascaded water is moved in a Contractor-furnished portable holding tank (unpriced, cl.3.10 f).
- Hauled (vacuum tanker from the yard pad, RFI-031/C-101): spent cleaning solution of C4, C5, C6, C7 (copper pipe in the flushed path: 3.4 mg/L Cu for CL-100, 1.6 mg/L for CL-210) and C8 (galvanized: 5.5 mg/L Zn for CL-210), each > 1.0 mg/L SW-03 local limit (23 25 16 cl.3.7), plus C8 INITIAL_FLUSH to keep the programme total under the SW-03 Rev B cap.
- Sewered at MH-14: all other flush, hydro, cleaning (C1-C3: no Cu/Zn, pH 8.4) and rinse effluent: total 496,899 gal against the 500,000 gal programme authorisation (SW-03 Rev B cl.2), margin 0.0062. Hauled total 32,257 gal.
- Every discharge event is sampled before release and logged with volume, pH and temperature (SW-03 general conditions 3-4). Effluent temperature is ambient (68 degF makeup) against 104 degF; pH: makeup 7.6, spent CL-100 8.4, spent CL-210 8.1, rinse effluent falling from the spent-solution pH to the makeup pH - all inside 6.0-9.0.
- No discharge to storm or Tull Creek (RFI-031). Passivation charge retained (RETAIN_AND_TOP_UP): no passivation or turnover effluent.

### 3.7 Water, power and fleet

- Daily draw limit 92,000 gal (62,000 metered + 30,000 trucked, SW-01 cl.2), reduced by SI-04 to 61,000 gal on days 2 and 3 and 30,000 gal on day 6. The plan draws at most 77,823 gal in a day and keeps every day at or below 95 percent of its limit. Total draw 613,665 gal: 574,967 metered, 38,698 trucked; programme average 7.0576 $/kgal applied to every circuit (cl.3.10 c).
- Power: one skid per location at a time; worst case FS-1200 at MER-2 (75 of 95 kW) and FS-600 at ROOF (30 of 45 kW). Units held: FS-600-B days [0, 1, 2, 3, 4, 5, 11, 25]; FS-1200-A days [7, 8, 9, 10, 11, 25]. Not held on any day: FS-600-A. FS-1200-A is not used before hour 48 (SI-05).
- Turnover top-ups (C2-C7, 13,260 gal in total) are drawn through the SV-2 softened outlet where SF-1 capacity allows (C-101: 88,000 grains between daily regenerations, about 5,200 gal of 288 mg/L water per day); SV-2 is metered construction water, so the accounting is unchanged (water_source MAKEUP).

## 4. Governing constraint and margins (23 25 16 cl.1.6)

Margins are (limit - achieved)/limit for upper limits and (achieved - limit)/limit for lower limits. Skid head: available head of the assigned skid at the declared flow vs the required head (worst pumped row). Rinse endpoint: conductivity form (676.5 uS/cm limit) and displacement form (n used vs n required); the tighter, conductivity, is used. Programme discharge volume: sewered total vs 500,000 gal. Daily water allocation: tightest day on which the circuit draws water, against that day's draw limit (92,000 gal; 61,000 on days 2-3; 30,000 on day 6). Temporary power: maximum simultaneous connected kW at the circuit's panel vs available kW.

| Circuit | Skid head | Rinse (conductivity) | Rinse (displacements) | Programme discharge | Daily water | Temporary power | Governing |
|---|---|---|---|---|---|---|---|
| C1 | 0.2611 | 0.0198 | 0.0707 | 0.0062 | 0.1541 | 0.5000 | programme discharge volume |
| C2 | 0.7371 | 0.0198 | 0.0707 | 0.0062 | 0.1541 | 0.5000 | programme discharge volume |
| C3 | 0.6783 | 0.0198 | 0.0707 | 0.0062 | 0.1541 | 0.2105 | programme discharge volume |
| C4 | 0.3564 | 0.0107 | 0.0362 | 0.0062 | 0.3820 | 0.6667 | programme discharge volume |
| C5 | 0.0336 | 0.0107 | 0.0362 | 0.0062 | 0.3820 | 0.6667 | programme discharge volume |
| C6 | 0.3364 | 0.0289 | 0.1190 | 0.0062 | 0.3320 | 0.6667 | programme discharge volume |
| C7 | 0.3433 | 0.0107 | 0.0362 | 0.0062 | 0.3320 | 0.3333 | programme discharge volume |
| C8 | 0.6166 | 0.0359 | 0.1563 | 0.0062 | 0.4460 | 0.7500 | programme discharge volume |

GOVERNING CONSTRAINT C1: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C2: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C3: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C4: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C5: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C6: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C7: programme discharge volume (margin 0.00620)

GOVERNING CONSTRAINT C8: programme discharge volume (margin 0.00620)

The programme discharge volume binds every circuit because the 500,000 gal authorisation of SW-03 Rev B is shared by the whole programme and the cheapest compliant plan sewers close to it; the next-tightest constraint is the rinse endpoint (conductivity), 0.0107 for C4, C5 and C7. The rinse margins are fixed by the whole-number displacement rule; the head margin of C5 (FS-600 at 477 gpm) is the tightest hydraulic margin.

## 5. Execution narrative

Mobilisation (hour 0): skid pads per C-101; SDS, labels and training complete (section 8); chemical deliveries per resources.json chemical_orders (each ordered not later than first use minus VD-06 lead time). Crews: CREW-1 deployed (never more than two crews at once, 01 91 13 cl.1.7; SW-01 cl.3). Fleet use by stage is listed in flush_plan.csv and resources.json skid_assignment: FS-1200-A for C1, C2 and C3 (flows 1,182/624/721 gpm), an FS-600 for C4-C8; one unit per circuit at a time.

Per circuit sequence: [hydro] -> connect skid at the tie-in valves, fit bypass spools and the 40-mesh strainer -> one FLUSH-volume displacement -> make up cleaning charge (cleaner + PD-45), circulate 24 h -> drain to the declared route, clean strainer -> n rinse displacements at the flushing flow (cascaded first displacement where declared; circuit left full) -> sample (30 min circulation) against the RINSE gate -> dose passivation charge (PS-330, + TA-90 where copper) into the standing water, circulate V_f + 30 min, sample (PASSIVATION gate) -> isolate, release skid, unattended hold 14-21 days -> top-up to system volume with the maintenance increment, open component isolation valves, recirculate 30 min, sample (TURNOVER gate) -> remove bypass spools, fit fine filtration where required, remove temporary strainers (TM-4, VD-05) and hand over.

| Activity | Circuit | Stage | Start h | Finish h | Skid | Crew | Draw gal |
|---|---|---|---|---|---|---|---|
| C7-HYDRO | C7 | HYDRO | 0.0 | 2.0 | NONE | CREW-1 | 4,086 |
| C4-FLUSH | C4 | INITIAL_FLUSH | 2.0 | 2.275 | FS-600-B | CREW-1 | 5,957 |
| C5-HYDRO | C5 | HYDRO | 2.275 | 4.275 | NONE | CREW-1 | 6,406 |
| C5-FLUSH | C5 | INITIAL_FLUSH | 4.275 | 4.499 | FS-600-B | CREW-1 | 6,406 |
| C8-FLUSH | C8 | INITIAL_FLUSH | 4.499 | 5.134 | FS-600-B | CREW-1 | 5,791 |
| C7-FLUSH | C7 | INITIAL_FLUSH | 5.134 | 5.364 | FS-600-B | CREW-1 | 4,086 |
| C5-CLEAN | C5 | CHEM_CLEAN | 5.364 | 29.364 | FS-600-B | CREW-1 | 6,406 |
| C5-RINSE1 | C5 | DRAIN_RINSE | 29.364 | 29.588 | FS-600-B | CREW-1 | 6,406 |
| C5-RINSE2 | C5 | DRAIN_RINSE | 29.588 | 31.154 | FS-600-B | CREW-1 | 44,841 |
| C4-CLEAN | C4 | CHEM_CLEAN | 31.154 | 55.154 | FS-600-B | CREW-1 | 5,957 |
| C4-RINSE1 | C4 | DRAIN_RINSE | 55.154 | 55.979 | FS-600-B | CREW-1 | 11,913 |
| C7-CLEAN | C7 | CHEM_CLEAN | 55.979 | 79.979 | FS-600-B | CREW-1 | 4,086 |
| C4-RINSE2 | C4 | DRAIN_RINSE | 79.979 | 80.804 | FS-600-B | CREW-1 | 17,870 |
| C6-HYDRO | C6 | HYDRO | 80.804 | 82.804 | NONE | CREW-1 | 4,227 |
| C6-FLUSH | C6 | INITIAL_FLUSH | 84.0 | 84.195 | FS-600-B | CREW-1 | 4,227 |
| C8-CLEAN | C8 | CHEM_CLEAN | 84.195 | 108.195 | FS-600-B | CREW-1 | 5,791 |
| C4-RINSE3 | C4 | DRAIN_RINSE | 108.195 | 108.745 | FS-600-B | CREW-1 | 11,913 |
| C3-HYDRO | C3 | HYDRO | 108.745 | 110.745 | NONE | CREW-1 | 6,203 |
| C8-RINSE1 | C8 | DRAIN_RINSE | 110.745 | 114.555 | FS-600-B | CREW-1 | 28,954 |
| C6-CLEAN | C6 | CHEM_CLEAN | 114.555 | 138.555 | FS-600-B | CREW-1 | 4,227 |
| C6-RINSE1 | C6 | DRAIN_RINSE | 138.555 | 139.14 | FS-600-B | CREW-1 | 8,454 |
| C6-RINSE2 | C6 | DRAIN_RINSE | 139.14 | 140.116 | FS-600-B | CREW-1 | 21,136 |
| C7-RINSE1 | C7 | DRAIN_RINSE | 140.116 | 141.957 | FS-600-B | CREW-1 | 28,602 |
| C7-PASSIV | C7 | PASSIVATE | 141.957 | 142.687 | FS-600-B | CREW-1 | 0 |
| C7-HOLD | C7 | HOLD | 142.687 | 615.893 | NONE | NONE | 0 |
| C1-FLUSH | C1 | INITIAL_FLUSH | 168.0 | 168.465 | FS-1200-A | CREW-1 | 32,983 |
| C1-CLEAN | C1 | CHEM_CLEAN | 168.465 | 192.465 | FS-1200-A | CREW-1 | 32,983 |
| C2-FLUSH | C2 | INITIAL_FLUSH | 192.465 | 192.615 | FS-1200-A | CREW-1 | 5,596 |
| C1-RINSE1 | C1 | DRAIN_RINSE | 192.615 | 193.545 | FS-1200-A | CREW-1 | 65,967 |
| C1-RINSE2 | C1 | DRAIN_RINSE | 216.0 | 216.93 | FS-1200-A | CREW-1 | 65,967 |
| C2-CLEAN | C2 | CHEM_CLEAN | 216.93 | 240.93 | FS-1200-A | CREW-1 | 5,596 |
| C3-FLUSH | C3 | INITIAL_FLUSH | 240.93 | 241.074 | FS-1200-A | CREW-1 | 6,203 |
| C1-RINSE3 | C1 | DRAIN_RINSE | 241.074 | 242.004 | FS-1200-A | CREW-1 | 65,967 |
| C1-PASSIV | C1 | PASSIVATE | 242.004 | 242.969 | FS-1200-A | CREW-1 | 0 |
| C1-HOLD | C1 | HOLD | 242.969 | 612 | NONE | NONE | 0 |
| C3-CLEAN | C3 | CHEM_CLEAN | 242.969 | 266.969 | FS-1200-A | CREW-1 | 6,203 |
| C5-PASSIV | C5 | PASSIVATE | 266.969 | 267.693 | FS-600-B | CREW-1 | 0 |
| C3-RINSE1 | C3 | DRAIN_RINSE | 267.693 | 267.836 | FS-1200-A | CREW-1 | 0 |
| C5-HOLD | C5 | HOLD | 267.693 | 614.736 | NONE | NONE | 0 |
| C3-RINSE2 | C3 | DRAIN_RINSE | 267.836 | 268.553 | FS-1200-A | CREW-1 | 31,016 |
| C2-RINSE1 | C2 | DRAIN_RINSE | 268.553 | 269.45 | FS-1200-A | CREW-1 | 27,980 |
| C2-PASSIV | C2 | PASSIVATE | 269.45 | 270.099 | FS-1200-A | CREW-1 | 0 |
| C2-HOLD | C2 | HOLD | 270.099 | 612.5 | NONE | NONE | 0 |
| C8-PASSIV | C8 | PASSIVATE | 270.099 | 271.234 | FS-600-B | CREW-1 | 0 |
| C3-PASSIV | C3 | PASSIVATE | 271.234 | 271.878 | FS-1200-A | CREW-1 | 0 |
| C8-HOLD | C8 | HOLD | 271.234 | 613.617 | NONE | NONE | 0 |
| C3-HOLD | C3 | HOLD | 271.878 | 613.063 | NONE | NONE | 0 |
| C4-PASSIV | C4 | PASSIVATE | 271.878 | 272.653 | FS-600-B | CREW-1 | 0 |
| C4-HOLD | C4 | HOLD | 272.653 | 614.117 | NONE | NONE | 0 |
| C6-PASSIV | C6 | PASSIVATE | 272.653 | 273.348 | FS-600-B | CREW-1 | 0 |
| C6-HOLD | C6 | HOLD | 273.348 | 615.326 | NONE | NONE | 0 |
| C1-FILL | C1 | FINAL_FILL | 612 | 612.5 | FS-1200-A | CREW-1 | 0 |
| C2-FILL | C2 | FINAL_FILL | 612.5 | 613.063 | FS-1200-A | CREW-1 | 2,350 |
| C3-FILL | C3 | FINAL_FILL | 613.063 | 613.617 | FS-1200-A | CREW-1 | 2,350 |
| C8-FILL | C8 | FINAL_FILL | 613.617 | 614.117 | FS-600-B | CREW-1 | 0 |
| C4-FILL | C4 | FINAL_FILL | 614.117 | 614.736 | FS-600-B | CREW-1 | 2,580 |
| C5-FILL | C5 | FINAL_FILL | 614.736 | 615.326 | FS-600-B | CREW-1 | 2,580 |
| C6-FILL | C6 | FINAL_FILL | 615.326 | 615.893 | FS-600-B | CREW-1 | 1,450 |
| C7-FILL | C7 | FINAL_FILL | 615.893 | 616.503 | FS-600-B | CREW-1 | 1,950 |

Milestones (CX-01 Rev B): hydro tests complete 110.7 h (TM-1 = 144 h); chemical cleaning complete 267.0 h (TM-2 = 528 h); film formation complete 615.9 h (TM-3 = 1,056 h); last activity 616.5 h (TM-4 = 1,128 h, contractual).

Holds (occupied hours): C1 369.0 h (15.38 d); C2 342.4 h (14.27 d); C3 341.2 h (14.22 d); C4 341.5 h (14.23 d); C5 347.0 h (14.46 d); C6 342.0 h (14.25 d); C7 473.2 h (19.72 d); C8 342.4 h (14.27 d).

Contractor scope carried in the lump-sum mobilisation and excluded from the priced comparison (cl.3.10 f): the hydrostatic test pump for C3, C5, C6, C7; the portable holding tank for every cascaded displacement; fine filtration ahead of the CDUs (300 micron) and cold-plate banks (50 micron) - below the 380 micron rating of the VD-05 strainer - fitted before those components are reinstated at turnover.

## 6. Cost (23 25 16 cl.3.10)

Skid rental $8,180.00; crew $17,220.00; water $4,331.02; effluent $10,090.04 (sewer $4,670.85, tanker $5,419.19); chemicals $6,694.00; TOTAL $46,515.06.

| Circuit | Skid | Crew | Water | Effluent | Chemicals | Total |
|---|---|---|---|---|---|---|
| C1 | 1,840.83 | 2,664.77 | 1,862.28 | 2,112.00 | 1,722.00 | 10,201.88 |
| C2 | 1,344.33 | 1,957.46 | 293.05 | 368.22 | 660.00 | 4,623.06 |
| C3 | 1,554.85 | 2,076.88 | 366.82 | 413.88 | 660.00 | 5,072.43 |
| C4 | 670.85 | 1,996.09 | 396.57 | 1,394.22 | 752.00 | 5,209.73 |
| C5 | 715.10 | 2,085.28 | 515.52 | 1,562.12 | 752.00 | 5,630.02 |
| C6 | 666.00 | 2,144.18 | 308.57 | 1,029.37 | 800.00 | 4,948.12 |
| C7 | 596.48 | 2,161.01 | 302.13 | 1,032.11 | 640.00 | 4,731.73 |
| C8 | 791.56 | 2,134.33 | 286.08 | 2,178.12 | 708.00 | 6,098.09 |

Unit-days and crew shifts are apportioned by hours within each day/shift (cl.3.10 a, b); water at the single programme-average rate; chemicals in whole packages per dosing row.

## 7. Conflicts, judgement calls and defects

### Conflicts resolved

1. Discharge cap: SW-03 Rev A and RFI-031 state 540,000 gal; SW-03 Rev B (later) states 500,000 gal and supersedes Rev A section 2. 500,000 gal applied.
2. Hydrostatic record: CX-02 shows PASS for all circuits but four cited charts are not on file; 01 91 13 cl.1.3 governs - C3, C5, C6, C7 retested; C1, C2, C4, C8 not retested (23 21 16 cl.3.3).
3. M-PID-103 Rev A vs Rev C: line 4033 is in C4 (x2) on Rev A and in C5 (x3) on Rev C; Rev C and M-601 (3 legs) govern.
4. Passivation tables: UFC 3-230-13 tabulates passivation dosages/film times in Table 5-11 (10-12 days, 40-60 ppm) and in Tables 5-14/5-15 (14-21 days, polysilicate 40-50 ppm, with pH bands). Para 5-7.3.2.4 identifies Tables 5-14/5-15 for passivation; per 23 25 16 cl.3.5 they govern. Doses chosen inside both bands; holds of at least 14 days.
5. Maintenance dose: Table 5-11 lists cooling-tower maintenance levels (polysilicate 10-20 ppm, TTA 1-2 ppm); the closed-system programme text (6-2.2.5: 80-100 ppm SiO2, TTA >= 10 ppm) governs the turnover (cl.3.5 "the residual ... that document specifies for the program selected"). This also makes RETAIN_AND_TOP_UP permissible.
6. Programme selection: Table 6-2 lists polysilicate-azole only for diesel jackets, while para 6-2.2.5 recommends it where aluminium is present (closed process cooling loops); the paragraph governs (cl.3.5).
7. pH bands: polysilicate (7.5-8.5) and TTA (6.5-7.9) overlap only in part; copper circuits controlled at 7.5-7.9 (cl.3.8). C6 additionally inside VD-04 in-service 7.0-8.5.
8. Rinse pH: tolerance 7.6 +/-0.3 (7.3-7.9) vs window 7.5-8.5; control band 7.5-7.9 satisfies both (cl.3.6).
9. Discharge pH: 40 CFR 403.5(b)(2) floor 5.0 vs SW-03 local limit 6.0; the more restrictive 6.0 applies (SW-03 general condition 1). Temperature 104 degF in both.
10. Water limit: the 62,000 gal metered allocation is the price break, not the limit; the daily limit is 92,000 gal (SW-01 cl.2) as varied by SI-04.
11. Component limits: VD-03/VD-04 dP figures are developed drops at rated flow; the M-602 maximum allowable dP governs (M-602 Note 6, VD-03 note 5). With bypasses fitted no bypassable component sees flushing flow; at the full flushing flows several would exceed their allowable dP (e.g. HX-201B 64.2 ft vs 58 ft at 721 gpm), so spools stay fitted until the top-up circulation is complete.
12. Coil bank CL-401: M-602 lists "copper, aluminium fin (dry)"; VD-04 note 4 confirms the wetted path is copper - C7 treated as copper, not aluminium (CL-100 permitted; eta 0.45 still applies as a coil bank).
13. Makeup hardness 288 mg/L exceeds the 250 mg/L guideline for chilled closed systems (UFC 6-2.1, Table 6-1; programme step 1). Softening cannot be applied to the flushing/rinse water at the declared flows; the turnover top-ups use SV-2 where capacity allows and the owner's operating makeup should be softened. Recorded for the Engineer of Record; no effect on the accounting.

### Judgement calls

- Flows are the minimum required flows rounded up to the next whole gpm; one initial-flush displacement; single skid per circuit; RETAIN_AND_TOP_UP throughout.
- Doses at the bottom of each permitted band (dispersant 4 ppm, SiO2 40/80 ppm, TTA 10 ppm); whole packages give a small surplus that keeps residuals inside the bands.
- Holds kept between 14 and 21 days (occupied); all eight top-ups done in one shift after the last hold so that the turnover pays for one crew shift and one day of each skid.
- Daily draws kept at or below 95 percent of the day limit; sewered total kept below the cap with a buffer of several thousand gallons.
- Stages are split into several activities where the daily water limit requires it (e.g. the C1 rinse in batches of two displacements on separate days); between batches the skid may serve another circuit (never two at once) and the circuit stands full. Contact, circulation, displacement and hold times are counted only as occupied hours (cl.3.10 b).
- Crews are engaged per 12-h shift; the plan keeps the attended work contiguous so that charged shifts are fully used, and never deploys more than two crews.
- Rinse effluent is sewered: VD-06 Note 3 characterises the spent solution only; the rinse effluent falls from it to makeup quality and is sampled before release (SW-03 condition 4); any batch failing a local limit is diverted to the tanker.

### Defects found in the documents

- UFC 3-230-13 Table 5-14 states orthophosphate and tolyltriazole dosages in "days" (should be ppm); Table 6-1 carries an orphan line "Less than 50 ppm hardness"; Table 6-3 prints 10^3 as "103".
- VD-06 / VD-07: NB-700 is "68 % sodium nitrite" in VD-06 but "NO2 at 68 percent active" in VD-07 (68 % NaNO2 is about 45 % as NO2). VD-07 classifies SA-100 soda ash as Skin Corr. 1B / Eye Dam. 1 (sodium carbonate is normally Eye Irrit. 2A).
- VD-03 notes are numbered 1, 5, 2, 3, 4. M-ISO-204 gives the ROOF tie-in at grade datum +0 ft with a 72 ft lift; used as drawn.
- CX-02 cites charts TR-0414, TR-0416, TR-0417, TR-0418 that are not in the record set.
- SW-03 Rev A / RFI-031 cap (540,000 gal) not updated after Rev B.

## 8. Safety - hazard communication (29 CFR 1910.1200)

- Written hazard communication programme (1910.1200(e)) for this scope, kept at the MER-1 site office and on each skid, with the list of hazardous chemicals on site: CL-100 and CL-210 (Skin Corr. 1B, Eye Dam. 1, DANGER), PS-330, TA-90 and PD-45 (Eye Irrit. 2A, WARNING). NB-700, MO-500 and SA-100 are not brought to site.
- Safety data sheets (VD-07) for every product maintained at each tie-in location and readily accessible during every shift (1910.1200(g)(8)); CX-03 item 10 signed before the first chemical is opened.
- Labels: shipped containers kept labelled; every secondary container, dosing pot and day tank labelled with product identifier and hazard information (1910.1200(f)(6)).
- Information and training (1910.1200(h)) for both crews before initial assignment: hazards, location of the programme and SDS, detection of releases, PPE and emergency procedures.
- SDS controls: chemical splash goggles, face shield, chemical-resistant gloves and apron for all transfers; emergency eyewash and quick-drench shower within 10 seconds of every handling point (mobile units at each skid pad); eyes flushed 15 minutes. Cleaners are dosed through the skid dosing pot, never by open pouring at height; spill kits at each pad; UFC 3-230-13 para 8-4.1 handling and storage practices followed.
- Hydrostatic testing: exclusion zone during pressurisation, test pressure 127.5 psig not exceeding the lowest component rating, gauge calibration certificate and chart filed (01 91 13 cl.1.3).
- Discharge: batch sampled before release; tanker standing at the yard pad only (C-101); no discharge to storm or creek.
