# BASIS OF ESTIMATE - DEVICE TAKEOFF AND PRICED BILL

Meridian Data Center, Phase 1, Data Hall 1 (MDC-2026-014). Drawings issued for construction 2026-07-24, revision 2 (2026-07-27, Addendum 1 clouds) on every sheet; Addendum No. 02 dated 2026-08-07.

**Basket total (sum of attribution rows in bom.csv): $17,986.78**  
Purchase total (what is bought, incl. 5 percent spare and whole cartons): $21,166.05

## 1. Counting conventions applied

| clause | how it was applied |
|---|---|
| C1 / E-05 | A device is counted once. Match lines A and B sit at 14400 mm (x and y) on E-201..E-204; each parent plan schedules only its own side (general sheet note 3). Screened (grey) symbols beyond a match line were checked against the adjacent sheet and not recounted. Keyed note <1>, printed on E-201..E-204 and E-211, is one requirement counted once. |
| C2 | E-001 is the only symbol definition. Symbols were matched pixel-for-pixel against the E-001 legend symbols (drawn at the same plotted size, legend note 2). |
| C3 / E-04 | A square enclosing a diamond (looks like R7, whose square encloses a circle) is not in the legend: no quantity, listed as unresolved (section 4). |
| C4 | R8 and F6 have no instance on any plan: quantity 0. |
| C5 / E-06 | Keyed notes provided (section 3). |
| C6 / E-07 | ADD-02 (2026-08-07) postdates the revision of every sheet (rev 2, 2026-07-27) and governs for item 02-1. |
| C7 / E-08 | ELECTRICAL / ENTRY (west strip, x < 1800 mm) and PDU GALLERY (east strip, x > 23400 mm) are drawn without devices on the parent plans except as noted below; their devices are counted from E-231, E-232 and E-233. The 1:20 viewports overlap by about 470 mm; no device appears in two viewports. |
| C8 / C9 | Condition by location (section 5); counts split per (type mark, condition) in locations.csv and bom.csv. |

Grid bays follow E-001 legend notes 6-7: column lines 1, 2, 3 at 7500, 14700, 21900 mm from the west wall line; row lines A, B, C at 7500, 14700, 21900 mm from the south wall line; bay = letter (rows) then number (columns), e.g. A1 = south-west bay.

## 2. Sheets each type mark was counted from, and governing issue

| mark | qty | sheets (count) | source |
|---|---|---|---|
| R1 | 51 | E-201 (7), E-202 (14), E-203 (4), E-204 (4), E-231 (9), E-232 (7), E-233 (6) | drawn 51 |
| R2 | 8 | E-201 (2), E-232 (3), E-233 (3) | added-ADD02 2, drawn 6 |
| R3 | 8 | E-231 (3), E-232 (3), E-233 (2) | drawn 8 |
| R4 | 6 | E-202 (4), E-233 (2) | drawn 6 |
| R5 | 32 | E-201 (20), E-202 (8), E-203 (2), E-204 (2) | drawn 4, keynote<2> 28 |
| R6 | 4 | E-201 (1), E-203 (1), E-231 (1), E-233 (1) | drawn 4 |
| R7 | 6 | E-202 (5), E-204 (1) | keynote<3> 6 |
| R8 | 0 | - | no instance on any plan |
| J1 | 38 | E-201 (11), E-202 (7), E-203 (7), E-204 (8), E-231 (4), E-232 (1) | drawn 38 |
| P1 | 7 | E-201 (1), E-202 (1), E-203 (1), E-231 (2), E-232 (1), E-233 (1) | drawn 7 |
| F1 | 12 | E-211 (12) | keynote<1> 8, keynote<4> 4 |
| F2 | 4 | E-211 (1), E-231 (2), E-233 (1) | drawn 4 |
| F3 | 3 | E-211 (2), E-233 (1) | drawn 3 |
| F4 | 6 | E-211 (6) | drawn 6 |
| F5 | 30 | E-211 (25), E-232 (2), E-233 (3) | drawn 30 |
| F6 | 0 | - | no instance on any plan |
| D1 | 27 | E-211 (25), E-231 (1), E-232 (1) | drawn 27 |

Governing issue: all sheets are at revision 2 (2026-07-27). Addendum No. 02 is dated 2026-08-07, so it postdates every sheet and governs for what it describes (item 02-1); the sheets govern for everything else. ADD-02 item 02-1: at the cloud tagged revision 2 on E-201 (the plan covering grid bay A1) the four duplex receptacles R1 in bay A1 were deleted (at approx. (3360, 368), (4330, 1793), (4330, 4803), (4330, 7203) mm) and one quadraplex receptacle R2 was added at each of the first and second deleted positions measured from the south ((3360, 368), (4330, 1793) mm). The other symbols inside that cloud (R5 x4, R6, J1 x2, P1) are not duplex receptacles of type R1 ("no other device ... is deleted") and were kept.

Notes on drawn devices: the four R5 symbols on E-201 stand in the ENTRY VESTIBULE (room VEST, DAMP) at x = 900 mm and are drawn on the parent plan; they are not on any enlarged plan and are counted once from E-201. E-211 carries the ceiling (F4) and under-floor (F5, drawn as a dotted circle with bar) detectors and the duct detectors (D1) for the hall; the PDU GALLERY F5 and the D1 at CRAH-01 and CRAH-04 appear only on the enlarged plans and are counted from there.

## 3. Keyed notes (devices not drawn)

| note | sheets | requirement | census (other sheet) | qty | condition |
|---|---|---|---|---|---|
| <1> | E-201..E-204, E-211 | one visible appliance (F1) at each structural column bay on the north and south walls | 4 bay columns (1-4: west wall-1, 1-2, 2-3, 3-east wall) x 2 walls, column grid on A-102 | 8 | DRY-MASONRY (north/south walls are P2) |
| <4> | E-211 | one visible appliance (F1) on the wall at each exit door | A-102 door schedule EGRESS = YES: D-01, D-02 (in P3 / P-R1), D-04 (W-W), D-05 (W-E); D-03 is not an exit | 4 | D-01, D-02 RATED-2HR; D-04, D-05 DRY-STUD (P1) |
| <2> | E-201..E-204 | one weather-resistant receptacle with extra-duty while-in-use cover (R5) within 7.6 m of each CRAH unit | CRAH units drawn on A-101 / A-102 / M-101 at revision 2 ("in-row CRAH units added"): 4 perimeter (CRAH-01..04) + 24 in-row (CRAH-A01..F04). The A-601 / M-101 schedule QTY (12 in-row) is not a census of the drawn units. | 28 | DRY-STUD (note names no wall) |
| <3> | E-201..E-204 | one floor box in the access floor (R7) at each PDU | PDU-01..PDU-06 (A-101, A-601, A-102) | 6 | ACCESS-FLOOR (E-002 mounting) |

## 4. Unresolved symbols (not in the E-001 legend - no quantity carried)

| sheet | view | grid bay | location (hall mm from SW corner) | description |
|---|---|---|---|---|
| E-232 | PDU GALLERY - 2 OF 7 (detail 9) | A4 | x approx. 25200, y approx. 5280 (directly north of an R1) | square enclosing a diamond |
| E-233 | PDU GALLERY - 6 OF 7 (detail 13) | C4 | x approx. 25200, y approx. 18720 (directly south of an R1) | square enclosing a diamond |

Neither symbol matches any E-001 entry (R7 is a square enclosing a circle). They are reported to the Engineer for clarification and are excluded from takeoff.csv, locations.csv and bom.csv.

## 5. Condition split and where it came from

Order applied: (1) a condition set by E-002 governs - R6 EMERGENCY (BRANCH), R4 IG, F4 CEILING, R7 and F5 ACCESS-FLOOR (MOUNTING), D1 carried under CEILING; (2) otherwise a device inside an area hatched DAMP on A-102 is DAMP (entry vestibule x 0-1500, y 0-8000 mm; CRAH condensate aprons 2400 x 2100 mm at the four perimeter CRAH units); (3) otherwise the construction of the nearest A-102 wall measured to its centreline: west and east walls P1 (steel stud, DRY-STUD, centrelines x = 75 and 26925 mm), north and south walls P2 (200 mm masonry, DRY-MASONRY, centrelines y = 23850 and 150 mm), electrical/entry partition P3 (two-hour, RATED-2HR, centreline x = 1650 mm); (4) keyed-note devices take the wall the note names (door wall for <4>) or DRY-STUD. The pull box P1 on E-201 at approx. (2400, 900) mm lies on the east edge of the CRAH-01 condensate apron and is carried as DAMP.

| mark | DRY-STUD | DRY-MASONRY | RATED-2HR | DAMP | CEILING | ACCESS-FLOOR | EMERGENCY | IG | total |
|---|---|---|---|---|---|---|---|---|---|
| R1 | 19 | 19 | 10 | 3 |  |  |  |  | 51 |
| R2 | 6 | 2 |  |  |  |  |  |  | 8 |
| R3 | 7 |  |  | 1 |  |  |  |  | 8 |
| R4 |  |  |  |  |  |  |  | 6 | 6 |
| R5 | 28 |  |  | 4 |  |  |  |  | 32 |
| R6 |  |  |  |  |  |  | 4 |  | 4 |
| R7 |  |  |  |  |  | 6 |  |  | 6 |
| J1 | 5 | 18 | 13 | 2 |  |  |  |  | 38 |
| P1 | 3 |  | 1 | 3 |  |  |  |  | 7 |
| F1 | 2 | 8 | 2 |  |  |  |  |  | 12 |
| F2 | 1 |  | 2 | 1 |  |  |  |  | 4 |
| F3 | 1 | 1 | 1 |  |  |  |  |  | 3 |
| F4 |  |  |  |  | 6 |  |  |  | 6 |
| F5 |  |  |  |  |  | 30 |  |  | 30 |
| D1 |  |  |  |  | 27 |  |  |  | 27 |

## 6. Assembly chosen for each (type mark, condition) pair and the clause that permits it

| mark | condition | count | assembly per device (catalogue line x multiplicity) | permitted by |
|---|---|---|---|---|
| R1 | DRY-STUD | 19 | DEV-DUP-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| R1 | DRY-MASONRY | 19 | DEV-DUP-20 x1 + BOX-MAS-4KO x1 | 26 05 33 2.3 / 3.2; A-102 note 3 (masonry box, no plaster ring) |
| R1 | RATED-2HR | 10 | DEV-DUP-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 + ACC-FIRESTOP-PAD x1 | 26 05 33 2.4 / 3.2; 07 84 00 2.1, 3.1 (DRY-STUD box + listed intumescent pad) |
| R1 | DAMP | 3 | DEV-GFCI-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 (+ extra-duty while-in-use hood and gasketed plate: required, not catalogued, no line) | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2, 2.9 h (wet-listed GFCI receptacle) |
| R2 | DRY-STUD | 6 | DEV-DUP-20 x2 + BOX-4SQ-15 x1 + RING-1G-58 x1 (quadraplex = two duplex receptacles) | 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| R2 | DRY-MASONRY | 2 | DEV-DUP-20 x2 + BOX-MAS-4KO x1 (quadraplex = two duplex receptacles) | 26 05 33 2.3 / 3.2; A-102 note 3 (masonry box, no plaster ring) |
| R3 | DRY-STUD | 7 | DEV-GFCI-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| R3 | DAMP | 1 | DEV-GFCI-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 (+ extra-duty while-in-use hood and gasketed plate: required, not catalogued, no line) | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2, 2.9 h (wet-listed GFCI receptacle) |
| R4 | IG | 6 | DEV-IG-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 + ACC-IG-CONDUCTOR x1 | 26 20 00 2.2; E-002 note 3; NFPA 70 250.146(D) (DRY-STUD assembly + 1 insulated EGC) |
| R5 | DRY-STUD | 28 | DEV-GFCI-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 (+ extra-duty while-in-use hood and gasketed plate: required, not catalogued, no line) | 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| R5 | DAMP | 4 | DEV-GFCI-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 (+ extra-duty while-in-use hood and gasketed plate: required, not catalogued, no line) | 26 20 00 2.3, 2.5; UFGS 26 20 00 2.12.2, 2.9 h (wet-listed GFCI receptacle) |
| R6 | EMERGENCY | 4 | DEV-DUP-20 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 26 20 00 3.2; E-002 note 2 (separate box per device) |
| R7 | ACCESS-FLOOR | 6 | BOX-FLOOR-2G x1 | 26 05 33 2.6, 2.9; UFGS 28 31 76 3.2.5 (listed floor box / access-floor detector on 100 mm box) |
| J1 | DRY-STUD | 5 | BOX-4SQ-15 x1 + CVR-4SQ-BLANK x1 (26 05 33 2.8: flat blank cover, no ring on a junction box) | 26 05 33 2.8 (100 mm sq box + flat blank cover, no ring); box family per 26 05 33 2.2 |
| J1 | DRY-MASONRY | 18 | BOX-MAS-4KO x1 + CVR-4SQ-BLANK x1 (26 05 33 2.8: flat blank cover, no ring on a junction box) | 26 05 33 2.8 (100 mm sq box + flat blank cover, no ring); masonry box per 26 05 33 2.3, A-102 note 3 |
| J1 | RATED-2HR | 13 | BOX-4SQ-15 x1 + CVR-4SQ-BLANK x1 + ACC-FIRESTOP-PAD x1 (26 05 33 2.8: flat blank cover, no ring on a junction box) | 26 05 33 2.8 (100 mm sq box + flat blank cover, no ring); pad per 26 05 33 2.4, 07 84 00 2.1 (junction boxes included) |
| J1 | DAMP | 2 | BOX-4SQ-15 x1 + CVR-4SQ-BLANK x1 (26 05 33 2.8: flat blank cover, no ring on a junction box) | 26 05 33 2.8 (100 mm sq box + flat blank cover, no ring); A-102 note 5 (no receptacle in this assembly) |
| P1 | DRY-STUD | 3 | BOX-PULL-12 x1 (26 05 33 2.7: pull box and cover are one assembly) | 26 05 33 2.7 (pull box and cover one assembly) |
| P1 | RATED-2HR | 1 | BOX-PULL-12 x1 + ACC-FIRESTOP-PAD x1 (26 05 33 2.7: pull box and cover are one assembly) | 26 05 33 2.7 (pull box and cover one assembly); pad per 07 84 00 2.1 (pull boxes included) |
| P1 | DAMP | 3 | BOX-PULL-12 x1 (26 05 33 2.7: pull box and cover are one assembly) | 26 05 33 2.7 (pull box and cover one assembly); A-102 note 5 (no receptacle in this assembly) |
| F1 | DRY-STUD | 2 | APP-STROBE-120 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| F1 | DRY-MASONRY | 8 | APP-STROBE-120 x1 + BOX-MAS-4KO x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.3 / 3.2; A-102 note 3 (masonry box, no plaster ring) |
| F1 | RATED-2HR | 2 | APP-STROBE-120 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 + ACC-FIRESTOP-PAD x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.4 / 3.2; 07 84 00 2.1, 3.1 (DRY-STUD box + listed intumescent pad) |
| F2 | DRY-STUD | 1 | APP-BS-120 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| F2 | RATED-2HR | 2 | APP-BS-120 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 + ACC-FIRESTOP-PAD x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.4 / 3.2; 07 84 00 2.1, 3.1 (DRY-STUD box + listed intumescent pad) |
| F2 | DAMP | 1 | APP-BS-120 x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 28 31 76 2.1 (appliance on 100 mm box); A-102 note 5 (no receptacle in this assembly) |
| F3 | DRY-STUD | 1 | APP-PULL x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.2 / 3.2 (4 in sq box + raised plaster ring); UFGS 26 20 00 2.9 |
| F3 | DRY-MASONRY | 1 | APP-PULL x1 + BOX-MAS-4KO x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.3 / 3.2; A-102 note 3 (masonry box, no plaster ring) |
| F3 | RATED-2HR | 1 | APP-PULL x1 + BOX-4SQ-15 x1 + RING-1G-58 x1 + ACC-FIRESTOP-PAD x1 | 28 31 76 2.1-2.2 (appliance on 100 mm box); 26 05 33 2.4 / 3.2; 07 84 00 2.1, 3.1 (DRY-STUD box + listed intumescent pad) |
| F4 | CEILING | 6 | DET-PHOTO x1 + BOX-4SQ-15 x1 | 26 05 33 2.9; UFGS 28 31 76 3.2.5 (100 mm mounting box, no ring); 28 31 76 1.3 for D1 |
| F5 | ACCESS-FLOOR | 30 | DET-PHOTO-UF x1 + BOX-4SQ-15 x1 | 26 05 33 2.6, 2.9; UFGS 28 31 76 3.2.5 (listed floor box / access-floor detector on 100 mm box) |
| D1 | CEILING | 27 | INS-DUCT-DET x1 + BOX-4SQ-15 x1 (detector furnished by Div 23 - installation line only, 28 31 76 1.3) | 26 05 33 2.9; UFGS 28 31 76 3.2.5 (100 mm mounting box, no ring); 28 31 76 1.3 for D1 |

Item selection within the permitted set: the lowest-cost permitted line at its own quantity band was used - BOX-4SQ-15 for the 4 in square family, RING-1G-58 (4 in square raised plaster ring), BOX-MAS-4KO, BOX-PULL-12, BOX-FLOOR-2G (recessed steel access-floor box, not the on-grade box), DEV-DUP-20 (spec grade 5-20R, 26 20 00 2.1), DEV-GFCI-20 (listed WET, GFCI, weather-resistant), DEV-IG-20, APP-STROBE-120 (only VISIBLE appliance), APP-BS-120 (AUDIBLE-VISIBLE, cheaper than APP-HS-24 at this quantity), APP-PULL, DET-PHOTO, DET-PHOTO-UF, INS-DUCT-DET.

While-in-use hood: UFGS 26 20 00 2.12.2 / 26 20 00 2.3 / 26 05 33 2.5 require a gasketed, weather-resistant, EXTRA-DUTY rated while-in-use hood (and a gasketed plate, UFGS 2.9 h) for every weather-resistant receptacle (all R5) and every receptacle in a DAMP area. The catalogue carries no while-in-use hood or gasketed plate, so the requirement is stated here and no line is carried for it.

Fire-rated assemblies (E-14): every box in a RATED-2HR pair carries one listed intumescent pad (ACC-FIRESTOP-PAD); boxes on opposite faces of a common wall are not to be placed back-to-back and keep 300 mm (12 in) separation (UFC 3-520-01 3-6.1) - an installation requirement, no material line.

Mounting heights (E-002, measured to the centre of the device, UFGS 26 20 00 3.1.10): R1-R6 460 mm AFF; R8 1200 mm AFF; J1 and P1 2600 mm AFF; F1, F2 (and F6) 2286 mm AFF; F3 1067 mm AFF to the handle; F4 ceiling; F5 and R7 in the access floor; D1 at the unit.

## 6a. Judgement calls (reported to the Engineer)

1. ADD-02 item 02-1 deletes "the duplex receptacles" at the clouded location: read as type R1 (RECEPTACLE, DUPLEX, 20 A, 125 V - the only receptacle without a further qualifier; the added quadraplex R2 is its counterpart). The weather-resistant R5, emergency R6, junction boxes and pull box inside the same cloud are kept ("no other device ... is deleted").
2. The four R5 receptacles drawn on E-201 at x = 900 mm stand inside the ENTRY VESTIBULE (VEST, DAMP), which A-102 names as a room separate from ELECTRICAL / ENTRY; they appear on no enlarged plan and are counted once from E-201.
3. Keyed note <2> census = every CRAH unit drawn at the latest issue (A-101, A-102, M-101, E-sheets all show 4 perimeter + 24 in-row units, revision 2 "in-row CRAH units added"); the QTY columns of the A-601 CRAH schedule and the M-101 consumer schedule (2 per row) are not a census of the drawn units.
4. The dotted-circle-with-bar symbols on E-211, E-232 and E-233 are read as F5 (legend: broken circle with bar, in access floor); they lie on a 21 m2 (UFGS 28 31 76 3.2.5) grid under the floor and E-211 note 3 places the under-floor detectors on that sheet.
5. Pull box P1 on E-201 at approx. (2400, 900) mm: on the east boundary of the CRAH-01 condensate apron, carried as DAMP (boundary included).
6. Keyed-note devices have no drawn position: F1 (notes <1>, <4>) are reported on the fire alarm plan E-211; R5 (<2>) and R7 (<3>) are reported on the parent plan whose area contains the CRAH unit / PDU they serve, in that unit's grid bay.

## 7. Pricing, spare stock and carton method

1. REQUIRED quantity of a line = sum over pairs of (pair device count x multiplicity in its assembly).
2. Unit price = the price-list rate of the band that line's own REQUIRED quantity falls in (before spare and cartons); the same rate is used on the attribution rows and the purchase row of that line.
3. Extended price = quantity x unit price, rounded to the cent. Basket total = sum of attribution rows = **$17,986.78**.
4. PURCHASE quantity = required + 5 percent Owner spare stock (OPR 4), i.e. ceil(1.05 x required), rounded UP to the next whole carton at the printed carton size. Cartons and spare are constraints on what is bought and are not in the basket total.

| line item | required | band | unit price | purchase (cartons) |
|---|---|---|---|---|
| ACC-FIRESTOP-PAD | 29 | 24-199 | 94.06 | 40 (4 x 10) |
| ACC-IG-CONDUCTOR | 6 | 3-23 | 3.36 | 10 (1 x 10) |
| APP-BS-120 | 4 | 2-19 | 70.06 | 5 (5 x 1) |
| APP-PULL | 3 | 2-11 | 81.06 | 4 (4 x 1) |
| APP-STROBE-120 | 12 | 4-35 | 299.44 | 13 (13 x 1) |
| BOX-4SQ-15 | 181 | 75-749 | 1.99 | 200 (8 x 25) |
| BOX-FLOOR-2G | 6 | 3-23 | 104.36 | 7 (7 x 1) |
| BOX-MAS-4KO | 48 | 30-249 | 22.02 | 75 (3 x 25) |
| BOX-PULL-12 | 7 | 4-29 | 34.75 | 8 (8 x 1) |
| CVR-4SQ-BLANK | 38 | 20-199 | 0.81 | 40 (4 x 10) |
| DET-PHOTO | 6 | 3-23 | 116.39 | 7 (7 x 1) |
| DET-PHOTO-UF | 30 | 15-119 | 133.02 | 32 (32 x 1) |
| DEV-DUP-20 | 68 | 40-399 | 5.18 | 80 (8 x 10) |
| DEV-GFCI-20 | 43 | 20-199 | 20.03 | 50 (5 x 10) |
| DEV-IG-20 | 6 | 3-23 | 24.25 | 10 (1 x 10) |
| INS-DUCT-DET | 27 | 15-119 | 98.15 | 29 (29 x 1) |
| RING-1G-58 | 98 | 40-299 | 1.09 | 125 (5 x 25) |

