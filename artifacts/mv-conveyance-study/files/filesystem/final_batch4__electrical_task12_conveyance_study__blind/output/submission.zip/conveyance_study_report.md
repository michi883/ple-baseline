# Pacific Crest SFA - 13.8 kV Site Distribution: Conveyance Study (FA4610-26-R-0031, Amd 0002)

Study date 2026-09-15. Prepared by the design-build contractor (electrical engineer / cost estimator). 10 % design level per RFP 1.5. Workbook `conveyance_study.xlsx` carries the full take-off, live roll-up formulas, segments, structures and pulling results.

## 1. Summary of recommendations

| Item | Circuit | Recommended | Cable | Sets | OH conductor | Design I (A) | Ampacity/set (A) | Route (ft) | Direct cost ($) | Total project cost ($) | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| C01 | SS-1 F1 to MB-1 MSG-A | CEDB | 500 kcmil | 2 | - | 640 | 331.5 | 857.3 | 196,701 | 278,499 | 324.86 |
| C02 | SS-1 F2 to MB-1 MSG-B | OH | 350 kcmil | 2 | 336.4 | 560 | 299.1 | 1,338.2 | 164,821 | 233,361 | 174.39 |
| C03 | SS-1 F3 to CUP-1 SWG-C1 | CEDB | 500 kcmil | 1 | - | 400 | 466.1 | 353.8 | 52,691 | 74,602 | 210.84 |
| C04 | CUP-1 CF-2 to TX-LS2 | OH | 250 kcmil | 1 | 1/0 | 60 | 196.0 | 1,408.7 | 144,702 | 204,876 | 145.44 |
| C05 | MSG-A A-3 to USS-A1 (in MB-1) | RMC | 250 kcmil | 2 | - | 200 | 160.0 | 400.0 | 149,454 | 211,605 | 529.01 |
| C06 | SS-1 F4 to TX-GH1 | OH | 250 kcmil | 1 | 1/0 | 40 | 196.0 | 1,817.4 | 77,984 | 110,413 | 60.75 |
| C07 | CUP-1 CF-1 to TX-W3 | CEDB | 250 kcmil | 1 | - | 120 | 330.5 | 680.0 | 99,325 | 140,629 | 206.81 |

Total project cost of the seven recommended designs: $1,253,984.

## 2. Estimating basis (RFP Part 3)

* Wage determination CA20260022 **Modification 5** (published 08/06/2026, effective for the 2026-10-08 sealed-bid opening under 29 CFR 1.6(c)(2)(ii)(A)); classifications per RFP 2.1; no military-base premium (RFP 2.2).
* Loaded rate = base x (1 + burden) + fringe; burden = FICA 7.65 + FUTA 0.60 + CA SUI 3.40 + workers comp of the class code (7538: 8.74, 5190: 4.12, 6218: 7.35 per $100).
* Labor units from the PCEC 2026 database; P-405 units x 67/80; PULL-MV and DBC-LAY x 0.85 (puller); XARM, GUY, STRING x 0.85 (bucket truck); conductors > 4/0 strung at 0.0328 MH/ft.
* Equipment: EP 1110-1-8 Vol 7 Region VII Table 2-2 (average) with fuel and FOG scaled by jobsite/EP fuel price (gasoline 5.12/2.49 = 2.056; off-road diesel 4.38/2.26 = 1.938); rentals at RQ-26-0419.
* Materials: quote Q-2608-114 x (1 + waste) x PPI (items marked (I): WPU102603 Aug-2026 494.096 / Jul-2026 482.612 = 1.02380) x 1.095 sales tax. Subcontracts at ADD-26-311 and PJB-8817.
* Roll-up: JOOH 9.5 %; HOOH 4.5 %; profit 7.949 % (weighted guidelines; size-of-job weight 0.0614, period 0.0848, subcontracting 0.0862); bond 1.3124 % (Class B premium $14,358.42 on $1,094,021.22, +3 % for 15 months); escalation factor 1.01939 (1.06169 at 2027-08-18 / 1.04150 at 2026-09-15); design contingency 5.0 %; SIOH 5.7 % on contract cost plus contingency; no area cost factor (UFS 3-701-01 4-1.1).

### Labor rates used

| Class | WD group | Base ($/h) | Fringe ($/h) | Burden (%) | Loaded ($/h) |
|---|---|---|---|---|---|
| LINEMAN | ELEC1245-001 | 70.16 | 24.71 | 20.39 | 109.18 |
| EQSPEC | ELEC1245-001 | 53.30 | 22.26 | 20.39 | 86.43 |
| GROUNDMAN | ELEC1245-001 | 40.76 | 21.76 | 20.39 | 70.83 |
| LAB1 | LABO0300-003 | 46.48 | 25.95 | 19.00 | 81.26 |
| LAB3 | LABO0300-003 | 47.58 | 25.95 | 19.00 | 82.57 |
| LAB4 | LABO0300-003 | 49.13 | 25.95 | 19.00 | 84.41 |
| PUMPOP | ENGI0012-024 | 63.40 | 33.20 | 19.00 | 108.65 |
| ELECTRICIAN | ELEC0011-004 | 60.80 | 31.59 | 15.77 | 101.98 |
| SPLICER_IN | ELEC0011-004 | 63.84 | 31.59 | 15.77 | 105.50 |

### Crew rates (average loaded labor rate per MH; equipment $ per MH)

| Crew | Size | Labor $/MH | Equipment $/MH |
|---|---|---|---|
| CR-EX | 2 | 83.84 | 29.34 |
| CR-TM | 2 | 82.57 | 7.31 |
| CR-BF | 3 | 83.86 | 11.29 |
| CR-DU | 6 | 83.61 | 0.00 |
| CR-CO | 4 | 81.26 | 0.00 |
| CR-CP | 6 | 86.21 | 25.75 |
| CR-SP | 2 | 90.00 | 0.00 |
| CR-MH | 4 | 84.92 | 15.26 |
| CR-DW | 1 | 108.65 | 3.85 |
| CR-OH | 4 | 90.00 | 24.00 |
| CR-OH2 | 2 | 90.00 | 48.00 |
| CR-OH3 | 3 | 96.39 | 32.00 |
| CR-STR | 10 | 86.17 | 19.20 |
| CR-IN | 2 | 101.98 | 5.90 |
| CR-IS | 2 | 103.74 | 0.00 |

### Equipment rates used ($/h)

| ID | Description | Source | Rate |
|---|---|---|---|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET, 22.50' MAX DIGGING DEPTH | EP 1110-1-8 Region VII, fuel/FOG adjusted | 58.68 |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH, WALK BEHIND, CRAWLER | EP 1110-1-8 Region VII, fuel/FOG adjusted | 14.61 |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY FRONT END BUCKET, 24" DIP, 14.5' DIGGING DEPTH, 4X2 | EP 1110-1-8 Region VII, fuel/FOG adjusted | 30.98 |
| C10BO003 | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS IMPACT | EP 1110-1-8 Region VII, fuel/FOG adjusted | 2.90 |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON, 72' BOOM, 4X4 | EP 1110-1-8 Region VII, fuel/FOG adjusted | 61.06 |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA, 425 GPM @ 95' HEAD | EP 1110-1-8 Region VII, fuel/FOG adjusted | 3.85 |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | RQ-26-0419 | 96.00 |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb with dynamometer | RQ-26-0419 | 58.50 |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | RQ-26-0419 | 11.80 |
| RQ-TBX | Trench shield (box), 8 ft x 20 ft, steel, with spreaders | RQ-26-0419 | 7.25 |

### Principal material unit costs used (delivered, incl. waste, index and tax)

| Code | Unit | Quote price | Unit cost used |
|---|---|---|---|
| CBL-250 | LF | 6.20 | 7.16 |
| CBL-350 | LF | 7.45 | 8.60 |
| CBL-500 | LF | 9.10 | 10.51 |
| CBL-750 | LF | 12.40 | 14.32 |
| ACSR-1/0 | LF | 0.62 | 0.71 |
| ACSR-336.4 | LF | 1.72 | 1.97 |
| EB20-5 | LF | 4.15 | 4.77 |
| EB20-6 | LF | 5.60 | 6.44 |
| SCH40-5 | LF | 8.90 | 10.23 |
| RGS-5 | LF | 61.00 | 70.13 |
| CONC-3000 | CY | 212.00 | 250.71 |
| REBAR-4 | LB | 1.18 | 1.36 |
| SAND | CY | 48.00 | 57.82 |
| GND-4/0 | LF | 7.90 | 9.12 |
| MH-PRECAST | EA | 16850.00 | 18450.75 |
| TERM-KIT | EA | 265.00 | 290.18 |
| POLE-45 | EA | 1480.00 | 1620.60 |
| POLE-50 | EA | 1760.00 | 1927.20 |
| RISER-ASSY | EA | 3950.00 | 4325.25 |
| TRAY-24-SB | LF | 38.00 | 43.69 |

## 3. Item studies

### C01 - SS-1 F1 to MB-1 MSG-A

**Recommendation: CEDB** - PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2); 2 set(s) of 500 kcmil 15 kV Al MV-105. Design current 640 A (PDS Rev D phase pickup); governing ampacity 331.5 A per set (ductbank 2 circ rho131 d18) x 2 = 663.1 A. Route length 857.3 ft; total project cost $278,499 ($324.86/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 280.00,640.00; 330.00,640.00; 420.00,730.00; 700.00,730.00 | 18 | 1 x 3, 6 in, 1 spare | N | B | none | N |
| 2 | CE | 700.00,730.00; 750.00,730.00 | 18 | 1 x 3, 6 in, 1 spare | N | B | none | N |
| 3 | HDD | 750.00,730.00; 800.00,730.00 | 84 | 1 x 3, 6 in, 1 spare | N |  | none | N |
| 4 | CE | 800.00,730.00; 1100.00,730.00 | 18 | 1 x 3, 6 in, 1 spare | N | B | none | N |

Structures: MH-01 MH (700.0, 730.0) excavation 8 ft, trench shield.


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 6,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C01-P1 | START | MH-01 | 457.3 | START | 1360 | 32 | 2973 | 3.82 | 20.6 |
| C01-P2 | MH-01 | END | 400.0 | END | 908 | 32 | 1555 | 3.30 | 27.5 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 100 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-2,B-3,B-4 | 131 (table 150) | 2 | 18 (table 30) | 331.5 |
| 2 | CE | B-4 | 104 (table 120) | 2 | 18 (table 30) | 360.4 |
| 3 | HDD | B-4 | 104 (table 120) | 1 | 84 (table 120) | 331.5 (bore, excluded: bores <= 25 pct of run) |
| 4 | CE | B-4 | 104 (table 120) | 2 | 18 (table 30) | 360.4 |

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 500 x 2 | 857.3 | 613.6 | 52,508 | 85.57 | 10,622 | 119,571 | 14,000 | 196,701 | 278,499 | 324.86 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 500 x 2 | 857.3 | 568.7 | 48,876 | 85.94 | 10,993 | 126,524 | 14,000 | 200,393 | 283,726 | 330.96 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 500 x 2 | 857.3 | 334.2 | 28,887 | 86.44 | 6,900 | 80,295 | 14,000 | 130,082 | 184,176 | 214.84 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 250 x 3 | 857.3 | 669.6 | 57,944 | 86.53 | 15,271 | 82,247 | 136,992 | 292,453 | 414,070 | 483.00 |
| OH | N | PCSFA-IEDS Rev 3 para 4.1 / UFC 3-550-01 para 3-11.1.1: overhead not permitted inside the congested industrial area (C-101) where the load terminal lies | 500 x 2 + 336.4 ACSR | 857.3 | 411.4 | 36,296 | 88.23 | 9,876 | 70,767 | 0 | 116,939 | 165,568 | 193.13 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 6.0 | 5.1 | 1.3 | 1.3 | 0.3 |
| CR-CO | 81.26 | 0.00 | 49.7 | 0.0 | 0.0 | 0.0 | 3.7 |
| CR-BF | 83.86 | 11.29 | 17.8 | 52.7 | 14.2 | 2.8 | 1.0 |
| CR-DU | 83.61 | 0.00 | 89.2 | 59.8 | 0.0 | 0.0 | 6.6 |
| CR-MH | 84.92 | 15.26 | 22.0 | 22.0 | 22.0 | 22.0 | 0.0 |
| CR-CP | 86.21 | 25.75 | 384.9 | 384.9 | 245.1 | 577.3 | 75.3 |
| CR-SP | 90.00 | 0.00 | 44.2 | 44.2 | 44.2 | 66.2 | 38.4 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 7.4 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 98.7 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 62.6 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 11.4 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 113.4 |
| **Total** | | | 613.6 | 568.7 | 334.2 | 669.6 | 411.4 |

Estimate roll-up of the recommended design: direct $196,701; JOOH $18,687; HOOH $9,692; profit $17,893; bond $3,189; escalation $4,772; contract $250,934; contingency $12,547; SIOH $15,018; **total project cost $278,499**.

Route east from the F1 stub-out, 45-degree long sweeps to y = 730 (clear of T-201 TPZ and 30 ft south of P-1), HDD under Mission Dr (10 ft beyond each edge, 84 in cover to clear W-12 at 56-68.75 in by 12 in), shallow crossing over SD-30 (bottom of 1 x 3 envelope 30.6 in vs top of pipe 60 in) and perpendicular entry into the MSG-A zone at (1100, 730), 18 ft south of T-207 TPZ. One manhole at (700, 730): 67 ft from P-1, 60 ft from Mission Dr, 228 ft from FP-1. B-3 (131 C-cm/W, 150 table) governs ampacity; 2 x 500 kcmil in 6 in EB-20 (D/d 3.82, also in Sch 40 risers 3.70 and HDPE-6 bore 3.31 / 27.5 % fill).

### C02 - SS-1 F2 to MB-1 MSG-B

**Recommendation: OH** - PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route; 2 set(s) of 350 kcmil 15 kV Al MV-105, overhead 336.4 ACSR x 2 circuit(s). Design current 560 A (PDS Rev D phase pickup); governing ampacity 299.1 A per set (ductbank 2 circ rho101 d18) x 2 = 598.3 A. Route length 1,338.2 ft; total project cost $233,361 ($174.39/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 280.00,520.00; 290.00,510.00; 290.00,400.00 | 18 | 3 x 1, 5 in, 1 spare | N | B | none | N |
| 2 | CE | 290.00,400.00; 290.00,290.00 | 18 | 3 x 1, 5 in, 1 spare | N | B | none | N |
| 3 | OH | 290.00,290.00; 517.50,290.00 |  |  | N |  | none | N |
| 4 | OH | 517.50,290.00; 745.00,290.00 |  |  | N |  | none | N |
| 5 | OH | 745.00,290.00; 972.50,290.00 |  |  | N |  | none | N |
| 6 | OH | 972.50,290.00; 1200.00,290.00 |  |  | N |  | none | N |
| 7 | OH | 1200.00,290.00; 1330.00,390.00 |  |  | N |  | none | N |
| 8 | CE | 1330.00,390.00; 1330.00,420.00 | 18 | 3 x 1, 5 in, 1 spare | N | B | none | N |

Structures: MH-1 MH (290.0, 400.0) excavation 8 ft, trench shield; RP-01 RISER_POLE (290.0, 290.0) 45 ft, 1 guy(s), dead-end Y; P-02 POLE (517.5, 290.0) 45 ft, 0 guy(s), dead-end N; P-03 POLE (745.0, 290.0) 50 ft, 0 guy(s), dead-end N; P-04 POLE (972.5, 290.0) 50 ft, 0 guy(s), dead-end N; P-05 POLE (1200.0, 290.0) 45 ft, 1 guy(s), dead-end N; RP-06 RISER_POLE (1330.0, 390.0) 45 ft, 1 guy(s), dead-end Y.


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 4,200 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C02-P1 | START | MH-1 | 124.1 | START | 465 | 35 | 758 | 3.51 | 24.4 |
| C02-P2 | MH-1 | RP-01 | 110.0 | RP-01 | 358 | 35 | 514 | 3.51 | 24.4 |
| C02-P3 | RP-06 | END | 30.0 | RP-06 | 466 | 85 | 466 | 3.51 | 24.4 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 100 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-12,B-2 | 101 (table 120) | 2 | 18 (table 30) | 299.1 |
| 2 | CE | B-12 | 101 (table 120) | 2 | 18 (table 30) | 299.1 |
| 8 | CE | B-9 | 112 (table 120) | 2 | 18 (table 30) | 299.1 |

Overhead: 336.4 ACSR Linnet, 428 A at 40 C per circuit; 2 circuit(s); max span 250 ft (IEDS 4.9); conductor design tension 25 % of RBS = 3525 lb (<= 50 % RBS and <= 4,750 lb, UFC 3-550-01 3-10).

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 500 x 2 | 1,204.1 | 864.6 | 73,901 | 85.48 | 15,047 | 178,136 | 14,000 | 281,084 | 397,973 | 330.50 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 500 x 2 | 1,204.1 | 800.3 | 68,709 | 85.85 | 15,578 | 188,075 | 14,000 | 286,362 | 405,446 | 336.71 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 350 x 2 | 1,204.1 | 464.8 | 40,105 | 86.29 | 9,722 | 107,632 | 14,000 | 171,460 | 242,761 | 201.61 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 500 x 2 | 1,204.1 | 638.0 | 55,112 | 86.39 | 14,609 | 120,307 | 143,598 | 333,627 | 472,365 | 392.28 |
| OH (rec.) | Y | PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route | 350 x 2 + 336.4 ACSR | 1,338.2 | 577.8 | 50,372 | 87.17 | 12,224 | 102,225 | 0 | 164,821 | 233,361 | 174.39 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 9.2 | 8.1 | 2.6 | 2.6 | 2.5 |
| CR-CO | 81.26 | 0.00 | 71.0 | 0.0 | 0.0 | 0.0 | 14.1 |
| CR-BF | 83.86 | 11.29 | 27.0 | 76.9 | 21.6 | 5.6 | 6.7 |
| CR-DU | 83.61 | 0.00 | 127.5 | 85.5 | 0.0 | 0.0 | 29.2 |
| CR-MH | 84.92 | 15.26 | 44.0 | 44.0 | 44.0 | 44.0 | 22.0 |
| CR-CP | 86.21 | 25.75 | 535.9 | 535.9 | 336.1 | 535.9 | 165.3 |
| CR-SP | 90.00 | 0.00 | 49.9 | 49.9 | 49.9 | 49.9 | 44.2 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 10.6 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 87.1 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 45.6 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 8.5 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 152.7 |
| **Total** | | | 864.6 | 800.3 | 464.8 | 638.0 | 577.8 |

Estimate roll-up of the recommended design: direct $164,821; JOOH $15,658; HOOH $8,122; profit $14,993; bond $2,672; escalation $3,999; contract $210,264; contingency $10,513; SIOH $12,584; **total project cost $233,361**.

OH is permitted (MSG-B entry on the south wall lies outside the industrial area) and is cheaper than the CEDB alternative by more than 40 %. Underground riser run from F2 west of the T-2 end, manhole MH-1 (124 ft from the stub-out, 110 ft to the riser pole), riser pole RP-01 at (290, 290) outside the industrial area; pole line along y = 290 (spans 227.5 ft, 50 ft poles on the Mission Dr span), corner pole P-05 guyed (37.6 deg), riser pole RP-06 30 ft south of MB-1 and a 30 ft riser run into the MSG-B zone. 2 circuits of 336.4 ACSR (428 A each at 40 C; a single 477 ACSR circuit gives only 532 A < 560 A at 40 C) and 2 sets of 350 kcmil underground (299 A per set, 2 circuits in bank, B-2/B-12 rho 120). Double-circuit take-off: crossarms per circuit (2 per tangent pole, 4 per dead-end), conductor-feet = 3 x OH length x 1.015 per circuit, RISER per circuit per riser pole.

### C03 - SS-1 F3 to CUP-1 SWG-C1

**Recommendation: CEDB** - PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2); 1 set(s) of 500 kcmil 15 kV Al MV-105. Design current 400 A (PDS Rev D phase pickup); governing ampacity 466.1 A per set (ductbank 1 circ rho85 d53) x 1 = 466.1 A. Route length 353.8 ft; total project cost $74,602 ($210.84/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 240.00,700.00; 295.00,756.20 | 18 | 2 x 1, 6 in, 1 spare | N | B | none | N |
| 2 | CE | 295.00,756.20; 440.60,905.00 | 24 | 2 x 1, 6 in, 1 spare | Y | B | none | N |
| 3 | CE | 440.60,905.00; 470.00,935.00; 470.00,960.00 | 53 | 2 x 1, 6 in, 1 spare | N | B | box | N |

Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 6,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C03-P1 | START | END | 353.8 | END | 1748 | 292 | 2139 | 3.82 | 20.6 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 75 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-1 | 88 (table 90) | 1 | 18 (table 30) | 490.1 |
| 2 | CE | B-1,B-6 | 88 (table 90) | 1 | 24 (table 30) | 490.1 |
| 3 | CE | B-6 | 85 (table 90) | 1 | 53 (table 72) | 466.1 |

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 500 x 1 | 353.8 | 211.7 | 18,002 | 85.02 | 2,875 | 31,814 | 0 | 52,691 | 74,602 | 210.84 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 500 x 1 | 353.8 | 206.4 | 17,570 | 85.13 | 2,922 | 32,668 | 0 | 53,161 | 75,267 | 212.73 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 350 x 1 | 353.8 | 176.7 | 15,051 | 85.20 | 2,452 | 23,181 | 0 | 40,685 | 57,603 | 162.80 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 500 x 1 | 353.8 | 102.6 | 8,920 | 86.92 | 2,148 | 14,029 | 31,441 | 56,539 | 80,051 | 226.24 |
| OH | N | PCSFA-IEDS Rev 3 para 4.1 / UFC 3-550-01 para 3-11.1.1: overhead not permitted inside the congested industrial area (C-101) where the load terminal lies | 350 x 1 + 336.4 ACSR | 353.8 | 155.9 | 13,786 | 88.45 | 3,527 | 28,572 | 0 | 45,885 | 64,966 | 183.61 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 3.8 | 3.6 | 0.9 | 0.0 | 0.2 |
| CR-CO | 81.26 | 0.00 | 23.6 | 17.3 | 15.9 | 0.0 | 2.3 |
| CR-BF | 83.86 | 11.29 | 54.4 | 59.2 | 52.4 | 0.0 | 0.8 |
| CR-DU | 83.61 | 0.00 | 27.2 | 23.7 | 16.0 | 0.0 | 4.6 |
| CR-CP | 86.21 | 25.75 | 83.4 | 83.4 | 70.8 | 83.4 | 37.7 |
| CR-SP | 90.00 | 0.00 | 19.2 | 19.2 | 19.2 | 19.2 | 19.2 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 1.3 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 47.4 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 17.1 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 5.7 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 20.9 |
| **Total** | | | 211.7 | 206.4 | 176.7 | 102.6 | 155.9 |

Estimate roll-up of the recommended design: direct $52,691; JOOH $5,006; HOOH $2,596; profit $4,793; bond $854; escalation $1,278; contract $67,218; contingency $3,361; SIOH $4,023; **total project cost $74,602**.

Direct diagonal route across P-1 (saw-cut, reinforced envelope extended 5 ft beyond the paving, 24 in cover), then deep crossing under G-4 (top of envelope 53 in, 12 in below the 40.5 in bottom of the gas line; trench 78 in deep in Type B soil protected by trench shield) and perpendicular entry into the SWG-C1 south zone. Single pull of 354 ft, no manhole. The 72 in depth factor governs: 466 A for 1 x 500 kcmil (load factor 75 %).

### C04 - CUP-1 CF-2 to TX-LS2

**Recommendation: OH** - PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route; 1 set(s) of 250 kcmil 15 kV Al MV-105, overhead 1/0 ACSR x 1 circuit(s). Design current 60 A (PDS Rev D phase pickup); governing ampacity 196.0 A per set (ACSR 1/0 40C) x 1 = 196.0 A. Route length 1,408.7 ft; total project cost $204,876 ($145.44/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 600.00,1005.00; 705.00,1005.00 | 24 | 2 x 1, 5 in, 1 spare | Y | C | none | N |
| 2 | CE | 705.00,1005.00; 750.00,1005.00 | 18 | 2 x 1, 5 in, 1 spare | N | C | none | N |
| 3 | HDD | 750.00,1005.00; 800.00,1005.00 | 84 | 1 x 2, 5 in, 1 spare | N |  | none | N |
| 4 | CE | 800.00,1005.00; 940.50,1005.00 | 18 | 2 x 1, 5 in, 1 spare | N | C | none | N |
| 5 | CE | 940.50,1005.00; 1100.00,1005.00; 1160.00,945.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |
| 6 | CE | 1160.00,945.00; 1160.00,875.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |
| 7 | OH | 1160.00,875.00; 1360.00,872.50 |  |  | N |  | none | N |
| 8 | OH | 1360.00,872.50; 1560.00,870.00 |  |  | N |  | none | N |
| 9 | OH | 1560.00,870.00; 1670.00,1039.71 |  |  | N |  | none | N |
| 10 | OH | 1670.00,1039.71; 1735.00,1140.00 |  |  | N |  | none | N |
| 11 | CE | 1735.00,1140.00; 1760.00,1160.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |

Structures: MH-1 MH (1160.0, 945.0) excavation 8 ft, trench shield; RP-01 RISER_POLE (1160.0, 875.0) 45 ft, 1 guy(s), dead-end Y; P-02 POLE (1360.0, 872.5) 45 ft, 0 guy(s), dead-end N; P-03 POLE (1560.0, 870.0) 45 ft, 1 guy(s), dead-end N; P-04 POLE (1670.0, 1039.7) 45 ft, 0 guy(s), dead-end N; RP-05 RISER_POLE (1735.0, 1140.0) 45 ft, 1 guy(s), dead-end Y.


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 3,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C04-P1 | START | MH-1 | 584.9 | START | 1162 | 32 | 1628 | 3.27 | 28.0 |
| C04-P2 | MH-1 | RP-01 | 70.0 | RP-01 | 272 | 32 | 346 | 3.79 | 20.9 |
| C04-P3 | RP-05 | END | 32.0 | RP-05 | 434 | 73 | 434 | 3.79 | 20.9 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 75 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-7 | 69 (table 90) | 1 | 24 (table 30) | 345.1 |
| 2 | CE | B-7 | 69 (table 90) | 1 | 18 (table 30) | 345.1 |
| 3 | HDD | B-7 | 69 (table 90) | 1 | 84 (table 120) | 286.7 (bore, excluded: bores <= 25 pct of run) |
| 4 | CE | B-7,B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |
| 5 | CE | B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |
| 6 | CE | B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |
| 11 | CE | B-11 | 90 (table 90) | 1 | 18 (table 30) | 345.1 |

Overhead: 1/0 ACSR Raven, 196 A at 40 C per circuit; 1 circuit(s); max span 300 ft (IEDS 4.9); conductor design tension 25 % of RBS = 1095 lb (<= 50 % RBS and <= 4,750 lb, UFC 3-550-01 3-10).

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 250 x 1 | 1,268.1 | 529.7 | 45,142 | 85.23 | 8,623 | 104,671 | 29,704 | 188,140 | 266,378 | 210.05 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 250 x 1 | 1,268.1 | 498.8 | 42,656 | 85.52 | 8,941 | 108,487 | 29,704 | 189,788 | 268,712 | 211.89 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 250 x 1 | 1,268.1 | 339.2 | 29,073 | 85.72 | 6,414 | 74,645 | 29,704 | 139,835 | 197,986 | 156.12 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 250 x 1 | 1,268.1 | 358.7 | 30,945 | 86.26 | 8,062 | 67,609 | 109,535 | 216,151 | 306,037 | 241.33 |
| OH (rec.) | Y | PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route | 250 x 1 + 1/0 ACSR | 1,408.7 | 449.9 | 38,840 | 86.32 | 8,464 | 83,397 | 14,000 | 144,702 | 204,876 | 145.44 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 6.7 | 5.8 | 3.0 | 2.6 | 3.8 |
| CR-CO | 81.26 | 0.00 | 44.9 | 8.0 | 8.0 | 0.0 | 28.2 |
| CR-BF | 83.86 | 11.29 | 44.4 | 75.0 | 44.7 | 5.6 | 35.7 |
| CR-DU | 83.61 | 0.00 | 83.0 | 59.4 | 8.1 | 0.0 | 49.0 |
| CR-MH | 84.92 | 15.26 | 44.0 | 44.0 | 44.0 | 44.0 | 22.0 |
| CR-CP | 86.21 | 25.75 | 281.7 | 281.7 | 197.4 | 281.7 | 173.1 |
| CR-SP | 90.00 | 0.00 | 25.0 | 25.0 | 25.0 | 25.0 | 22.1 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 9.0 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 51.3 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 19.9 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 8.5 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 36.3 |
| **Total** | | | 529.7 | 498.8 | 339.2 | 358.7 | 449.9 |

Estimate roll-up of the recommended design: direct $144,702; JOOH $13,747; HOOH $7,130; profit $13,163; bond $2,346; escalation $3,511; contract $184,598; contingency $9,230; SIOH $11,048; **total project cost $204,876**.

OH is permitted (TX-LS2 lies outside the industrial area) and is cheaper than CEDB. Underground from the SWG-C1 east zone through the CUP yard (reinforced, 24 in), HDD under Mission Dr, east along y = 1005 (25 ft south of T-203 TPZ, over SD-30) to MH-1 at (1160, 945) and riser pole RP-01 at (1160, 875) east of the G-4 end and outside the industrial area; pole line north of MB-1 (y 870-875, 50 ft from the building, clear of T-209 TPZ), angle pole at (1560, 870) guyed (57.8 deg), span over the DC-1 channel buffer to P-04 at (1670, 1039.7) and riser pole RP-05 at (1735, 1140), 32 ft riser run to TX-LS2. OH 722 ft is the predominant method (underground 682 ft).

### C05 - MSG-A A-3 to USS-A1 (in MB-1)

**Recommendation: RMC** - UFGS 26 20 00 para 3.1.6.7 (rigid metal conduit or IMC for circuits >600 V) and UFC 3-520-01 Table 3-1 (Art. 328/344); 6 in space available on route (A-501, PCSFA-IEDS 5.1); 2 set(s) of 250 kcmil 15 kV Al MV-105. Design current 200 A (PDS Rev D phase pickup); governing ampacity 160.0 A per set (air conduit in air 40C) x 2 = 320.0 A. Route length 400.0 ft; total project cost $211,605 ($529.01/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | RMC | 1130.00,730.00; 1130.00,695.00; 1300.00,695.00 |  |  | N |  | none | N |
| 2 | RMC | 1300.00,695.00; 1440.00,695.00; 1440.00,640.00 |  |  | N |  | none | N |

Structures: PB-1A PULLBOX (1300.0, 695.0); PB-1B PULLBOX (1300.0, 695.0).


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 3,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C05-P1 | START | PB-1A | 205.0 | START | 779 | 96 | 1583 | 3.63 | 22.8 |
| C05-P2 | PB-1A | END | 195.0 | END | 796 | 106 | 1458 | 3.63 | 22.8 |
| C05-P3 | START | PB-1B | 205.0 | START | 779 | 96 | 1583 | 3.63 | 22.8 |
| C05-P4 | PB-1B | END | 195.0 | END | 796 | 106 | 1458 | 3.63 | 22.8 |

Ampacity: conduit in air at 40 C (TD-15AL-133 Air table): 250 kcmil 160 A per set x 2 = 320 A >= 200 A; 350 kcmil 195 A < 200 A; 500 kcmil jams in 5 in RGS (D/d 3.08). Short circuit 15.8 kA for 0.5 s: 250 kcmil 16.6 kA.

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| RMC (rec.) | Y | UFGS 26 20 00 para 3.1.6.7 (rigid metal conduit or IMC for circuits >600 V) and UFC 3-520-01 Table 3-1 (Art. 328/344); 6 in space available on route (A-501, PCSFA-IEDS 5.1) | 250 x 2 | 400.0 | 536.5 | 54,784 | 102.10 | 2,939 | 91,732 | 0 | 149,454 | 211,605 | 529.01 |
| EMT | N | UFGS 26 20 00 para 3.1.6.7: conduit for circuits rated greater than 600 V shall be rigid metal conduit or IMC only (EMT also excluded in equipment rooms, 3.1.6.2 c) | 250 x 2 | 400.0 | 425.6 | 43,469 | 102.14 | 2,284 | 47,750 | 0 | 93,503 | 132,386 | 330.97 |
| TRAY-EN | N | PCSFA-IEDS Rev 3 para 5.1 with A-501 Rev 1: tray needs 6 in + 12 in headroom = 18 in; COR-1D (14 in) and MR-2 (16 in) block every tray route from ER-A to MR-1 (SCIF keep-out excludes others) | 250 x 2 | 400.0 | 432.3 | 44,153 | 102.13 | 2,324 | 55,789 | 0 | 102,267 | 144,794 | 361.99 |
| TRAY-LD | N | UFC 3-520-01 (2025) Table 3-1 Art. 328: interior MV cable only in raceway or fully enclosed cable tray (ladder tray not enclosed); also IEDS 5.1 space (COR-1D 14 in, MR-2 16 in) | 250 x 2 | 400.0 | 408.3 | 41,706 | 102.14 | 2,182 | 45,901 | 0 | 89,790 | 127,129 | 317.82 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | RMC | EMT | TRAY-EN | TRAY-LD |
|---|---|---|---|---|---|---|
| CR-IN | 101.98 | 5.90 | 498.1 | 387.2 | 393.9 | 369.9 |
| CR-IS | 103.74 | 0.00 | 38.4 | 38.4 | 38.4 | 38.4 |
| **Total** | | | 536.5 | 425.6 | 432.3 | 408.3 |

Estimate roll-up of the recommended design: direct $149,454; JOOH $14,198; HOOH $7,364; profit $13,595; bond $2,423; escalation $3,626; contract $190,661; contingency $9,533; SIOH $11,411; **total project cost $211,605**.

Rigid steel conduit route through ER-A, MR-2 (16 in available >= 6 in required) and MR-1, 25 ft from the SCIF wall; two 5 in RGS conduits each with one set of 250 kcmil (conduit-in-air 160 A at 40 C, 2 sets = 320 A; 350 kcmil 195 A < 200 A; 500 kcmil jams in 5 in RGS, D/d 3.08). Firestops at the two 2-hour walls (x = 1160, x = 1400), one pull box per conduit at (1300, 695) so that each pull has 180 degrees of bends, 15 seismic braces. Tray types are blocked by the 14 in / 16 in ceiling spaces at COR-1D and MR-2 (18 in required); EMT is not allowed above 600 V.

### C06 - SS-1 F4 to TX-GH1

**Recommendation: OH** - PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route; 1 set(s) of 250 kcmil 15 kV Al MV-105, overhead 1/0 ACSR x 1 circuit(s). Design current 40 A (PDS Rev D phase pickup); governing ampacity 196.0 A per set (ACSR 1/0 40C) x 1 = 196.0 A. Route length 1,817.4 ft; total project cost $110,413 ($60.75/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 180.00,480.00; 205.00,284.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |
| 2 | OH | 205.00,284.00; 467.50,264.17 |  |  | N |  | none | N |
| 3 | OH | 467.50,264.17; 730.00,244.33 |  |  | N |  | none | N |
| 4 | OH | 730.00,244.33; 992.50,224.50 |  |  | N |  | none | N |
| 5 | OH | 992.50,224.50; 1255.00,204.67 |  |  | N |  | none | N |
| 6 | OH | 1255.00,204.67; 1517.50,184.83 |  |  | N |  | none | N |
| 7 | OH | 1517.50,184.83; 1780.00,165.00 |  |  | N |  | none | N |
| 8 | CE | 1780.00,165.00; 1800.00,130.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |

Structures: RP-01 RISER_POLE (205.0, 284.0) 45 ft, 1 guy(s), dead-end Y; P-02 POLE (467.5, 264.2) 45 ft, 0 guy(s), dead-end N; P-03 POLE (730.0, 244.3) 50 ft, 0 guy(s), dead-end N; P-04 POLE (992.5, 224.5) 50 ft, 0 guy(s), dead-end N; P-05 POLE (1255.0, 204.7) 45 ft, 0 guy(s), dead-end N; P-06 POLE (1517.5, 184.8) 45 ft, 0 guy(s), dead-end N; RP-07 RISER_POLE (1780.0, 165.0) 45 ft, 1 guy(s), dead-end Y.


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 3,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C06-P1 | START | RP-01 | 197.6 | START | 803 | 135 | 803 | 3.79 | 20.9 |
| C06-P2 | RP-07 | END | 40.3 | RP-07 | 452 | 76 | 452 | 3.79 | 20.9 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 75 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-12,B-2 | 101 (table 120) | 1 | 18 (table 30) | 330.5 |
| 8 | CE | B-9 | 112 (table 120) | 1 | 18 (table 30) | 330.5 |

Overhead: 1/0 ACSR Raven, 196 A at 40 C per circuit; 1 circuit(s); max span 300 ft (IEDS 4.9); conductor design tension 25 % of RBS = 1095 lb (<= 50 % RBS and <= 4,750 lb, UFC 3-550-01 3-10).

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 250 x 1 | 1,817.4 | 739.8 | 63,018 | 85.18 | 11,990 | 155,286 | 14,000 | 244,294 | 345,884 | 190.32 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 250 x 1 | 1,817.4 | 683.8 | 58,504 | 85.56 | 12,568 | 162,217 | 14,000 | 247,288 | 350,123 | 192.65 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 250 x 1 | 1,817.4 | 393.9 | 33,836 | 85.90 | 7,979 | 100,794 | 14,000 | 156,609 | 221,734 | 122.01 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 250 x 1 | 1,817.4 | 506.5 | 43,657 | 86.20 | 11,527 | 98,334 | 155,360 | 308,878 | 437,324 | 240.63 |
| OH (rec.) | Y | PCSFA-IEDS Rev 3 para 4.1: overhead permitted outside the industrial area (C-101 ADP 2024) with underground risers; load terminal outside industrial area, OH predominant on the route | 250 x 1 + 1/0 ACSR | 1,817.4 | 296.1 | 25,871 | 87.38 | 6,365 | 45,747 | 0 | 77,984 | 110,413 | 60.75 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 10.6 | 8.9 | 3.8 | 3.8 | 0.9 |
| CR-CO | 81.26 | 0.00 | 66.9 | 0.0 | 0.0 | 0.0 | 9.0 |
| CR-BF | 83.86 | 11.29 | 31.9 | 87.5 | 32.5 | 8.3 | 3.2 |
| CR-DU | 83.61 | 0.00 | 136.1 | 93.2 | 0.0 | 0.0 | 18.3 |
| CR-MH | 84.92 | 15.26 | 66.0 | 66.0 | 66.0 | 66.0 | 0.0 |
| CR-CP | 86.21 | 25.75 | 400.5 | 400.5 | 247.5 | 400.5 | 75.7 |
| CR-SP | 90.00 | 0.00 | 27.8 | 27.8 | 27.8 | 27.8 | 19.2 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 16.3 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 59.0 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 25.6 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 5.7 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 79.4 |
| **Total** | | | 739.8 | 683.8 | 393.9 | 506.5 | 296.1 |

Estimate roll-up of the recommended design: direct $77,984; JOOH $7,408; HOOH $3,843; profit $7,094; bond $1,264; escalation $1,892; contract $99,485; contingency $4,974; SIOH $5,954; **total project cost $110,413**.

OH is permitted (TX-GH1 lies south of the industrial area) and is far cheaper than CEDB. 198 ft underground riser run from the F4 stub-out (20 ft outside the T-208 TPZ, over SS-8) to riser pole RP-01 at (205, 284); straight tangent line of six 263 ft spans to RP-07 at (1780, 165) south of the DC-1 buffer, 50 ft poles at the Mission Dr span; 40 ft riser run to TX-GH1. 1/0 ACSR (196 A at 40 C) and 250 kcmil underground (short-circuit minimum).

### C07 - CUP-1 CF-1 to TX-W3

**Recommendation: CEDB** - PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2); 1 set(s) of 250 kcmil 15 kV Al MV-105. Design current 120 A (PDS Rev D phase pickup); governing ampacity 330.5 A per set (ductbank 1 circ rho99 d18) x 1 = 330.5 A. Route length 680.0 ft; total project cost $140,629 ($206.81/LF).

Design (segments from the source end):

| # | Method | Route (x,y) | Cover (in) | Ducts (r x c, size, spare) | Reinf. | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|
| 1 | CE | 470.00,1060.00; 470.00,1086.00; 750.00,1086.00 | 18 | 2 x 1, 5 in, 1 spare | N | C | none | N |
| 2 | HDD | 750.00,1086.00; 800.00,1086.00 | 84 | 1 x 2, 5 in, 1 spare | N |  | none | N |
| 3 | CE | 800.00,1086.00; 951.10,1086.00 | 18 | 2 x 1, 5 in, 1 spare | N | C | none | N |
| 4 | CE | 951.10,1086.00; 1030.00,1086.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |
| 5 | CE | 1030.00,1086.00; 1030.00,1180.00 | 18 | 2 x 1, 5 in, 1 spare | N | B | none | N |

Structures: MH-A MH (1030.0, 1086.0) excavation 8 ft, trench shield.


Cable pulling (feed-in 100 lb, approved SWBP limit 600 lb/ft, tension limit 3,000 lb):

| Pull | From | To | Length (ft) | Feed end | Max tension (lb) | Max SWBP (lb/ft) | Tension other direction (lb) | Jam ratio | Fill (%) |
|---|---|---|---|---|---|---|---|---|---|
| C07-P1 | START | MH-A | 586.0 | START | 1070 | 32 | 2778 | 3.27 | 28.0 |
| C07-P2 | MH-A | END | 94.0 | END | 300 | 32 | 400 | 3.79 | 20.9 |

Ampacity check along the route (per set, TD-15AL-133 tables, earth 25 C, load factor 75 %):

| Segment | Method | Nearest borings | rho used (C-cm/W) | Circuits | Depth (in) | Ampacity/set (A) |
|---|---|---|---|---|---|---|
| 1 | CE | B-7 | 69 (table 90) | 1 | 18 (table 30) | 345.1 |
| 2 | HDD | B-7 | 69 (table 90) | 1 | 84 (table 120) | 286.7 (bore, excluded: bores <= 25 pct of run) |
| 3 | CE | B-7,B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |
| 4 | CE | B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |
| 5 | CE | B-8 | 99 (table 120) | 1 | 18 (table 30) | 330.5 |

Conveyance types evaluated (labor hours, rates and cost per linear foot):

| Type | Permitted | Deciding clause | Cable x sets | Length (ft) | Labor MH | Labor $ | Avg labor $/MH | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB (rec.) | Y | PCSFA-IEDS Rev 3 para 4.2 and UFC 3-550-01 (2016 C3) para 3-11.2.1: primary circuits in concrete-encased ductbank (crossings by HDD per IEDS 4.3 / UFC 3-11.2.2) | 250 x 1 | 680.0 | 285.8 | 24,418 | 85.43 | 4,549 | 56,358 | 14,000 | 99,325 | 140,629 | 206.81 |
| UEDB | N | PCSFA-IEDS Rev 3 para 4.2: conduit without concrete encasement not permitted for primary distribution (UFC 3-550-01 para 3-11.2.1 concrete encasement) | 250 x 1 | 680.0 | 265.9 | 22,809 | 85.79 | 4,754 | 58,829 | 14,000 | 100,392 | 142,140 | 209.03 |
| DBC | N | PCSFA-IEDS Rev 3 para 4.2: direct-buried cable not permitted; UFC 3-550-01 para 3-11.3.1: not authorized for base core distribution | 250 x 1 | 680.0 | 162.5 | 14,015 | 86.24 | 3,119 | 36,925 | 14,000 | 68,058 | 96,361 | 141.71 |
| HDD | N | UFC 3-550-01 (2016 C3) para 3-11.4.1: directional boring authorized only for crossings, not in lieu of concrete encasement; PCSFA-IEDS Rev 3 para 4.3: bore not more than 50 ft beyond pavement edge/channel bank | 250 x 1 | 680.0 | 202.6 | 17,516 | 86.44 | 4,383 | 36,048 | 62,530 | 120,477 | 170,577 | 250.85 |
| OH | N | PCSFA-IEDS Rev 3 para 4.1 / UFC 3-550-01 para 3-11.1.1: overhead not permitted inside the congested industrial area (C-101) where the load terminal lies and W-3 dock crane area | 250 x 1 + 1/0 ACSR | 680.0 | 181.4 | 16,081 | 88.65 | 4,272 | 31,385 | 0 | 51,739 | 73,254 | 107.73 |

Labor hours by crew (MH) and crew rates used:

| Crew | Labor $/MH | Equip $/MH | CEDB | UEDB | DBC | HDD | OH |
|---|---|---|---|---|---|---|---|
| CR-EX | 83.84 | 29.34 | 3.7 | 3.1 | 1.3 | 1.3 | 0.2 |
| CR-CO | 81.26 | 0.00 | 23.9 | 0.0 | 0.0 | 0.0 | 2.3 |
| CR-BF | 83.86 | 11.29 | 11.2 | 31.0 | 11.4 | 2.8 | 0.8 |
| CR-DU | 83.61 | 0.00 | 48.5 | 33.2 | 0.0 | 0.0 | 4.6 |
| CR-MH | 84.92 | 15.26 | 22.0 | 22.0 | 22.0 | 22.0 | 0.0 |
| CR-CP | 86.21 | 25.75 | 154.5 | 154.5 | 100.0 | 154.5 | 37.7 |
| CR-SP | 90.00 | 0.00 | 22.1 | 22.1 | 22.1 | 22.1 | 19.2 |
| CR-TM | 82.57 | 7.31 | 0.0 | 0.0 | 5.8 | 0.0 | 0.0 |
| CR-OH | 90.00 | 24.00 | 0.0 | 0.0 | 0.0 | 0.0 | 51.3 |
| CR-OH2 | 90.00 | 48.00 | 0.0 | 0.0 | 0.0 | 0.0 | 22.8 |
| CR-OH3 | 96.39 | 32.00 | 0.0 | 0.0 | 0.0 | 0.0 | 11.4 |
| CR-STR | 86.17 | 19.20 | 0.0 | 0.0 | 0.0 | 0.0 | 31.2 |
| **Total** | | | 285.8 | 265.9 | 162.5 | 202.6 | 181.4 |

Estimate roll-up of the recommended design: direct $99,325; JOOH $9,436; HOOH $4,894; profit $9,035; bond $1,610; escalation $2,410; contract $126,710; contingency $6,335; SIOH $7,584; **total project cost $140,629**.

North from the SWG-C1 north zone, 26 ft leg into a 25 ft radius long sweep (tangent 25 ft), east along y = 1086 between CUP-1 and the rail spur (no rail crossing: route passes south of the spur and its bumper post), HDD under Mission Dr, manhole MH-A at (1030, 1086) east of the crane area and bumper post (pull 586 ft), and a 94 ft run north to TX-W3 (within 200 ft with pulling calculation). B-7 area: trench 3.43 ft deep stays above the 4.0 ft groundwater (no dewatering).

## 4. Basis of the alternatives priced

* CEDB: route shown for the recommended design (C01, C03, C07) or the CEDB route designed for the item (C02: south of T-2 along y = 390 with 2 manholes; C04: along y = 1005 and y = 1085 with HDD under DC-1 and 2 manholes; C06: diagonal with 3 manholes); crossings of Mission Dr by HDD, P-1 / CUP yard reinforced.
* UEDB: same route, Schedule 40 PVC in sand at 24 in cover (UFGS 33 71 02 3.7.8), reinforced concrete encasement under paving (3.7.8.1), HDD at roads.
* DBC: same route, triplexed cable at 30 in cover in 8 in trench (UFGS 33 71 02 3.6.1), concrete-encased ducts under paving, HDD at roads; cable sized on the direct-burial table.
* HDD: entire run bored between the same pull points, HDPE SDR 11 (fill <= 30 %), 120 in cover (deep-bore surcharge), conduits = circuits + spares; cable sized on the single-conduit-in-earth table at 120 in (bores > 25 % of the run).
* OH (C01, C03, C07, not permitted): pole line along the CEDB route with riser poles 30 ft from each terminal; OH (C02, C04, C06): recommended designs.
* C05: RMC and EMT on the ER-A / MR-2 / MR-1 route (EMT 4 in cannot take 250-350 kcmil without jamming); TRAY-EN / TRAY-LD on the ER-A / COR-1 / COR-1D / COR-1E / MR-1 route (2 sets of 250 kcmil: 350 kcmil exceeds 40 % fill of the 4 in wall sleeves).

## 5. Errors and inconsistencies found in Government-furnished documents

| ID | Document | Location | Defect | Correction used |
|---|---|---|---|---|
| F01 | E-001 One-Line Diagram Rev B (2026-02-10) | Feeder F1 relay 51P | E-001 shows F1 51P pickup 560 A; Protective Device Settings Schedule E-PDS-001 Rev D (2026-06-30) shows 640 A (increased for MB-1 Phase 2) | Used 640 A (current PDS governs over one-line, IEDS 1.3(4)); C01 sized for 640 A at 100 % load factor |
| F02 | Attachment J-3 Wage Determination CA20260022 Mod 2 | ELEC0011-004 inside electrician | Solicitation attaches Mod 2 (Journeyman Electrician $65.00 + 3%+$35.62); Mod 5 published 08/06/2026, more than 10 days before bid opening 2026-10-08, lists $60.80 + $31.59 | Used Mod 5 per 29 CFR 1.6(c)(2)(ii)(A); line construction, laborer and operator rates identical in both |
| F03 | Government Estimate Template PCSFA FY26 | Summary line 2-3 | Template applies Area Cost Factor 1.16 (LOS ANGELES AFB SITE # 1) to the bottom-up direct cost | ACF not applied (1.00): UFS 3-701-01 4-1.1 prohibits ACFs on detailed take-offs; RFP 3.1 estimate priced with local WD, quotes and Region VII schedule |
| F04 | C-101 Site Utility Plan Rev 4 | W-12 water main labels | C-101 shows top of pipe approx. 72 in; SUE-24-0117 test holes TH-1/TH-2 measured 56 in (16 in shallower) | Used 56 in (SUE governs, IEDS 1.3(5)); Mission Dr bores at 84 in cover to clear W-12 bottom (68.75 in) by >= 12 in |
| F05 | C-101 Site Utility Plan Rev 4 | TREES layer | Tree T-208 (14 in Jacaranda, retain, x 170 y 395) of arborist survey TS-24-0117 is not shown on C-101; C-101 circles are drawn at 0.8 ft per inch DBH, smaller than the IEDS 4.14 TPZ (1 ft per inch) | Used arborist survey (IEDS 1.3(7)) and TPZ radius = DBH in ft; C06 riser run kept 20 ft outside T-208 TPZ |
| F06 | GEO-24-0117 Geotechnical Report | Table 2 (OSHA soil type) | Table 2 lists B-7 and B-10 as Type B; logs show granular SP (3-9 ft, GW 4.0 ft) at B-7 and SM (2-12 ft, GW 3.0 ft) at B-10, which are Type C | Used logs (IEDS 1.3(6), 4.12): Type C where excavation reaches the granular layer / groundwater |
| F07 | TD-15AL-133 Cable Data Sheet Rev 3 | 4.2 SWBP | Catalogue SWBP 1,000 lb/ft; approved submittal SUB-33 71 02-07 (manufacturer letter 2026-08-14) limits SWBP to 600 lb/ft for the tape-shielded cable | Used 600 lb/ft (approved submittal governs catalogue, IEDS 1.3(3)) |
| F08 | Transmittal T-0117-09 | GEO-24-0117 and SUE-24-0117 dates | Transmittal lists GEO-24-0117 dated 2026-03-27 and SUE-24-0117 dated 2026-04-18; the documents are dated 2025-05-16 and 2025-03-28 | Used the documents as transmitted (content unaffected) |
| F09 | UFC 3-550-01 App B vs PCSFA-IEDS Rev 3 4.7 / HDD quote | B-1 conduit type | UFC App B calls for minimum Schedule 80 HDPE; IEDS 4.7 and quote ADD-26-311 specify HDPE SDR 11 | Used HDPE SDR 11 dimensions of quote Q-2608-114 (project-specific IEDS requirement); fill <= 30 % per App B |
| F10 | UFS 3-701-01 Data Tables (file labelled 2025) | Table 4-2 cell G29 | FY2030 escalation factor formula references G27 (FY2028) instead of G28, so 2030 equals 2029; file is labelled 2025 while UFS edition is 2026 | Not affecting study: factors interpolated between 2025-10-01, 2026-10-01 and 2027-10-01 (1.021 compounded) |
| F11 | Labor Unit Database / Crew book vs Rental Quote RQ-26-0419 | TBOX / RQ-TBX | Trench shield rental RQ-TBX is quoted but no crew carries it; TBOX (move shield) uses crew CR-EX (excavator only) | Priced per crew book (RFP 3.3 equipment hours = crew hours x units in the crew); shield rental not added |
| F12 | Fuel Supplier Invoice FSI-0826-2207 | Ship-to | Invoice prices are for deliveries to the contractor yard (Gardena), not the jobsite | Used invoice prices as the jobsite fuel prices required by RFP 3.3 (gasoline $5.12, dyed diesel $4.38) |
| F13 | TD-15AL-133 Ampacity Tables | Depth_Correction_Ductbank 1/0 AWG | 1/0 AWG factor at 180 in (0.913) equals the 120 in factor, inconsistent with the other sizes | Not used (1/0 below the 250 kcmil short-circuit minimum) |
| F14 | Supplier Quote Q-2608-114 | Cable lines 1-8 / conduit note 6 | Note numbering out of sequence (note 6 before 5); 500 kcmil in 5 in EB-20 gives D/d 3.21 but 3.08 in 5 in Sch 40 risers and 39 % fill in 5 in HDPE | Used 6 in EB-20 / HDPE for 500 kcmil (D/d 3.82 / 3.31, fill 20.6 / 27.5 %) |

## 6. Requirements register

| ID | Document | Clause | Requirement | Value | Applies to |
|---|---|---|---|---|---|
| R01 | RFP FA4610-26-R-0031 Sec 01 11 00 Amd 0002 | 1.4 | Conveyance types evaluated; type permitted when a compliant route exists with the type predominant | CEDB, UEDB, DBC, HDD, OH; C05: RMC, EMT, TRAY-EN, TRAY-LD | All |
| R02 | RFP Sec 01 11 00 Amd 0002 | 1.5 | Recommended conveyance = permitted type with lowest total project cost; 10 % design | lowest TPC | All |
| R03 | RFP Sec 01 11 00 Amd 0002 | 1.1 | Study date / midpoint of construction | 2026-09-15 / 2027-08-18 | Escalation |
| R04 | RFP Sec 01 11 00 Amd 0002 | 3.2 | Labor hours = qty x unit (database conversions); loaded rate = base x (1+burden) + fringe | burden = FICA+FUTA+SUI+WC on base | Estimate |
| R05 | RFP Sec 01 11 00 Amd 0002 | 3.3 | Equipment EP 1110-1-8 Region VII, fuel & FOG adjusted (paras 3.9, 3.10); rentals at quote; equipment hours = crew hours x units | gas 5.12/2.49, diesel off-road 4.38/2.26 | Estimate |
| R06 | RFP Sec 01 11 00 Amd 0002 | 3.4 | Materials: price x (1+waste) x PPI adjustment x (1+9.5 % tax) | PPI WPU102603 Aug-2026 494.096 / Jul-2026 482.612 | Estimate |
| R07 | RFP Sec 01 11 00 Amd 0002 | 3.6 | JOOH 9.5 % DC; HOOH 4.5 % (DC+JOOH); profit weighted guidelines; bond per surety letter; escalation; contingency 5 %; SIOH 5.7 % | see Markups | Estimate |
| R08 | UFC 3-740-05 (2022 C1) | 11-2.2 | Weights: size of job $4.2 M -> 0.0614; period 15 months -> 0.0848; subcontracting 30 % -> 0.0863 | profit 7.949 % | Estimate |
| R09 | Sierra Surety bond rate letter 2026 | Class B schedule | Graduated premium on contract amount excl. bond; +1 % of premium per month beyond 12 months | 15 months -> +3 % | Estimate |
| R10 | UFS 3-701-01 (2026) data tables | Table 4-2 | Escalation factor at midpoint / factor at study date, linear by day | 1.06169 / 1.04150 = 1.01939 | Estimate |
| R11 | UFS 3-701-01 (2026) | 4-1.1 | MILCON ACFs not applied to detailed quantity take-offs | ACF = 1.00 | Estimate |
| R12 | 29 CFR 1.6 | (c)(2)(ii)(A) | Revised WD issued >= 10 days before bid opening is effective (sealed bidding) | CA20260022 Mod 5 (08/06/2026), bid opening 2026-10-08 | Labor rates |
| R13 | PCSFA-IEDS Rev 3 | 1.3 | Order of precedence (IEDS stricter, UFC, submittals, PDS, SUE, boring logs, arborist survey) | applied | All |
| R14 | PCSFA-IEDS Rev 3 | 2.1 | MV cable: 1/C MV-105 XLPE 133 % Al, copper tape shield; min 1/0 AWG; 3 conductors of a set in one raceway | TD-15AL-133 | All |
| R15 | PCSFA-IEDS Rev 3 | 2.2 | Ampacity of one set at governing condition x sets >= phase pickup (PDS Rev D) | F1 640, F2 560, F3 400, CF-2 60, A-3 200, F4 40, CF-1 120 A | All |
| R16 | PCSFA-IEDS Rev 3 | 2.3 | Load factor: F1, F2 100 %; others 75 % | 100 / 75 % | All |
| R17 | PCSFA-IEDS Rev 3 | 2.4 | Short-circuit: capability at 0.5 s >= bus fault (SS-1 16.5 kA, SWG-C1 14.2 kA, MSG-A 15.8 kA) | min 250 kcmil (16.6 kA); 4/0 = 14.1 kA fails | All |
| R18 | PCSFA-IEDS Rev 3 | 4.1 | No overhead inside industrial area (C-101) or W-3 crane area; OH elsewhere with UG risers | C-101 polygons | Site |
| R19 | PCSFA-IEDS Rev 3 | 4.2 | Primary circuits in concrete-encased ductbank; no direct burial / unencased conduit | CE | Site |
| R20 | PCSFA-IEDS Rev 3 | 4.3 | Perimeter Rd, Mission Dr, MB-1 drive not open-cut (HDD/JB); P-1 & CUP yard saw-cut with reinforced CE extending 5 ft beyond paving; bores only for listed crossings, <= 50 ft beyond pavement/bank; DC-1 not open cut | HDD 10 ft beyond each road edge | Site |
| R21 | PCSFA-IEDS Rev 3 | 4.4 | Bus A (F1, F3) and bus B (F2, F4) conveyances separate, >= 20 ft apart except within 50 ft of SS-1 fence / MB-1 walls | >= 20 ft (min 215 ft achieved) | C01, C02, C03, C06 |
| R22 | PCSFA-IEDS Rev 3 | 4.6 | Ampacity: nearest-boring rho (next higher table value), 25 C earth (ambient factor on all UG tables), circuits = occupied ducts, lowest along route; bores excluded if <= 25 % of run; ACSR and building at 40 C | TD-15AL-133 tables | All |
| R23 | PCSFA-IEDS Rev 3 | 4.7 | HDD: HDPE SDR 11, cover 48 in under pavement, 120 in elsewhere except within 10 ft of bore ends; fill <= 30 % | UFC 3-550-01 App B B-1.1 | Site |
| R24 | PCSFA-IEDS Rev 3 | 4.8 | EB-20 PVC, 5 in min, 3 in spacing/cover; spares >= 1/3 of ducts (min 1); 4/0 Cu ground per ductbank | 1 circuit: 2 ducts; 2 circuits: 3 ducts | Site |
| R25 | UFGS 33 71 02 | 3.7.9 | Cover to top of concrete envelope 18 in (24 in under pavement); stricter than UFC 3-550-01 3-11.2.2 (18 in to conduit) | 18 / 24 in | Site |
| R26 | UFGS 33 71 02 | 3.7.8 / 3.6.1 | Unencased conduit >= 24 in cover; direct-buried MV cable >= 30 in cover | 24 / 30 in | UEDB, DBC pricing |
| R27 | UFGS 33 71 02 | 3.7.1 c | Field long-sweep bends 25 ft radius for direction changes > 5 deg | R = 25 ft | Site |
| R28 | PCSFA-IEDS Rev 3 | 4.9 | Max spans 1/0 300 ft, 3/0 280, 336.4 250, 477 220; Class 3 wood 45 ft (50 ft both poles of road-crossing span); guys > 5 deg, dead-end 2 guys > 60 deg, riser poles dead-end 1 guy; pole clearances 25 ft buildings, 6 ft roads, not in pavement/12 ft of rail/channel buffer | applied | OH |
| R29 | PCSFA-IEDS Rev 3 / UFC 3-550-01 | 4.10 / 3-11.5.5, 3-11.6 | Manholes not in pavement, >= 50 ft from paving, >= 200 ft from fueling point FP-1; spacing <= 400 ft (600 ft with pulling calc); within 100 ft (200 ft with calc) of riser poles / pad transformers | pulls <= 600 ft; <= 200 ft to pads/risers | Site |
| R30 | PCSFA-IEDS Rev 3 / SUB-33 71 02-07 | 4.11 / letter 2026-08-14 | Pulling tension 0.006 lb/cmil x 2 conductors (<= 10,000 lb); SWBP <= 600 lb/ft; riser elbows 90 deg 36 in radius | 250: 3,000 lb; 350: 4,200 lb; 500: 6,000 lb | All |
| R31 | TD-15AL-133 Rev 3 | 4.3-4.9 | Friction PVC 0.35, HDPE 0.30, steel 0.40; jam 2.8-3.2 avoided; fill <= 40 %; feed-in 100 lb; reel 2,500 ft | applied | All |
| R32 | PCSFA-IEDS Rev 3 / 29 CFR 1926 Subpart P | 4.12 / App A, App B | Soil type from nearest boring, least stable layer; granular / below GW = Type C; protective system for excavations >= 5 ft (slope A 3/4:1, B 1:1, C 1.5:1, or shield); manholes 8 ft deep; dewater below GW | shield (box) at manholes and deep trenches | Site |
| R33 | PCSFA-IEDS Rev 3 | 4.13 | Existing utilities: 5 ft horizontal (parallel), 12 in vertical at crossings | G-4 crossing top >= 52.5 in; W-12 bore cover 84 in; SD-30 crossed above | Site |
| R34 | PCSFA-IEDS Rev 3 | 4.14 | Tree protection zone 1 ft per inch DBH (arborist survey TS-24-0117); no excavation in TPZ | T-201..T-209 retained | Site |
| R35 | PCSFA-IEDS Rev 3 | 5.1 | Building MV: tray needs 6 + 12 in, conduit 6 in (A-501); 10 ft from SCIF walls; rises 7 ft with 90 deg elbow | A-501 Rev 1 | C05 |
| R36 | PCSFA-IEDS Rev 3 | 5.2 / 5.3 | Rigid conduit firestopped at every rated wall; tray sleeves at 2-hr walls (<= 40 % fill); supports; seismic braces every 40 ft transverse / 80 ft longitudinal; pull boxes so bends <= 270 deg | applied | C05 |
| R37 | UFGS 26 20 00 | 3.1.6.7 | Conduit for circuits > 600 V: rigid metal conduit or IMC only | RMC | C05 |
| R38 | UFC 3-520-01 (2025) | Table 3-1 Art. 328 | Interior MV cable in raceway or fully enclosed cable tray | ladder tray excluded | C05 |
| R39 | UFC 3-550-01 (2016 C3) | 3-11.4.1 | Directional boring only for crossings (roads, parking lots, water, environmentally sensitive areas) | HDD not as entire run | Site |
| R40 | UFC 3-550-01 (2016 C3) | 3-10 | Overhead: initial loaded tension <= 50 % RBS, max 4,750 lb; ACSR conductors | design tension per 3-10 | OH |
| R41 | UFGS 33 71 01 | 3.1.3.1 | Pole setting depth | per spec (POLE-HOLE 7 ft unit) | OH |
| R42 | RFP Sec 01 11 00 Amd 0002 | 3.7 | Take-off conventions (trench, envelope, excavation, backfill, manholes, cable circuit-feet, terminations, OH, building) | applied | All |
