```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 221593.05,
      "improved_cost_usd": 84960.13
    },
    "CR-P2": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 266374.34,
      "improved_cost_usd": 91634.86
    },
    "CR-P3": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 32906.58,
      "improved_cost_usd": 57273.32
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 57453.13,
      "improved_cost_usd": 46960.29
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 17986.47,
      "improved_cost_usd": 36798.03
    },
    "CR-P6": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 204518.99,
      "improved_cost_usd": 86930.09
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 441378.42,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-01N (2005) Foundation Design - cancelled predecessor volume",
    "UFC 3-220-10N (2005) Soil Mechanics - cancelled predecessor volume (incl. its tolerable-settlement tables)",
    "Basis of Design Rev 1 - superseded (all-Warehouse occupancy, F0 exposure, 1-in dimensioning, 20 ft depth)",
    "Geotechnical Addendum 1 - superseded (Es 320/900/2400 ksf, withdrawn 4,000 psf presumptive value)",
    "NOAA NCEI AFI 1951-1980 return-period tables - superseded edition (416 F-days -> 30 in)",
    "Presumptive bearing pressure 3,000 psf (GDR Rev 2 Sec 7) - prohibited by AHJ Amendment 4 and RFI-009",
    "Adjacent parcel report (Broadview Commons) - different property, 5,500 psf not applicable (RFI-013)",
    "FHWA GEC 6 highway-bridge tolerable movement criteria (angular distortion 0.004-0.005) - different class of structure",
    "EM 1110-2-2104 Table 3-1 hydraulic-structure load factors and para 2.9.1 hydraulic shrinkage steel - not applicable",
    "Proprietary vendor stress concentration ratios (>= 20) - rejected per RFI-011; GEC 13 value n_s = 10 used",
    "EM 1110-2-2502 Table 4-1 sliding FS 1.5 - superseded by UFC 3-220-01 2-4.6.3 FS 2.0 (UFC prevails)",
    "UFC 3-220-01 2-4.7.7 / UFC 3-301-01 1808.8.2.1 thick-footing minimum 0.0015 - lower than the BoD 0.0018 project minimum",
    "Subgrade-reaction (mat chapter) estimator as settlement method - rejected per RFI-019",
    "Deep foundations (drilled piers / driven piles) - not accepted in Phase 1 (RFI-015)"
  ]
}
```

# Design basis - Phase 1 foundation strategy, Cattail Run Data Campus (AV-CR-2604)

Prepared by the structural engineer of record for the six Phase 1 building pads CR-P1 to CR-P6 (one instrumented column line of five isolated column footings F1-F5 and one continuous shear-wall footing W1 per pad). All numbers below are derived from the documents in the data room and are reproduced in `foundation_geometry.json`, `ground_improvement_plan.json`, `foundation_schedule.xlsx`, `foundation_feasibility_matrix.md` and `constraint_register.xlsx`.

## 1. Governing criteria and documents set aside

The criteria that govern are: UFC 3-220-01 Geotechnical Engineering (1 Nov 2012, Change 3, 1 Jul 2025) for bearing, factor of safety, settlement, minimum widths, frost, sliding and thick-footing reinforcement; UFC 3-301-01 Structural Engineering (2023, Change 4) for load combinations and footing reinforcement; UFGS 03 30 00 Cast-in-Place Concrete for the exposure-class w/cm and f'c limits; UFGS 31 00 00 Earthwork for dewatering; the Basis of Design - Structural Rev 3 (occupancy, exposure classes, reinforcement, dimensioning and cost basis); the Loudoun County AHJ amendment letter LC-BD-26-0774 (Amendment 3 frost depth, Amendment 4 prohibition of presumptive bearing values); the RFI log (RFI-004, -007, -009, -011, -013, -015, -017, -019, -021); the BIM parameter standard Rev 2; the Geotechnical Data Report Rev 2 with its boring logs and laboratory summary; the civil grading and groundwater record (sheet C-301); the structural base reactions, column grid and load-combination memorandum; the bid schedule Rev 1 and the Kettleridge proposal KGS-26-0917. The analysis manuals applied are UFC 3-220-20 (DM 7.2, 2025) and EM 1110-1-1905 for bearing capacity, FHWA GEC 13 Vol I Chapter 5 for rammed aggregate piers and the layered-elastic settlement equation, EM 1110-2-2502 for the sliding/passive procedure, EM 1110-2-2104 Chapter 5 (ACI 318 shear strength) for footing structural design and EM 1110-2-2000 Table 2-2 for the sulfate exposure condition.

The documents reviewed and set aside, with the reason, are: UFC 3-220-01N (2005) and UFC 3-220-10N (2005) - both are cancelled predecessor volumes and were not used for any requirement (the settlement method is the one directed by RFI-019); Basis of Design Rev 1 - superseded in its entirety by Rev 3 (its all-Warehouse occupancy, F0 exposure, 1-in dimensioning and 20 ft maximum depth are not used); Geotechnical Addendum 1 - superseded by GDR Rev 2 (its moduli of 320/900/2400 ksf and its 4,000 psf presumptive value are withdrawn); the 1951-1980 NCEI air-freezing-index tables - the superseded edition of the AFI product per AHJ Amendment 3 and RFI-007; the Broadview Commons adjacent-parcel report - a different property with different stratigraphy, information only (RFI-013); FHWA GEC 6 - written for highway bridges, a different class of structure, so its bridge tolerable-movement criteria are not used; the load factors of EM 1110-2-2104 Table 3-1 - they are for hydraulic structures and the load memo excludes them; the 3,000 psf presumptive bearing pressure of GDR Rev 2 Section 7 - prohibited for design by AHJ Amendment 4, UFC 3-220-01 2-4.5.2/2-4.6.4 and RFI-009.

## 2. Bearing capacity, settlement and factor of safety

Bearing-capacity method actually applied: the ultimate bearing capacity of every foundation is computed with the general drained bearing-capacity equation of UFC 3-220-20 (Eq 5-15) by three widely accepted methods as required by UFC 3-220-01 paragraph 2-4.7.1 - Terzaghi (1943) with the Table 5-5 shape factors, Meyerhof (1963) with the Table 5-6 shape and depth factors, and Brinch Hansen (1970) with the Table 5-8 shape and depth factors - using the drained parameters of the bearing stratum from GDR Rev 2 Section 2 (Stratum I: 118 pcf, phi' = 26 deg, c' = 0.25 ksf). The groundwater correction of UFC 3-220-20 Section 5-3.2 / Figure 5-6 is applied to the N-gamma term wherever the stabilised groundwater (civil record Section 2) lies within one footing width below the bearing elevation, i.e. at CR-P1, CR-P2, CR-P4 and CR-P6; submerged unit weight = total unit weight less 62.4 pcf (GDR Section 2). The net allowable bearing pressure is q_all,net = q_ult/FS - sigma_zD (UFC 3-220-20 Eq 5-14) and the value reported for each foundation is the LEAST of the three methods (RFI-021), so it is never more permissive than the general equation. The applied net pressure is the service D + L reaction divided by the footing area (Eq 5-3); as an additional margin the design also satisfies the more rigorous net pressure (P + footing + backfill weight)/A - sigma_zD, and the larger of the two is reported as q_net. No presumptive bearing value was used anywhere.

- Factor of safety at CR-P1 (Data Hall 1): FS = 3.5, from UFC 3-220-01 Table 2-3, row 'Light Industrial, Public', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2.
- Factor of safety at CR-P2 (Data Hall 2): FS = 3.5, from UFC 3-220-01 Table 2-3, row 'Light Industrial, Public', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2.
- Factor of safety at CR-P3 (Electrical Yard Building): FS = 3.5, from UFC 3-220-01 Table 2-3, row 'Light Industrial, Public', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2.
- Factor of safety at CR-P4 (Administration and Operations Building): FS = 3.0, from UFC 3-220-01 Table 2-3, row 'Apartments, Office', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2.
- Factor of safety at CR-P5 (Logistics and Spares Warehouse): FS = 2.5, from UFC 3-220-01 Table 2-3, row 'Warehouse', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2. The Table 2-3 asterisk note (FS > 3 for super-flat floors) does not apply because no such floor requirement is stated in the Basis of Design.
- Factor of safety at CR-P6 (Data Hall 3): FS = 3.5, from UFC 3-220-01 Table 2-3, row 'Light Industrial, Public', the occupancy classification assigned to this building in Basis of Design Rev 3 Section 2.

Settlement method actually applied: layered elastic compression exactly as directed by RFI-019 - the soil below the bearing surface is divided into uniform layers 0.25 ft thick down to max(4B, 40 ft), the net stress increment at the mid-height of each layer is computed with the 2V:1H distribution for a rectangular area, delta_sigma = P/((B+z)(L+z)), and the layer compressions delta_sigma*H/Es are summed using the pad-specific moduli of GDR Rev 2 Section 2 with the Stratum I base interpolated by station and rounded to 0.1 ft (GDR Section 4). This is GEC 13 Equation 5-14. For footings on rammed aggregate piers the GEC 13 two-layer method is used: s = s_uz + s_lz (Eq 5-11), top-of-pier stress q_g = q n_s/(n_s R_a - R_a + 1) (Eq 5-12), s_uz = q_g/k_g (Eq 5-13), and s_lz by the same layered Eq 5-14 below the treatment depth. To make the design insensitive to implementation details, settlements were evaluated in four variants (stratum of a layer by its mid-height or by exact split; net or gross pressure for q_g and for the rigorous net pressure) and the largest is reported and checked.

## 3. Tolerable movement criteria

The tolerable-movement criteria adopted are those of UFC 3-220-01 paragraph 2-4.7.1: total post-construction settlement not more than 1 in, and differential settlement between adjacent foundation units not producing an angular distortion greater than 1/500 (difference in settlement divided by the distance between the units). Settlement is computed at all six units of each pad and the greatest difference between adjacent units is checked; the critical pair is F5-W1, only 5.0 ft apart, which allows 0.12 in. The design targets are 0.98 in for total settlement and 95 % of the angular-distortion limit in every computation variant. Competing criteria rejected: the FHWA GEC 6 bridge criteria (angular distortion 0.004 to 0.005, differential settlements of 1 to 2 in) because GEC 6 is written for highway bridges; the tolerable-settlement tables of the cancelled UFC 3-220-10N; the EM 1110-2-2502 retaining-wall range of 0.002-0.003; and the 75 %-of-maximum empirical differential rule quoted in UFC 3-220-20 - the differential settlement is computed directly from the settlement pattern as UFC 3-220-01 requires.

## 4. Frost, depth and groundwater

Frost protection follows UFC 3-220-01 paragraph 2-4.8.4 (frost depths published by the local government). The AHJ published the requirement in Amendment 3: 42 in minimum bearing depth where the 100-year AFI at NCEI station USC00444909 (Lincoln, VA) exceeds 500 F-days. The current NCEI product (1981-2010 normals) gives a 100-year AFI of 556 F-days for USC00444909, so the frost depth is 42 in. The superseded 1951-1980 tables give 416 F-days for the same station (which would have produced 30 in); they are not used (AHJ Amendment 3, RFI-007). Bearing depths adopted: CR-P1 45 in, CR-P2 45 in, CR-P3 45 in, CR-P4 42 in, CR-P5 42 in, CR-P6 45 in (3-in grid, single bearing elevation per pad, all shallower than 4.0 ft so no open-cut side slopes are needed, and all at least 4.25 ft above the stabilised groundwater so no dewatering is required: dewatering_days = 0 at every pad). The UFC 18-in minimum depth is also satisfied. Every foundation bears in Stratum I (the interpolated base of Stratum I is 4.5 ft or deeper at every station).

## 5. Structural design of the footings and concrete

Footing thickness is the least 3-in multiple (minimum 12 in, BoD Section 4) satisfying two-way shear at d/2 from the column/wall face (vc = 4 sqrt(f'c)) and one-way shear at d (vc = 2 sqrt(f'c)) under the 1.2D + 1.6L reactions (load memo; UFC 3-301-01 2-4.3) with phi = 0.75 and d = t - 4 in (BoD Section 3), per EM 1110-2-2104 paragraph 5.1 / Eq 3-1 (ACI 318 shear strength). Flexural steel is computed at the face of the column or wall (phi = 0.90, fy = 60 ksi) and the reported reinforcement ratio (As/gross area, each direction) is the greater of the flexural requirement and the BoD Section 3 project minimum of 0.0018; the UFC 3-220-01 2-4.7.7 / UFC 3-301-01 1808.8.2.1 minimum of 0.0015 for footings over 3 ft thick is lower and therefore does not govern, but its No. 4 minimum bar and 12-in maximum spacing are respected (bars No. 5 to No. 7 at 6-8 in). The thinnest footing is 15 in.

The sulfate exposure condition is assigned from the more severe of the two Stratum I results with EM 1110-2-2000 Table 2-2 and paragraph 2-2c(3)(b) (moderate 0.10-0.20 %, severe > 0.20 %; below 0.10 % no precautions): CR-P1 0.14 % moderate -> S1; CR-P2 0.23 % severe -> S2; CR-P3 0.07 % negligible -> S0; CR-P4 0.11 % moderate -> S1; CR-P5 0.05 % negligible -> S0; CR-P6 0.26 % severe -> S2. The concrete limits are the most restrictive of the UFGS 03 30 00 tables for all assigned classes (F1 0.55/3500, F3 0.40/5000, W1 0.50/4000, C1 -/2500, S1 0.50/4000, S2 0.45/4500) and the lowest plant strength meeting them is specified: CR-P1, CR-P3, CR-P4 4000 psi, w/cm 0.50; CR-P2, CR-P6 4500 psi, w/cm 0.45; CR-P5 (F3, de-icing exposure) 5000 psi, w/cm 0.40.

## 6. Shear-wall footing stability

Sliding (0.6D + W) is resisted by base friction with delta = 2/3 phi' of the bearing stratum (Stratum I, phi' = 26 deg, tan delta = 0.312) plus not more than one half of the passive resistance on the embedded footing face (load memo Section 3; EM 1110-2-2502 para 3-8). Required FS = 2.0 (UFC 3-220-01 2-4.6.3; UFC 3-220-20 4-5.1.3 also requires 2.0 when passive resistance is counted). The sliding_fs reported in the parameter file is the conservative value that counts only the 0.6D wall reaction in base friction (no footing or backfill weight, no passive): 2.30 at all six pads; with 0.6 x footing and backfill weight and one half of the Rankine passive force the factor of safety is 2.59-2.81. The service D + L + W resultant stays in the middle third in the direction of the wall shear and also across the width (UFC 3-220-20 Eq 5-5; load memo): the reported eccentricity is the largest of M/P, (M + H t)/(P + W) and (M + H D)/P, 8.9-9.1 in, against B/6 >= 12.5 in and L/6 >= 49.5 in. Uplift (UPLIFT_W) is resisted by 0.6 x (footing self weight + soil above the footing projection + unfactored dead load); reported FS = 2.84-3.05 (taking the lesser of the value with and without the soil above the projection) against the 1.5 minimum of UFC 3-220-20 Figure 5-41.

## 7. Ground-improvement design parameters and authority

- Stress concentration ratio n_s = 10: FHWA GEC 13 Vol I Chapter 5 Section 4.2.1 ('for structure foundation support under rigid footings a somewhat higher stress ratio (10) may be considered'), as directed by RFI-011; vendor design-manual ratios of 20 or more are not accepted.
- Pier diameter 30 in and minimum clear spacing 1.0 ft (3.5 ft centre to centre): Kettleridge proposal KGS-26-0917 Section 2. The clear spacing limits the area replacement ratio to 0.401 (square grid) / 0.463 (staggered grid); the design keeps R_a <= 0.401.
- Minimum area replacement ratio 0.33: GEC 13 Section 4.2.1 (HITEC evaluation, Collin 2007). Adopted R_a = 0.331-0.383 (R_a = pier count x 4.909 sq ft / footing area).
- Stiffness modulus k_g: the pad-specific pre-production modulus-test values of KGS-26-0917 Section 3 (CR-P1 165, CR-P2 140, CR-P4 195, CR-P6 155 pci), inside the GEC 13 Section 4.2.3.1 range of 75-360 pci for rigid footings.
- Treatment depth: 8 to 25 ft below the footing soffit in whole feet (KGS-26-0917 Section 2); adopted 8-9 ft (deepest per pad: CR-P1 9 ft, CR-P2 9 ft, CR-P4 8 ft, CR-P6 9 ft).
- Top-of-pier stress: not more than 18,000 psf (KGS-26-0917 Section 2), computed conservatively from the gross bearing pressure; maximum 15,261 psf.
- Verification testing: one production modulus test per improved pad (KGS-26-0917 Section 5), consistent with GEC 13 Section 5.2.2 (typically one modulus test per 1,000 piers; the largest improved pad has 99 piers).

## 8. Conflicts between documents and their resolution

| Topic | Conflict | Resolution and governing value |
|---|---|---|
| Frost depth | 1951-1980 AFI tables (416 F-days -> 30 in) vs current 1981-2010 product (556 F-days -> 42 in) | Current product governs per AHJ Amendment 3 and RFI-007: 42 in. |
| Occupancy / FS | BoD Rev 1 (all Warehouse, FS 2.5) vs BoD Rev 3 | Rev 3 governs: FS 3.5 (P1, P2, P3, P6), 3.0 (P4), 2.5 (P5). |
| Elastic moduli | Addendum 1 (320/900/2400 ksf) vs GDR Rev 2 pad-specific moduli | GDR Rev 2 governs (e.g. Stratum I 85-250 ksf). |
| Presumptive bearing | GDR Sec 7 3,000 psf (and Addendum 1 4,000 psf) vs AHJ Amendment 4 / UFC 3-220-01 2-4.5.2 | Prohibited; site-specific least-of-three analysis governs. |
| Sliding FS | EM 1110-2-2502 Table 4-1 (1.5) vs UFC 3-220-01 2-4.6.3 (2.0) and UFC 3-220-20 4-5.1.3 (2.0 with passive) | UFC prevails over best-practice documents (UFC 3-220-01 para 1-7): FS = 2.0. |
| Minimum reinforcement | UFC 3-220-01 2-4.7.7 / UFC 3-301-01 1808.8.2.1 (0.0015 for t > 3 ft) and EM 1110-2-2104 para 2.9.1 (0.003, hydraulic structures) vs BoD 0.0018 | BoD 0.0018 governs (the UFC thick-footing value is lower; the hydraulic-structure value does not apply to building footings). |
| Load factors | EM 1110-2-2104 Table 3-1 hydraulic factors vs UFC 3-301-01 combinations | Load memo governs: 1.2D + 1.6L for shear/flexure, D + L for bearing/settlement, 0.6D + W for sliding/uplift. |
| Stress concentration ratio | Vendor manuals (20+) vs GEC 13 (10 for rigid footings) | GEC 13 value n_s = 10 (RFI-011). |
| Tolerable movement | GEC 6 bridge criteria (0.004-0.005) vs UFC 3-220-01 2-4.7.1 (1 in, 1/500) | UFC 3-220-01: 1 in and 1/500. |
| Settlement method | UFC 3-220-01 points to EM 1110-1-1904 / DM 7.1 (not in data room / cancelled edition) | RFI-019 layered elastic compression (GEC 13 Eq 5-14). |
| Footing spacing | UFC 3-220-01 2-4.8.1 1.5B spacing not achieved at several bays | RFI-017: individual units, no overlap reduction; combined footings in the CDs. |
| Groundwater zone | UFC 3-220-20 Fig 5-6 (zone = B) vs EM 1110-1-1905 Eq 1-6 (zone = failure depth) | UFC 3-220-20 governs (the governing foundations manual); least-of-three values remain well below the general equation. |
| Deep foundations | Permitted for comparison (RFI-015) vs not accepted in Phase 1 | Shallow / aggregate-pier solutions only. |

## 9. Campus programme - which pads are improved, how many rigs and why

| Pad | Spread-only cost | Improved cost (excl. rig mobilisation) | Decision |
|---|---|---|---|
| CR-P1 | $221,593 | $84,960 | IMPROVED_SPREAD |
| CR-P2 | $266,374 | $91,635 | IMPROVED_SPREAD |
| CR-P3 | $32,907 | $57,273 | SPREAD |
| CR-P4 | $57,453 | $46,960 | IMPROVED_SPREAD |
| CR-P5 | $17,986 | $36,798 | SPREAD |
| CR-P6 | $204,519 | $86,930 | IMPROVED_SPREAD |

Pads improved: CR-P1, CR-P2, CR-P4 and CR-P6. Rigs mobilised: 2 (RIG-1 serves CR-P1 and CR-P2; RIG-2 serves CR-P4 and CR-P6), mobilisation cost $80,000.

Reasoning. On the very soft residual Stratum I of CR-P1 (Es 110 ksf), CR-P2 (85 ksf) and CR-P6 (95 ksf) spread footings at the frost depth cannot meet 1 in / 1/500 at any practical size; the cheapest compliant spread-only designs are $221,593 (CR-P1, footings lowered to 96 in, at the stabilised groundwater level), $266,374 (CR-P2, 120 in with dewatering) and $204,519 (CR-P6, very large footings), against $84,960, $91,635 and $86,930 improved - each saving far more than a full $40,000 rig. These three pads therefore must be improved, and because one rig can serve at most two pads within the Phase 1 window (KGS-26-0917 Section 4), two rigs are required for three pads. The second rig then has one free pad slot at no additional mobilisation cost. CR-P4 fills it: improved it costs $46,960 (footings, piers, platform and its modulus test) against $57,453 for the cheapest spread-only design, a saving of $10,493. CR-P3 and CR-P5 stay on spread footings: their thin Stratum I over stiff Stratum II gives compliant spread footings for $32,907 and $17,986, while improving either would cost $57,273 and $36,798 plus a third $40,000 rig. Improving five or six pads (3 rigs) or only three pads (still 2 rigs) is more expensive. Total campus programme cost: $441,378 (pad costs $361,378 + mobilisation $80,000).

Governing constraint: at every pad the footing plan sizes are selected by BEARING (net applied pressure at 93-100 % of the least-of-three net allowable; removing 3 in from a footing violates it). On the improved pads the piers then control total and differential settlement; on CR-P3 and CR-P5 the bearing-sized footings also satisfy 1 in and 1/500 (largest spread-footing settlement 0.966 in at CR-P3 F3). Thickness follows from punching/one-way shear and the bearing elevation from frost; they are dependent variables, not pad-level governing constraints.

Costs are at the project budget prices of the bid schedule Rev 1 and KGS-26-0917: concrete $196/$211/$228 per CY (4000/4500/5000 psi), reinforcing $1.42/lb (pay weight = 2 x rho x gross volume x 490 pcf), excavation $38/CY to the neat prism with 1 ft working room, backfill $46/CY (excavation less concrete), dewatering $4,200/day, piers $28/LF, platform $2.40/SY, modulus test $9,500, mobilisation $40,000 per rig.

## 10. Summary of the adopted design per pad

- CR-P1: bearing depth 45 in, IMPROVED_SPREAD, FS 3.5, S1/4000 psi/w/cm 0.50; footings F1 135x135x27 in + 9 piers x 8 ft; F2 186x186x39 in + 17 piers x 8 ft; F3 204x204x42 in + 20 piers x 8 ft; F4 171x171x33 in + 14 piers x 8 ft; F5 126x126x24 in + 8 piers x 8 ft; W1 147x378x30 in + 26 piers x 9 ft.
- CR-P2: bearing depth 45 in, IMPROVED_SPREAD, FS 3.5, S2/4500 psi/w/cm 0.45; footings F1 138x138x27 in + 9 piers x 9 ft; F2 192x192x39 in + 19 piers x 8 ft; F3 210x210x42 in + 21 piers x 8 ft; F4 174x174x36 in + 15 piers x 8 ft; F5 129x129x27 in + 8 piers x 8 ft; W1 159x357x30 in + 27 piers x 8 ft.
- CR-P3: bearing depth 45 in, SPREAD, FS 3.5, S0/4000 psi/w/cm 0.50; footings F1 111x111x21 in; F2 153x153x33 in; F3 168x168x33 in; F4 141x141x27 in; F5 105x105x21 in; W1 108x360x24 in.
- CR-P4: bearing depth 42 in, IMPROVED_SPREAD, FS 3.0, S1/4000 psi/w/cm 0.50; footings F1 102x102x21 in + 5 piers x 8 ft; F2 138x138x30 in + 9 piers x 8 ft; F3 153x153x33 in + 11 piers x 8 ft; F4 126x126x27 in + 8 piers x 8 ft; F5 96x96x21 in + 5 piers x 8 ft; W1 96x330x21 in + 15 piers x 8 ft.
- CR-P5: bearing depth 42 in, SPREAD, FS 2.5, S0/5000 psi/w/cm 0.40; footings F1 87x87x18 in; F2 114x114x24 in; F3 126x126x27 in; F4 105x105x21 in; F5 81x81x18 in; W1 75x297x15 in.
- CR-P6: bearing depth 45 in, IMPROVED_SPREAD, FS 3.5, S2/4500 psi/w/cm 0.45; footings F1 135x135x27 in + 9 piers x 9 ft; F2 186x186x36 in + 17 piers x 8 ft; F3 204x204x42 in + 20 piers x 8 ft; F4 171x171x33 in + 14 piers x 8 ft; F5 126x126x24 in + 8 piers x 8 ft; W1 153x363x30 in + 26 piers x 8 ft.

## Appendix A - Bearing capacity worked values (RFI-021: three methods, value relied on)

Net allowable bearing pressure q_ult/FS - sigma_zD (ksf) by each method for the adopted geometry, stratigraphy and groundwater condition, the value reported (least of the three), the applied net pressure and the predicted settlement. Stratum I parameters (phi' = 26 deg, c' = 0.25 ksf, 118 pcf) govern at every foundation; the groundwater correction (UFC 3-220-20 Fig 5-6) is active at CR-P1, CR-P2, CR-P4 and CR-P6.

| Pad | Tag | B x L x t (in) | FS | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported q_allow,net | q_net = P/A | q_net reported | Settlement (in) | Piers | Governing |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CR-P1 | F1 | 135x135x27 | 3.5 | 4.957 | 5.548 | 5.023 | 4.9572 | 4.820 | 4.8918 | 0.659 | 9 x 8 ft, Ra 0.349 | BEARING |
| CR-P1 | F2 | 186x186x39 | 3.5 | 5.246 | 5.784 | 5.087 | 5.0869 | 4.912 | 5.0156 | 0.751 | 17 x 8 ft, Ra 0.347 | BEARING |
| CR-P1 | F3 | 204x204x42 | 3.5 | 5.348 | 5.880 | 5.121 | 5.1211 | 4.913 | 5.0255 | 0.794 | 20 x 8 ft, Ra 0.340 | BEARING |
| CR-P1 | F4 | 171x171x33 | 3.5 | 5.161 | 5.708 | 5.062 | 5.0621 | 4.826 | 4.9142 | 0.740 | 14 x 8 ft, Ra 0.338 | BEARING |
| CR-P1 | F5 | 126x126x24 | 3.5 | 4.906 | 5.515 | 5.020 | 4.9062 | 4.717 | 4.7806 | 0.697 | 8 x 8 ft, Ra 0.356 | BEARING |
| CR-P1 | W1 | 147x378x30 | 3.5 | 4.847 | 4.627 | 4.366 | 4.3659 | 4.276 | 4.3560 | 0.702 | 26 x 9 ft, Ra 0.331 | BEARING |
| CR-P2 | F1 | 138x138x27 | 3.5 | 5.050 | 5.654 | 5.067 | 5.0504 | 4.889 | 4.9613 | 0.954 | 9 x 9 ft, Ra 0.334 | BEARING |
| CR-P2 | F2 | 192x192x39 | 3.5 | 5.356 | 5.908 | 5.140 | 5.1403 | 4.886 | 4.9900 | 0.954 | 19 x 8 ft, Ra 0.364 | BEARING |
| CR-P2 | F3 | 210x210x42 | 3.5 | 5.458 | 6.005 | 5.176 | 5.1758 | 4.915 | 5.0270 | 0.918 | 21 x 8 ft, Ra 0.337 | BEARING |
| CR-P2 | F4 | 174x174x36 | 3.5 | 5.254 | 5.816 | 5.109 | 5.1092 | 4.941 | 5.0368 | 0.844 | 15 x 8 ft, Ra 0.350 | BEARING |
| CR-P2 | F5 | 129x129x27 | 3.5 | 4.999 | 5.620 | 5.063 | 4.9994 | 4.770 | 4.8418 | 0.766 | 8 x 8 ft, Ra 0.340 | BEARING |
| CR-P2 | W1 | 159x357x30 | 3.5 | 5.028 | 4.849 | 4.517 | 4.5173 | 4.437 | 4.5170 | 0.823 | 27 x 8 ft, Ra 0.336 | BEARING |
| CR-P3 | F1 | 111x111x21 | 3.5 | 5.203 | 5.947 | 5.236 | 5.2025 | 5.133 | 5.1891 | 0.630 | - | BEARING |
| CR-P3 | F2 | 153x153x33 | 3.5 | 5.707 | 6.421 | 5.399 | 5.3991 | 5.226 | 5.3143 | 0.837 | - | BEARING |
| CR-P3 | F3 | 168x168x33 | 3.5 | 5.887 | 6.605 | 5.472 | 5.4717 | 5.216 | 5.3044 | 0.966 | - | BEARING |
| CR-P3 | F4 | 141x141x27 | 3.5 | 5.563 | 6.278 | 5.345 | 5.3452 | 5.111 | 5.1828 | 0.922 | - | BEARING |
| CR-P3 | F5 | 105x105x21 | 3.5 | 5.130 | 5.887 | 5.220 | 5.1304 | 4.890 | 4.9462 | 0.816 | - | BEARING |
| CR-P3 | W1 | 108x360x24 | 3.5 | 4.987 | 4.752 | 4.476 | 4.4760 | 4.400 | 4.4640 | 0.891 | - | BEARING |
| CR-P4 | F1 | 102x102x21 | 3.0 | 5.551 | 6.291 | 5.762 | 5.5512 | 5.319 | 5.3751 | 0.596 | 5 x 8 ft, Ra 0.340 | BEARING |
| CR-P4 | F2 | 138x138x30 | 3.0 | 5.789 | 6.431 | 5.767 | 5.7674 | 5.621 | 5.7012 | 0.686 | 9 x 8 ft, Ra 0.334 | BEARING |
| CR-P4 | F3 | 153x153x33 | 3.0 | 5.888 | 6.509 | 5.787 | 5.7873 | 5.503 | 5.5912 | 0.700 | 11 x 8 ft, Ra 0.332 | BEARING |
| CR-P4 | F4 | 126x126x27 | 3.0 | 5.710 | 6.376 | 5.758 | 5.7097 | 5.600 | 5.6720 | 0.645 | 8 x 8 ft, Ra 0.356 | BEARING |
| CR-P4 | F5 | 96x96x21 | 3.0 | 5.512 | 6.278 | 5.770 | 5.5116 | 5.119 | 5.1748 | 0.532 | 5 x 8 ft, Ra 0.383 | BEARING |
| CR-P4 | W1 | 96x330x21 | 3.0 | 5.215 | 5.005 | 4.791 | 4.7914 | 4.725 | 4.7810 | 0.607 | 15 x 8 ft, Ra 0.335 | BEARING |
| CR-P5 | F1 | 87x87x18 | 2.5 | 6.919 | 7.975 | 7.195 | 6.9187 | 6.383 | 6.4309 | 0.477 | - | BEARING |
| CR-P5 | F2 | 114x114x24 | 2.5 | 7.373 | 8.341 | 7.286 | 7.2859 | 7.191 | 7.2552 | 0.681 | - | BEARING |
| CR-P5 | F3 | 126x126x27 | 2.5 | 7.575 | 8.526 | 7.349 | 7.3485 | 7.084 | 7.1560 | 0.772 | - | BEARING |
| CR-P5 | F4 | 105x105x21 | 2.5 | 7.221 | 8.209 | 7.246 | 7.2214 | 7.040 | 7.0960 | 0.750 | - | BEARING |
| CR-P5 | F5 | 81x81x18 | 2.5 | 6.818 | 7.909 | 7.190 | 6.8178 | 6.277 | 6.3251 | 0.631 | - | BEARING |
| CR-P5 | W1 | 75x297x15 | 2.5 | 6.345 | 6.192 | 5.919 | 5.9190 | 5.867 | 5.9067 | 0.717 | - | BEARING |
| CR-P6 | F1 | 135x135x27 | 3.5 | 4.995 | 5.595 | 5.044 | 4.9953 | 4.916 | 4.9882 | 0.933 | 9 x 9 ft, Ra 0.349 | BEARING |
| CR-P6 | F2 | 186x186x36 | 3.5 | 5.284 | 5.830 | 5.108 | 5.1081 | 5.010 | 5.1058 | 0.819 | 17 x 8 ft, Ra 0.347 | BEARING |
| CR-P6 | F3 | 204x204x42 | 3.5 | 5.386 | 5.926 | 5.142 | 5.1423 | 5.012 | 5.1238 | 0.847 | 20 x 8 ft, Ra 0.340 | BEARING |
| CR-P6 | F4 | 171x171x33 | 3.5 | 5.199 | 5.755 | 5.083 | 5.0833 | 4.923 | 5.0107 | 0.779 | 14 x 8 ft, Ra 0.338 | BEARING |
| CR-P6 | F5 | 126x126x24 | 3.5 | 4.944 | 5.562 | 5.041 | 4.9443 | 4.811 | 4.8749 | 0.675 | 8 x 8 ft, Ra 0.356 | BEARING |
| CR-P6 | W1 | 153x363x30 | 3.5 | 4.939 | 4.744 | 4.447 | 4.4467 | 4.364 | 4.4437 | 0.739 | 26 x 8 ft, Ra 0.331 | BEARING |

Worked example (CR-P5 F3, B = L = 10.5 ft, D = 3.5 ft, FS = 2.5, no groundwater correction): sigma_zD = 3.5 x 0.118 = 0.413 ksf. Terzaghi: Nc = 27.1, Nq = 14.2, Ngamma = 10.7, sc = 1.3, sgamma = 0.8 -> q_ult = 0.25(27.1)(1.3) + 0.413(14.2) + 0.5(0.118)(10.5)(10.7)(0.8) = 20.0 ksf -> 7.57 ksf net allowable. Meyerhof: Nc = 22.3, Nq = 11.9, Ngamma = 8.0, Kp = 2.56, s = 1.51/1.26/1.26, d = 1.11/1.05/1.05 -> q_ult = 22.3 ksf -> 8.52 ksf. Brinch Hansen: Ngamma = 7.9, sc = 1.48, sq = 1.44, sgamma = 0.6, dc = 1.06, dq = 1.10 -> q_ult = 19.4 ksf -> 7.35 ksf (relied on). Applied net pressure 781/(10.5 x 10.5) = 7.08 ksf (7.16 ksf including the excess weight of concrete over soil) < 7.35 ksf.
