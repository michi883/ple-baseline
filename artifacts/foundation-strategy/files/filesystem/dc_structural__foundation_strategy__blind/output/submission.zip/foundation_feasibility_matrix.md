# Foundation-type feasibility and optimisation matrix - Cattail Run Data Campus Phase 1 (AV-CR-2604)

All foundations are analysed as individual units (RFI-017). Demand = service D+L reaction (load memo); bearing = least of Terzaghi / Meyerhof (1963) / Brinch Hansen (1970) per UFC 3-220-20 Eq 5-14/5-15 with the Fig 5-6 groundwater correction and the Table 2-3 factor of safety; settlement = layered elastic compression per RFI-019 (2V:1H, 0.25 ft layers, depth max(4B, 40 ft)); improved footings use the GEC 13 two-layer method (Eq 5-11 to 5-14, n_s = 10, pad-specific k_g). Reported settlement is the largest of four computation variants (stratum assignment by layer mid-height or by exact split; top-of-pier stress from net or gross bearing pressure). Angular distortion limit 1/500 (UFC 3-220-01 2-4.7.1). Costs are at the bid-schedule and Kettleridge project budget prices (concrete, reinforcing, excavation, backfill, dewatering, piers, platform); modulus tests and rig mobilisation are carried at pad/campus level.

Station spacing of adjacent units on column line A: F1-F2 24 ft (limit 0.576 in), F2-F3 20 ft (0.480 in), F3-F4 16 ft (0.384 in), F4-F5 12 ft (0.288 in), F5-W1 5 ft (0.120 in).


## CR-P1 - Data Hall 1

Occupancy Light Industrial, Public, FS = 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 8.0 ft. Stratum I base 6.0 ft (sta 0) to 12.5 ft (sta 77); Es I/II/III = 110/1500/3500 ksf; k_g = 165 pci. Concrete: F1/W1/C1/S1, f'c = 4000 psi, w/cm <= 0.50 (sulfate 0.14 % = Moderate condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 610.0 | IMPROVED_SPREAD | 135 x 135 | 27 | I | 4.892 | 4.957 | 0.987 | 0.659 | 9 x 8 | 0.3490 | 12880 | BEARING | $6,540 | SPREAD 96x96 in, t=24 in @ D=96 in ($14,369) |
| F2 | 24 | 1180.0 | IMPROVED_SPREAD | 186 x 186 | 39 | I | 5.016 | 5.087 | 0.986 | 0.751 | 17 x 8 | 0.3473 | 13229 | BEARING | $14,043 | SPREAD 129x129 in, t=36 in @ D=96 in ($19,394) |
| F3 | 44 | 1420.0 | IMPROVED_SPREAD | 204 x 204 | 42 | I | 5.026 | 5.121 | 0.981 | 0.794 | 20 x 8 | 0.3397 | 13477 | BEARING | $17,429 | SPREAD 237x237 in, t=42 in @ D=96 in ($41,423) |
| F4 | 60 | 980.0 | IMPROVED_SPREAD | 171 x 171 | 33 | I | 4.914 | 5.062 | 0.971 | 0.740 | 14 x 8 | 0.3384 | 13240 | BEARING | $11,246 | SPREAD 234x234 in, t=36 in @ D=96 in ($38,940) |
| F5 | 72 | 520.0 | IMPROVED_SPREAD | 126 x 126 | 24 | I | 4.781 | 4.906 | 0.974 | 0.697 | 8 x 8 | 0.3561 | 12419 | BEARING | $5,612 | SPREAD 180x180 in, t=27 in @ D=96 in ($26,418) |
| W1 | 77 | 1650.0 | IMPROVED_SPREAD | 147 x 378 | 30 | I | 4.356 | 4.366 | 0.998 | 0.702 | 26 x 9 | 0.3307 | 12067 | BEARING | $20,591 | SPREAD 333x408 in, t=33 in @ D=96 in ($81,049) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 6.0 | 4.957 | 5.548 | 5.023 | 4.957 | 4.820 | 4.892 | 0.605 | 0.490 | 0.115 |
| F2 | 8.0 | 5.246 | 5.784 | 5.087 | 5.087 | 4.912 | 5.016 | 0.691 | 0.501 | 0.190 |
| F3 | 9.7 | 5.348 | 5.880 | 5.121 | 5.121 | 4.913 | 5.025 | 0.731 | 0.510 | 0.222 |
| F4 | 11.1 | 5.161 | 5.708 | 5.062 | 5.062 | 4.826 | 4.914 | 0.681 | 0.502 | 0.179 |
| F5 | 12.1 | 4.906 | 5.515 | 5.020 | 4.906 | 4.717 | 4.781 | 0.628 | 0.472 | 0.156 |
| W1 | 12.5 | 4.847 | 4.627 | 4.366 | 4.366 | 4.276 | 4.356 | 0.643 | 0.453 | 0.190 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.092 | 0.576 | 1/3140 | 0.16 |
| F2-F3 | 20 | 0.044 | 0.480 | 1/5516 | 0.09 |
| F3-F4 | 16 | 0.054 | 0.384 | 1/3526 | 0.14 |
| F4-F5 | 12 | 0.058 | 0.288 | 1/2462 | 0.20 |
| F5-W1 | 5 | 0.021 | 0.120 | 1/2911 | 0.17 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 708.0 k, H = 96.0 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.81 with 0.6 x footing/backfill weight (N = 827 k) and 0.5 Pp = 11.6 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 1650 k, H = 96.0 k, M = 880 k-ft) | e = 9.1 in (envelope); B/6 = 24.5 in, L/6 = 63.0 in | middle third | OK |
| Uplift | UPLIFT_W (U = 260.0 k) | FS = 3.05; 0.6(Wf 145 + Ws 53 + D 1180)/U = 3.18 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: IMPROVED_SPREAD.** Spread-only alternative $221,593 (bearing depth 96 in, 0 dewatering days) vs improved $84,960 (footings $53,315 + piers $21,784 + platform $361 + modulus test $9,500; mobilisation carried at campus level). 



## CR-P2 - Data Hall 2

Occupancy Light Industrial, Public, FS = 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 9.0 ft. Stratum I base 13.5 ft (sta 0) to 9.0 ft (sta 77); Es I/II/III = 85/1400/3400 ksf; k_g = 140 pci. Concrete: F1/W1/C1/S2, f'c = 4500 psi, w/cm <= 0.45 (sulfate 0.23 % = Severe condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 646.6 | IMPROVED_SPREAD | 138 x 138 | 27 | I | 4.961 | 5.050 | 0.982 | 0.954 | 9 x 9 | 0.3340 | 13488 | BEARING | $7,204 | SPREAD 219x219 in, t=27 in @ D=120 in ($48,386) |
| F2 | 24 | 1250.8 | IMPROVED_SPREAD | 192 x 192 | 39 | I | 4.990 | 5.140 | 0.971 | 0.954 | 19 x 8 | 0.3643 | 12696 | BEARING | $15,771 | SPREAD 264x264 in, t=39 in @ D=120 in ($64,585) |
| F3 | 44 | 1505.2 | IMPROVED_SPREAD | 210 x 210 | 42 | I | 5.027 | 5.176 | 0.971 | 0.918 | 21 x 8 | 0.3365 | 13574 | BEARING | $19,218 | SPREAD 225x225 in, t=42 in @ D=120 in ($53,639) |
| F4 | 60 | 1038.8 | IMPROVED_SPREAD | 174 x 174 | 36 | I | 5.037 | 5.109 | 0.986 | 0.844 | 15 x 8 | 0.3502 | 13198 | BEARING | $12,308 | SPREAD 117x117 in, t=33 in @ D=120 in ($26,971) |
| F5 | 72 | 551.2 | IMPROVED_SPREAD | 129 x 129 | 27 | I | 4.842 | 4.999 | 0.968 | 0.766 | 8 x 8 | 0.3398 | 13021 | BEARING | $6,025 | SPREAD 87x87 in, t=24 in @ D=120 in ($21,577) |
| W1 | 77 | 1749.0 | IMPROVED_SPREAD | 159 x 357 | 30 | I | 4.517 | 4.517 | 1.000 | 0.823 | 27 x 8 | 0.3362 | 12319 | BEARING | $21,609 | SPREAD 96x294 in, t=24 in @ D=120 in ($38,616) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 13.5 | 5.050 | 5.654 | 5.067 | 5.050 | 4.889 | 4.961 | 0.886 | 0.605 | 0.280 |
| F2 | 12.1 | 5.356 | 5.908 | 5.140 | 5.140 | 4.886 | 4.990 | 0.855 | 0.566 | 0.289 |
| F3 | 10.9 | 5.458 | 6.005 | 5.176 | 5.176 | 4.915 | 5.027 | 0.844 | 0.605 | 0.239 |
| F4 | 10.0 | 5.254 | 5.816 | 5.109 | 5.109 | 4.941 | 5.037 | 0.776 | 0.590 | 0.185 |
| F5 | 9.3 | 4.999 | 5.620 | 5.063 | 4.999 | 4.770 | 4.842 | 0.700 | 0.583 | 0.117 |
| W1 | 9.0 | 5.028 | 4.849 | 4.517 | 4.517 | 4.437 | 4.517 | 0.754 | 0.547 | 0.208 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.030 | 0.576 | 1/9490 | 0.05 |
| F2-F3 | 20 | 0.040 | 0.480 | 1/5941 | 0.08 |
| F3-F4 | 16 | 0.074 | 0.384 | 1/2594 | 0.19 |
| F4-F5 | 12 | 0.078 | 0.288 | 1/1836 | 0.27 |
| F5-W1 | 5 | 0.058 | 0.120 | 1/1043 | 0.48 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 750.5 k, H = 101.8 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.80 with 0.6 x footing/backfill weight (N = 872 k) and 0.5 Pp = 12.5 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 1749 k, H = 101.8 k, M = 933 k-ft) | e = 9.1 in (envelope); B/6 = 26.5 in, L/6 = 59.5 in | middle third | OK |
| Uplift | UPLIFT_W (U = 275.6 k) | FS = 3.04; 0.6(Wf 148 + Ws 55 + D 1251)/U = 3.16 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: IMPROVED_SPREAD.** Spread-only alternative $266,374 (bearing depth 120 in, 3 dewatering days) vs improved $91,635 (footings $59,330 + piers $22,428 + platform $377 + modulus test $9,500; mobilisation carried at campus level). 



## CR-P3 - Electrical Yard Building

Occupancy Light Industrial, Public, FS = 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 19.0 ft. Stratum I base 5.5 ft (sta 0) to 7.0 ft (sta 77); Es I/II/III = 210/1700/3700 ksf; k_g = 210 pci. Concrete: F1/W1/C1/S0, f'c = 4000 psi, w/cm <= 0.50 (sulfate 0.07 % = Negligible condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 439.2 | SPREAD | 111 x 111 | 21 | I | 5.189 | 5.202 | 0.997 | 0.630 | - | - | - | BEARING | $2,825 | IMPROVED 111x111 in, 6 piers x 8 ft ($4,192) |
| F2 | 24 | 849.6 | SPREAD | 153 x 153 | 33 | I | 5.314 | 5.399 | 0.984 | 0.837 | - | - | - | BEARING | $6,260 | IMPROVED 153x153 in, 11 piers x 8 ft ($8,767) |
| F3 | 44 | 1022.4 | SPREAD | 168 x 168 | 33 | I | 5.304 | 5.472 | 0.969 | 0.966 | - | - | - | BEARING | $7,804 | IMPROVED 168x168 in, 14 piers x 8 ft ($10,992) |
| F4 | 60 | 705.6 | SPREAD | 141 x 141 | 27 | I | 5.183 | 5.345 | 0.970 | 0.922 | - | - | - | BEARING | $4,999 | IMPROVED 141x141 in, 10 piers x 8 ft ($7,276) |
| F5 | 72 | 374.4 | SPREAD | 105 x 105 | 21 | I | 4.946 | 5.130 | 0.964 | 0.816 | - | - | - | BEARING | $2,492 | IMPROVED 105x105 in, 6 piers x 8 ft ($3,856) |
| W1 | 77 | 1188.0 | SPREAD | 108 x 360 | 24 | I | 4.464 | 4.476 | 0.997 | 0.891 | - | - | - | BEARING | $8,527 | IMPROVED 114x336 in, 18 piers x 8 ft ($12,690) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 5.5 | 5.203 | 5.947 | 5.236 | 5.203 | 5.133 | 5.189 | 0.622 | 0.000 | 0.622 |
| F2 | 6.0 | 5.707 | 6.421 | 5.399 | 5.399 | 5.226 | 5.314 | 0.823 | 0.000 | 0.823 |
| F3 | 6.4 | 5.887 | 6.605 | 5.472 | 5.472 | 5.216 | 5.304 | 0.949 | 0.000 | 0.949 |
| F4 | 6.7 | 5.563 | 6.278 | 5.345 | 5.345 | 5.111 | 5.183 | 0.909 | 0.000 | 0.909 |
| F5 | 6.9 | 5.130 | 5.887 | 5.220 | 5.130 | 4.890 | 4.946 | 0.806 | 0.000 | 0.806 |
| W1 | 7.0 | 4.987 | 4.752 | 4.476 | 4.476 | 4.400 | 4.464 | 0.877 | 0.000 | 0.877 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.208 | 0.576 | 1/1386 | 0.36 |
| F2-F3 | 20 | 0.128 | 0.480 | 1/1867 | 0.27 |
| F3-F4 | 16 | 0.044 | 0.384 | 1/4400 | 0.11 |
| F4-F5 | 12 | 0.111 | 0.288 | 1/1293 | 0.39 |
| F5-W1 | 5 | 0.088 | 0.120 | 1/680 | 0.73 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 509.8 k, H = 69.1 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.77 with 0.6 x footing/backfill weight (N = 589 k) and 0.5 Pp = 7.5 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 1188 k, H = 69.1 k, M = 634 k-ft) | e = 9.1 in (envelope); B/6 = 18.0 in, L/6 = 60.0 in | middle third | OK |
| Uplift | UPLIFT_W (U = 187.2 k) | FS = 2.98; 0.6(Wf 81 + Ws 51 + D 850)/U = 3.15 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: SPREAD.** Spread-only $32,907 vs improved alternative $97,273 (footings and piers $47,773 + modulus test $9,500 + a third rig $40,000, because the two mobilised rigs already serve four pads). 



## CR-P4 - Administration and Operations Building

Occupancy Apartments, Office, FS = 3.0 (UFC 3-220-01 Table 2-3). Bearing depth 42 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 8.0 ft. Stratum I base 6.0 ft (sta 0) to 9.5 ft (sta 77); Es I/II/III = 130/1600/3600 ksf; k_g = 195 pci. Concrete: F1/W1/C1/S1, f'c = 4000 psi, w/cm <= 0.50 (sulfate 0.11 % = Moderate condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 384.3 | IMPROVED_SPREAD | 102 x 102 | 21 | I | 5.375 | 5.551 | 0.968 | 0.596 | 5 x 8 | 0.3397 | 14266 | BEARING | $3,403 | SPREAD 114x114 in, t=21 in @ D=42 in ($2,799) |
| F2 | 24 | 743.4 | IMPROVED_SPREAD | 138 x 138 | 30 | I | 5.701 | 5.767 | 0.988 | 0.686 | 9 x 8 | 0.3340 | 15261 | BEARING | $6,811 | SPREAD 192x192 in, t=30 in @ D=42 in ($9,159) |
| F3 | 44 | 894.6 | IMPROVED_SPREAD | 153 x 153 | 33 | I | 5.591 | 5.787 | 0.966 | 0.700 | 11 x 8 | 0.3321 | 15051 | BEARING | $8,623 | SPREAD 237x237 in, t=33 in @ D=42 in ($14,663) |
| F4 | 60 | 617.4 | IMPROVED_SPREAD | 126 x 126 | 27 | I | 5.672 | 5.710 | 0.993 | 0.645 | 8 x 8 | 0.3561 | 14469 | BEARING | $5,605 | SPREAD 201x201 in, t=27 in @ D=42 in ($9,505) |
| F5 | 72 | 327.6 | IMPROVED_SPREAD | 96 x 96 | 21 | I | 5.175 | 5.512 | 0.939 | 0.532 | 5 x 8 | 0.3834 | 12553 | BEARING | $3,129 | SPREAD 141x141 in, t=21 in @ D=42 in ($4,117) |
| W1 | 77 | 1039.5 | IMPROVED_SPREAD | 96 x 330 | 21 | I | 4.781 | 4.791 | 0.998 | 0.607 | 15 x 8 | 0.3346 | 12946 | BEARING | $9,890 | SPREAD 183x432 in, t=24 in @ D=42 in ($17,210) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 6.0 | 5.551 | 6.291 | 5.762 | 5.551 | 5.319 | 5.375 | 0.554 | 0.467 | 0.087 |
| F2 | 7.1 | 5.789 | 6.431 | 5.767 | 5.767 | 5.621 | 5.701 | 0.639 | 0.500 | 0.140 |
| F3 | 8.0 | 5.888 | 6.509 | 5.787 | 5.787 | 5.503 | 5.591 | 0.652 | 0.491 | 0.161 |
| F4 | 8.7 | 5.710 | 6.376 | 5.758 | 5.710 | 5.600 | 5.672 | 0.602 | 0.474 | 0.127 |
| F5 | 9.3 | 5.512 | 6.278 | 5.770 | 5.512 | 5.119 | 5.175 | 0.493 | 0.410 | 0.083 |
| W1 | 9.5 | 5.215 | 5.005 | 4.791 | 4.791 | 4.725 | 4.781 | 0.563 | 0.419 | 0.144 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.090 | 0.576 | 1/3208 | 0.16 |
| F2-F3 | 20 | 0.015 | 0.480 | 1/16546 | 0.03 |
| F3-F4 | 16 | 0.055 | 0.384 | 1/3469 | 0.14 |
| F4-F5 | 12 | 0.113 | 0.288 | 1/1273 | 0.39 |
| F5-W1 | 5 | 0.075 | 0.120 | 1/797 | 0.63 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 446.0 k, H = 60.5 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.70 with 0.6 x footing/backfill weight (N = 505 k) and 0.5 Pp = 5.6 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 1040 k, H = 60.5 k, M = 554 k-ft) | e = 8.9 in (envelope); B/6 = 16.0 in, L/6 = 55.0 in | middle third | OK |
| Uplift | UPLIFT_W (U = 163.8 k) | FS = 2.93; 0.6(Wf 58 + Ws 40 + D 743)/U = 3.08 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: IMPROVED_SPREAD.** Spread-only alternative $57,453 (bearing depth 42 in, 0 dewatering days) vs improved $46,960 (footings $25,385 + piers $11,872 + platform $203 + modulus test $9,500; mobilisation carried at campus level). 



## CR-P5 - Logistics and Spares Warehouse

Occupancy Warehouse, FS = 2.5 (UFC 3-220-01 Table 2-3). Bearing depth 42 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 21.0 ft. Stratum I base 4.5 ft (sta 0) to 5.5 ft (sta 77); Es I/II/III = 250/1800/3800 ksf; k_g = 230 pci. Concrete: F3/W1/C1/S0, f'c = 5000 psi, w/cm <= 0.40 (sulfate 0.05 % = Negligible condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 335.5 | SPREAD | 87 x 87 | 18 | I | 6.431 | 6.919 | 0.929 | 0.477 | - | - | - | BEARING | $1,712 | IMPROVED 87x87 in, 4 piers x 8 ft ($2,622) |
| F2 | 24 | 649.0 | SPREAD | 114 x 114 | 24 | I | 7.255 | 7.286 | 0.996 | 0.681 | - | - | - | BEARING | $3,317 | IMPROVED 114x114 in, 7 piers x 8 ft ($4,909) |
| F3 | 44 | 781.0 | SPREAD | 126 x 126 | 27 | I | 7.156 | 7.348 | 0.974 | 0.772 | - | - | - | BEARING | $4,230 | IMPROVED 126x126 in, 8 piers x 8 ft ($6,051) |
| F4 | 60 | 539.0 | SPREAD | 105 x 105 | 21 | I | 7.096 | 7.221 | 0.983 | 0.750 | - | - | - | BEARING | $2,682 | IMPROVED 105x105 in, 6 piers x 8 ft ($4,046) |
| F5 | 72 | 286.0 | SPREAD | 81 x 81 | 18 | I | 6.325 | 6.818 | 0.928 | 0.631 | - | - | - | BEARING | $1,481 | IMPROVED 87x87 in, 4 piers x 8 ft ($2,599) |
| W1 | 77 | 907.5 | SPREAD | 75 x 297 | 15 | I | 5.907 | 5.919 | 0.998 | 0.717 | - | - | - | BEARING | $4,565 | IMPROVED 75x297 in, 11 piers x 8 ft ($7,070) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 4.5 | 6.919 | 7.975 | 7.195 | 6.919 | 6.383 | 6.431 | 0.473 | 0.000 | 0.473 |
| F2 | 4.8 | 7.373 | 8.341 | 7.286 | 7.286 | 7.191 | 7.255 | 0.663 | 0.000 | 0.663 |
| F3 | 5.1 | 7.575 | 8.526 | 7.349 | 7.349 | 7.084 | 7.156 | 0.742 | 0.000 | 0.742 |
| F4 | 5.3 | 7.221 | 8.209 | 7.246 | 7.221 | 7.040 | 7.096 | 0.734 | 0.000 | 0.734 |
| F5 | 5.4 | 6.818 | 7.909 | 7.190 | 6.818 | 6.277 | 6.325 | 0.626 | 0.000 | 0.626 |
| W1 | 5.5 | 6.345 | 6.192 | 5.919 | 5.919 | 5.867 | 5.907 | 0.711 | 0.000 | 0.711 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.204 | 0.576 | 1/1411 | 0.35 |
| F2-F3 | 20 | 0.091 | 0.480 | 1/2630 | 0.19 |
| F3-F4 | 16 | 0.022 | 0.384 | 1/8625 | 0.06 |
| F4-F5 | 12 | 0.135 | 0.288 | 1/1065 | 0.47 |
| F5-W1 | 5 | 0.102 | 0.120 | 1/589 | 0.85 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 389.4 k, H = 52.8 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.59 with 0.6 x footing/backfill weight (N = 428 k) and 0.5 Pp = 3.4 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 908 k, H = 52.8 k, M = 484 k-ft) | e = 8.9 in (envelope); B/6 = 12.5 in, L/6 = 49.5 in | middle third | OK |
| Uplift | UPLIFT_W (U = 143.0 k) | FS = 2.84; 0.6(Wf 29 + Ws 35 + D 649)/U = 2.99 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: SPREAD.** Spread-only $17,986 vs improved alternative $76,798 (footings and piers $27,298 + modulus test $9,500 + a third rig $40,000, because the two mobilised rigs already serve four pads). 



## CR-P6 - Data Hall 3

Occupancy Light Industrial, Public, FS = 3.5 (UFC 3-220-01 Table 2-3). Bearing depth 45 in (frost minimum 42 in, AHJ LC-BD-26-0774 Amd 3). Groundwater 8.5 ft. Stratum I base 14.0 ft (sta 0) to 6.5 ft (sta 77); Es I/II/III = 95/1450/3450 ksf; k_g = 155 pci. Concrete: F1/W1/C1/S2, f'c = 4500 psi, w/cm <= 0.45 (sulfate 0.26 % = Severe condition).

| Tag | Sta (ft) | Demand P(D+L) kips | Type | B x L (in) | t (in) | Stratum | q_net (ksf) | q_allow,net (ksf) | q_net/q_allow | Settlement (in) | Piers (N x ft) | Ra | Top-of-pier (psf) | Governing | Cost chosen | Alternative (cost) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 0 | 622.2 | IMPROVED_SPREAD | 135 x 135 | 27 | I | 4.988 | 4.995 | 0.999 | 0.933 | 9 x 9 | 0.3490 | 13113 | BEARING | $6,962 | SPREAD 315x315 in, t=27 in @ D=45 in ($24,826) |
| F2 | 24 | 1203.6 | IMPROVED_SPREAD | 186 x 186 | 36 | I | 5.106 | 5.108 | 1.000 | 0.819 | 17 x 8 | 0.3473 | 13447 | BEARING | $14,377 | SPREAD 429x429 in, t=39 in @ D=45 in ($56,691) |
| F3 | 44 | 1448.4 | IMPROVED_SPREAD | 204 x 204 | 42 | I | 5.124 | 5.142 | 0.996 | 0.847 | 20 x 8 | 0.3397 | 13719 | BEARING | $18,047 | SPREAD 423x423 in, t=42 in @ D=45 in ($58,379) |
| F4 | 60 | 999.6 | IMPROVED_SPREAD | 171 x 171 | 33 | I | 5.011 | 5.083 | 0.986 | 0.779 | 14 x 8 | 0.3384 | 13479 | BEARING | $11,587 | SPREAD 300x300 in, t=36 in @ D=45 in ($26,121) |
| F5 | 72 | 530.4 | IMPROVED_SPREAD | 126 x 126 | 24 | I | 4.875 | 4.944 | 0.986 | 0.675 | 8 x 8 | 0.3561 | 12644 | BEARING | $5,747 | SPREAD 180x180 in, t=27 in @ D=45 in ($7,973) |
| W1 | 77 | 1683.0 | IMPROVED_SPREAD | 153 x 363 | 30 | I | 4.444 | 4.447 | 0.999 | 0.739 | 26 x 8 | 0.3309 | 12283 | BEARING | $20,710 | SPREAD 246x429 in, t=33 in @ D=45 in ($30,527) |

Bearing capacity by method (net allowable q_ult/FS - sigma_zD, ksf; UFC 3-220-20 Eq 5-14/5-15, groundwater correction per Fig 5-6) and settlement components:

| Tag | Stratum I base (ft) | Terzaghi | Meyerhof (1963) | Brinch Hansen (1970) | Reported (least) | q_net (P/A) | q_net reported | s primary (in) | s_uz piers (in) | s soil / lower zone (in) |
|---|---|---|---|---|---|---|---|---|---|---|
| F1 | 14.0 | 4.995 | 5.595 | 5.044 | 4.995 | 4.916 | 4.988 | 0.872 | 0.532 | 0.340 |
| F2 | 11.7 | 5.284 | 5.830 | 5.108 | 5.108 | 5.010 | 5.106 | 0.756 | 0.544 | 0.212 |
| F3 | 9.7 | 5.386 | 5.926 | 5.142 | 5.142 | 5.012 | 5.124 | 0.781 | 0.553 | 0.227 |
| F4 | 8.2 | 5.199 | 5.755 | 5.083 | 5.083 | 4.923 | 5.011 | 0.717 | 0.545 | 0.172 |
| F5 | 7.0 | 4.944 | 5.562 | 5.041 | 4.944 | 4.811 | 4.875 | 0.619 | 0.512 | 0.107 |
| W1 | 6.5 | 4.939 | 4.744 | 4.447 | 4.447 | 4.364 | 4.444 | 0.676 | 0.491 | 0.185 |

Adjacent-unit differential settlement (largest over computation variants):

| Pair | Spacing (ft) | Delta s (in) | Limit (in) | Angular distortion | Ratio to 1/500 |
|---|---|---|---|---|---|
| F1-F2 | 24 | 0.117 | 0.576 | 1/2471 | 0.20 |
| F2-F3 | 20 | 0.029 | 0.480 | 1/8349 | 0.06 |
| F3-F4 | 16 | 0.068 | 0.384 | 1/2823 | 0.18 |
| F4-F5 | 12 | 0.104 | 0.288 | 1/1384 | 0.36 |
| F5-W1 | 5 | 0.064 | 0.120 | 1/944 | 0.53 |

Shear-wall footing W1 stability (load memo; UFC 3-220-01 2-4.6.3; UFC 3-220-20 Eq 5-5, Fig 5-41; EM 1110-2-2502 para 3-8):

| Check | Combination | Result | Requirement | Status |
|---|---|---|---|---|
| Sliding | 0.6D + W (N = 722.2 k, H = 97.9 k) | reported FS = 2.30 (friction on 0.6D only); FS = 2.80 with 0.6 x footing/backfill weight (N = 841 k) and 0.5 Pp = 12.0 k | FS >= 2.0 | OK |
| Overturning (resultant) | D + L + W (P = 1683 k, H = 97.9 k, M = 898 k-ft) | e = 9.1 in (envelope); B/6 = 25.5 in, L/6 = 60.5 in | middle third | OK |
| Uplift | UPLIFT_W (U = 265.2 k) | FS = 3.05; 0.6(Wf 145 + Ws 53 + D 1204)/U = 3.17 | FS >= 1.5 | OK |

**Governing constraint (pad): BEARING.** 
**Decision: IMPROVED_SPREAD.** Spread-only alternative $204,519 (bearing depth 45 in, 0 dewatering days) vs improved $86,930 (footings $55,761 + piers $21,308 + platform $361 + modulus test $9,500; mobilisation carried at campus level). 



## Campus programme

| Pad | Decision | Spread-only cost | Improved cost (excl. mobilisation) | Chosen pad cost |
|---|---|---|---|---|
| CR-P1 | IMPROVED_SPREAD | $221,593 | $84,960 | $84,960 |
| CR-P2 | IMPROVED_SPREAD | $266,374 | $91,635 | $91,635 |
| CR-P3 | SPREAD | $32,907 | $57,273 | $32,907 |
| CR-P4 | IMPROVED_SPREAD | $57,453 | $46,960 | $46,960 |
| CR-P5 | SPREAD | $17,986 | $36,798 | $17,986 |
| CR-P6 | IMPROVED_SPREAD | $204,519 | $86,930 | $86,930 |
| Mobilisation | 2 rigs x $40,000 | | | $80,000 |
| **Campus total** | | | | **$441,378** |
