# Building A2 - Roof Diaphragm and Shear Wall Lateral Package: Design Basis

Northern Divide Data Campus, Building A2, Lewis and Clark County, Montana. Delegated lateral design of the roof deck diaphragm, chords and collectors, deck-to-panel embeds and panel base tie-downs for wind, to EOR-NDDC-A2-S01 Structural Design Criteria Revision 2 (14 August 2026).

**All loads, unit shears, line loads, reactions, chord and collector forces and deflections reported in this package are ALLOWABLE STRESS DESIGN (ASD) quantities, obtained from the strength-level wind effect by the load combination 0.6W (criteria 3.3).**

## 1. Values the design was built on

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 Topographic Wind Study section 4 (applied over the whole footprint per EOR-NDDC-A2-S01 Rev 2 clause 4.3) |
| Ke | 0.867 | EOR-NDDC-A2-S01 Rev 2 clause 4.4, Ke = exp(-0.0000362 zg) with zg = 3941.02 ft (ALTA-2025-77 site benchmark BM-2) |
| q_h_psf | 28.74 | EOR-NDDC-A2-S01 Rev 2 clause 4.2 at mean roof height 28.00 ft (Kz = 0.9681, Kd = 0.85, V = 115 mph per NDDC-AHJ-014) |
| screen_wall_top_ft | 36.00 | SR-2026-118 Roof Line Scan Report clause 5.2 and the 2026 federated model (panels N108-N111, x = 96 ft to 168 ft) |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026, opening S14-O1 (field-cut after erection, 8.0 ft x 12.0 ft at x = 194.5 ft) |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Rev 2 clause 3.3 |
| omega_d | 2.35 | CDS-B36 Diaphragm Design Manual Note 2 |
| analysis_method | semi-rigid diaphragm, DIAPH-MT 1.0 finite element membrane model | EOR-NDDC-A2-S01 Rev 2 section 9; NDDC-AHJ-014 section 3 |
| mesh_level | L2 | EOR-NDDC-A2-S01 Rev 2 clause 9.7 (H = 5.0 ft) |

## 2. Governing wind scenario for each wall line

| line | governing scenario |
|---|---|
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

The governing scenario above is the one producing the largest roof-level line load on the wall line (schedule ShearWalls, column line_load_plf). The scenarios producing the largest in-plane reaction (shear wall load) on each line are: S W07, E W05, N1 W07, W W01, N2 W08, E2 W01.

## 3. Design summary

* Roof deck: 4 distinct CDS-B36 deck types (Owner limit 4, OBD-NDDC-A2 4.6): D18-36/9-5, D22-36/4-2, D22-36/4-4, D22-36/7-4.
  * Z11: D22-36/4-2, G' used 17.80 kip/in, ASD capacity 417 plf, area 3600 sf, peak ASD unit shear 365 plf (W06).
  * Z12: D18-36/9-5, G' used 63.50 kip/in, ASD capacity 1791 plf, area 3600 sf, peak ASD unit shear 387 plf (W01).
  * Z13: D22-36/4-2, G' used 17.80 kip/in, ASD capacity 417 plf, area 3600 sf, peak ASD unit shear 359 plf (W08).
  * Z21: D22-36/4-4, G' used 22.90 kip/in, ASD capacity 528 plf, area 3600 sf, peak ASD unit shear 203 plf (W06).
  * Z22: D22-36/4-2, G' used 20.47 kip/in, ASD capacity 417 plf, area 3200 sf, peak ASD unit shear 179 plf (W05).
  * Z23: D22-36/7-4, G' used 32.60 kip/in, ASD capacity 843 plf, area 3400 sf, peak ASD unit shear 229 plf (W08).
  * Z31: D22-36/4-4, G' used 22.90 kip/in, ASD capacity 528 plf, area 3600 sf, peak ASD unit shear 221 plf (W04).
  * Z32: D22-36/4-4, G' used 22.90 kip/in, ASD capacity 528 plf, area 3200 sf, peak ASD unit shear 317 plf (W02).
  * Z33: D22-36/7-4, G' used 32.60 kip/in, ASD capacity 843 plf, area 3400 sf, peak ASD unit shear 755 plf (W08).
  * Z41: D22-36/4-4, G' used 22.90 kip/in, ASD capacity 528 plf, area 3600 sf, peak ASD unit shear 324 plf (W04).
  * Z42: D22-36/7-4, G' used 32.60 kip/in, ASD capacity 843 plf, area 3600 sf, peak ASD unit shear 265 plf (W02).
  * Z43: D22-36/4-4, G' used 22.90 kip/in, ASD capacity 528 plf, area 1200 sf, peak ASD unit shear 507 plf (W08).
* Chords and collectors (KRS-CH, ASTM A572 Gr 50 plate, continuous over full length): C-S PL3x3/8, C-N1 PL3x3/8, C-N2 PL3x3/8, C-E PL3x3/8, C-E2 PL12x1, C-W PL3x3/8, K-N2 PL3x3/8, K-E2 PL3x3/8, O-S PL3x3/8, O-N PL3x3/8, O-W PL3x3/8, O-E PL3x3/8.
* Deck-to-panel embeds E1: 199 total; panel base tie-downs T1: 9 panels (N201, N202, N204, E201, E202, E203, E204, N110, N112).
* Installed cost: deck $144160 + chords/collectors $18405 + embeds $36815 + tie-downs $22050 = **$221430** (cap $310,000, OBD-NDDC-A2 4.7).
* Largest diaphragm deflection relative to the supporting piers: 0.521 in (limit 0.55 in, criteria 8.2 / OBD 4.4).
* Mesh convergence: reaction of wall line W under W01 = 48.04 kips at L2 and 48.12 kips at L3, change 0.18 % (limit 5 %, criteria 9.7).
* The DIAPH-MT implementation reproduces verification example VE-1 (criteria 9.8): 240 elements / 273 nodes, reactions 10.00 / 10.00 kips, largest unit shear 185.2 plf, largest chord bar force 2.57 kips, largest Y displacement 0.1669 in.

## 4. Analysis basis

* Wind: V = 115 mph (NDDC-AHJ-014), Risk Category III, Exposure C, Kd = 0.85, Kzt = 1.19, Ke = 0.867; q(z) = 0.00256 Kz Kzt Kd Ke V^2 with Kz = 2.01 (z/900)^(2/9.5), z >= 15 ft. q_h = 28.74 psf at 28.00 ft; q_p = 29.37 psf at the 31.00 ft parapet top and 30.31 psf at the 36.00 ft screen wall top.
* Wall patches: p = q_h Cp on the gross patch area (doors and louvres included, criteria 6.3); parapet patches p = q_p GCpn (net, both faces). Internal pressure (GCpi = +/-0.18) cancels in the net MWFRS force and is not included (criteria 4.1).
* Each panel spans vertically foundation-to-deck (h = 28.00 ft): R_roof = p A z / h, so the parapet and screen wall above the deck (z > h) deliver more than their own force to the diaphragm (criteria 6.4). The roof-level line load of a wall line is the sum of R_roof over its patches divided by the line length, applied along the wall normal as uniform consistent nodal loads.
* Torsional cases W09-W12: all line loads x 0.75 plus M_T = e B |F| (e = +/-0.15, B = 240 ft for N wind, 180 ft for E wind), applied as nodal forces proportional to tributary area and radius from the diaphragm area centroid (114.55 ft, 85.00 ft); positive e is a counter-clockwise moment (x east, y north).
* Piers: legs between opening edges, legs narrower than 2.0 ft neglected; cantilever h = 28.00 ft, Ec = 4030 ksi, G = 0.40 Ec; k = 1/(h^3/(3 Ec I) + 1.2 h/(G A)). Springs attached at the node nearest the leg mid-point.
* Diaphragm: square mesh H = 5.0 ft (L2) on the as-built roof outline less the mechanical well; bilinear membrane elements, 2 x 2 Gauss; EAx = 4.0 in2 x 29,000 ksi / 40 ft = 2,900 kip/ft (girders); EAy = 2.4 in2 x 29,000 / 5 ft = 13,920 kip/ft (joists), 17,400 kip/ft in Z22 (joists at 4 ft); Ghat = 12 G'. Chords and collectors as bars of the scheduled area.
* Deck capacity = nominal / 2.35 (CDS-B36 Note 2). G' x 1.15 in Z22 for the 4 ft deck span (CDS-B36 Note 4, stiffness only).
* Connections: E1 embed 4.20 kips ASD, spacing <= 8 ft o.c., minimum 2 per panel; count taken conservatively as the larger of max(2, ceil(L/8)+1) (embeds within 8 ft of each panel end and of each other) and ceil(V/4.20). B1 base connection 1.40 klf x L checked against the panel in-plane shear. Stability 0.6D + 0.6W: OTM = V x 28 ft vs 0.6 W L/2 on the gross panel; T1 tie-down (88 kips at lever arm L) provided where required.

## 5. Conflicts between issued documents and how they were resolved

1. Topographic factor: EOR-NDDC-A2-S01 Revision 0 (superseded) and the Hall B (Building A1) study carry Kzt = 1.00; the site-specific study TS-2026-02 gives Kzt = 1.19 over the whole footprint. Criteria Revision 2 clause 4.3 adopts the study, so Kzt = 1.19 was used.

2. Basic wind speed and risk category: Revision 0, the 2024 pre-application memorandum and the Hall B study use 105 mph at Risk Category II; the AHJ letter NDDC-AHJ-014 accepts 115 mph at Risk Category III and supersedes the memorandum. V = 115 mph, Risk Category III used.

3. Ground elevation factor: Revision 0 and the Hall B study took Ke = 1.0; criteria Revision 2 clause 4.4 requires Ke = exp(-0.0000362 zg) with zg from the ALTA survey benchmark. zg = 3941.02 ft (BM-2) gives Ke = 0.867 (the finished floor elevation 3940.0 ft gives the same value to 3 decimals).

4. Mechanical screen wall: the 2024 precast panel schedule PC-S01 (not reissued) shows panels N108-N111 with top of panel 31.00 ft; the roof line scan SR-2026-118 clause 5.2, the federated model and A-301 Rev C show 36.00 ft between x = 96 ft and x = 168 ft. The as-built model and scan govern (criteria 5.3): the screen wall parapet patches use q_p at 36.00 ft, an 8.00 ft strip above the deck delivering R_roof = p A (32/28).

5. Field-cut opening in panel S14: the federated model shows opening S14-O1, 8.0 ft wide x 12.0 ft high at x = 194.5-202.5 ft, cut after erection; it is not on the 2024 precast schedule PC-S01, nor on PC-S02 Rev 2 (its note 4 excludes field-cut openings) or A-301 Rev C. The model governs: S14 has a 2.5 ft leg (192.0-194.5 ft) carried as a pier and a 1.5 ft leg (202.5-204.0 ft) neglected under criteria 5.4.

6. Roof outline: the superseded A-101 Revision A shows a plain 240 ft x 180 ft rectangle; A-101 Rev C, S-201 Rev C, the federated model and the roof line scan show the generator yard notch (x = 180-240 ft, y = 140-180 ft, no roof) and the mechanical well opening (x = 100-140 ft, y = 100-130 ft). The as-built outline was used: deck area 39,600 sf, zone Z43 1,200 sf, zones Z22/Z32 3,200 sf and Z23/Z33 3,400 sf.

7. Superseded precast elevations: PC-S02 Revision 1 shows the S10 opening at 138-154 ft and an S14 opening; PC-S02 Rev 2 and the federated model show S10 at 136-152 ft. Revision 1 was not used; the federated model governs all panel and opening geometry.

8. Diaphragm idealisation: Revision 0 permitted a rigid distribution and the Hall B study used a flexible tributary distribution; criteria Revision 2 section 9 and the AHJ letter section 3 reject both for Building A2. The semi-rigid DIAPH-MT 1.0 model was used, verified against VE-1.

9. Parapet height: Revision 0 assumed a uniform 3 ft parapet; the as-built parapet is 3.00 ft (top 31.00 ft) except the 8.00 ft screen wall. As-built heights used.

10. Line E2 wall normal: geometrically the generator yard lies east of x = 180 ft, but the federated model places the E2 panels on the west side of the line (x = 179.33-180.00 ft) and WT-2026-07 reports E2 as windward for west winds (GCpn = +1.5 at 225-315 deg) and leeward for east winds. The coefficients were applied with the wall normal implied by the model and the study (E2 line load positive toward +x), consistently with how the data were derived; this is flagged to the EOR for confirmation.

11. Parapet coefficient at oblique incidence: WT-2026-07 section 6.3 describes interpolation on the cosine of incidence, while the issued data file gives the full +1.5 / -1.0 at 45 deg. The data file values (the issued coefficients the criteria refers to in 6.1) were used without modification.

12. Deck span: SJ-201 Note 1 states joists at 5 ft 0 in on centre and a typical deck span of 6 ft 0 in, the span at which CDS-B36 tabulates G' (Note 4). The typical zones were taken at the tabulated G' (no adjustment); in Z22 the joists are at 4 ft 0 in (SJ-201 Note 2, S-201) and G' x 1.15 was used, stiffness only (criteria 7.3). The smeared joist rigidity EAy uses the joist spacing (5 ft typical, 4 ft in Z22).

13. Deflection limit: criteria clause 2 points to the more restrictive of the code and UFC 3-301-01 Table 2-1; Table 2-1 governs framing supporting exterior finishes and does not address diaphragm deflection. The 0.55 in limit of OBD-NDDC-A2 4.4, adopted in criteria 8.2, governs the diaphragm, with pier drift limited to h/400 = 0.84 in (criteria 8.3).

14. Precast panel schedule versus model: apart from the screen wall and S14, PC-S01 (2024) agrees with the federated model on panel marks, lengths, thicknesses and cast openings; the model was used throughout (T-204 lists PC-S01 as for information, superseded by the federated model).

15. Hall B Lateral Study (Building A1, 2023) values - 105 mph, Kzt = Ke = 1.00, q_h = 18.9 psf, flexible distribution, 302 plf, single 22 ga 36/4 deck - belong to another building and were not used.

16. Wind study azimuths: WT-2026-07 section 2 describes 36 azimuths at 10 degree increments, a set that does not contain the 45, 135, 225 and 315 degree azimuths at which it reports coefficients, while stating that the reported azimuths envelope the measured set. The issued data-file coefficients were used as reported, at the eight azimuths the criteria (4.5) adopts for the twelve scenarios.

17. Survey benchmark: ALTA-2025-77 lists two monuments (BM-1 at 3936.18 ft, BM-2 at 3941.02 ft) and the finished floor at 3940.0 ft; BM-2 is named the site benchmark and was used for zg (criteria 4.4). The choice changes Ke by less than 0.02 %.

18. Embed spacing: KRS-CN 2.3 sets a maximum 8 ft 0 in spacing and a minimum of two per panel; the count was taken conservatively with embeds within 8 ft of each panel end (max(2, ceil(L/8)+1)) or the count needed for the panel shear at 4.20 kips each, whichever is larger.

