# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

All loads in this package are strength-level seismic load effects (1.0E, rho = 1.0) and all capacities are LRFD design strengths (phi Rn): deck phi = 0.60 (BDS-2026-DT Table 4 / AISI S310), connectors, tie-downs and wall anchors phi = 0.75 (RPC-CAT-2026), steel members phi = 0.90. No ASD values are used anywhere (SDC-02 s9).

## 1. Seismic basis

* Code: 2024 IBC as adopted by Montana, ASCE/SEI 7-22, ACI 318-19, AISI S310 (SDC-02 s1). Reference copy of the system table is UFC 3-301-01 Table 3-1, which replaces ASCE 7-22 Table 12.2-1 and has the same precast shear wall coefficients.
* Risk Category III, Ie = 1.25 (SDC-02 s2, OBD-CDDC-B s1.4: county 911 emergency communications tenant; ASCE 7-22 s11.5.1 / Table 1.5-2).
* Site Class D from the measured Vs,100 = 905 ft/s in GEO-2026-071 s4.
* USGS ASCE 7-22 output for RC III / Site Class D at 46.6832, -111.9756: Ss = 0.49, S1 = 0.13, SMS = 0.66, SM1 = 0.36, **SDS = 0.44, SD1 = 0.24**, TL = 6 s.
* SDC: SDS gives C (Table 11.6-1) but SD1 = 0.24 >= 0.20 gives D (Table 11.6-2); the more severe governs, **SDC D** (ASCE 7-22 s11.6, SDC-02 s3). The s11.6 exception (SDS only) is not available: the diaphragm is flexible and the vertical elements are 180-240 ft apart.
* hn = 28 ft (roof diaphragm; the 3 ft parapet is not a level), Ta = Ct hn^x = 0.02 x 28^0.75 = 0.243 s (Eq. 12.8-7).
* Cs = SDS/(R/Ie) = 0.44/(4/1.25) = **0.1375** (Eq. 12.8-2); Cs,max = SD1/(T R/Ie) = 0.308 (Eq. 12.8-3); Cs,min = 0.0242 (Eq. 12.8-5).
* Effective seismic weight W = 2270.5 kips (roof 20 psf x 39,200 sf net = 784.0; phase-1 RTUs 45.0; wall lines 1.716 klf x 840 ft = 1441.5); future mass case 2286.5 kips.
* Base shear V = Cs W = **312.2 kips** (future 314.4 kips). One storey: Cvx = 1.0, the whole V acts at the roof (s12.8.3).
* Wall weight tributary to the roof uses the lever action of the 3 ft parapet cantilever (SDC-02 s6, FEMA P-2192-V1 s7.6.1 Step 1): w = 100 psf x 31 x (31/2)/28 = **1716 plf** (tributary height 17.16 ft).
* Diaphragm force (s12.10.1.1): Fpx/wpx = 0.1375 (between 0.2 SDS Ie = 0.110 and 0.4 SDS Ie = 0.220). wpx,X = 1446.8 kips (roof + RTUs + W and E walls), Fpx,X = 198.9 kips, w_px = 1105 plf over the 180 ft N-S span; wpx,Y = 1652.7 kips (roof + RTUs + S and N walls), Fpx,Y = 227.2 kips, w_px = 947 plf over the 240 ft E-W span. The parallel wall lines carry their own inertia directly (DAP-2 s5).
* Construction stage (S11, S12): 0.5 x permanent seismic load, Ie, R and accidental torsion unchanged (ERC-07 s3), deck east of X = 180 ft not fastened (ERC-07 s4).
* Redundancy rho = 1.0 (s12.3.4.2(a): removal of any one 10 ft panel pier, h/l = 2.8, removes far less than 33 % of the storey strength and creates no extreme torsional irregularity). No horizontal irregularity (Ax = 1.00 in every case, openings 9 % of the plan), so the s12.3.3.4 25 % increase does not apply; collectors are in any case designed with Omega0.

## 2. Seismic force-resisting system

**Selected: Intermediate precast shear walls, bearing wall system - UFC 3-301-01 Table 3-1 row A.6 (= ASCE 7-22 Table 12.2-1 A.6), detailing ACI 318-19 s18.5. R = 4, Omega0 = 2.5 (2.0 for collectors by footnote b, flexible diaphragm, SDC-02 s4), Cd = 4.** Permitted in SDC D up to hn = 40 ft (the 45 ft footnote i does not apply to a data centre); Building B hn = 28 ft. PROC-114 key: `intermediate_precast`.

Why it is the cost-efficient choice (SDC-02 s4 asks for the balance of detailing/qualification cost against R):
* Ordinary precast shear walls (row A.7) are **not permitted (NP) in SDC D** although they carry the lowest premium ($940/panel).
* Special reinforced concrete (special precast) shear walls (row A.1, footnote h) give R = 5 (20 % lower forces) but cost $4,120 per panel in SFRS premium: 81 panels x $4,120 = $333,720 before any other item, and any joint connectors must be the RPC-60D (ACI ITG-5.2 qualified, $1,240 each). Even with the cheapest tie-downs the special system totals at least $491,814, above the $395,000 cap. The 20 % force reduction cannot buy back the $183,870 premium difference.
* Intermediate precast: premium 81 x $1,850 = $149,850; the RPC-24/RPC-40 connectors are qualified for it, but the design uses none (isolated panel piers, JC0) - see s9.

## 3. As-built geometry

The scan (CDDC-SV-2026-041) was registered to the building grid with the four high-intensity CP spheres (rigid fit, residual < 0.001 ft, rotation 1.742 deg). The wall planes are at X = 0 / 240 ft and Y = 0 / 180 ft (inside faces), and the openings in the cloud match ERL-2026-08. Design geometry (RFI-041: the erected geometry governs; PR-07: semi-rigid model on erected geometry):

| Wall | Openings (as built) | Piers / spandrels used (start, length ft) |
|---|---|---|
| S | D-1 18-32, D-2 48-62, **D-3 78-93.5 (15.5 ft)**, **D-4 109.5-123.5**, D-5 138-152, P-1 196-200 | 0/18, 32/16, 62/16, 93.5/16, **123.5/14.5**, 152/44, 200/40 |
| N | P-2 24-28 (door), L-1 60-72 (louver, 14-24 ft), **L-2 154-170 (16 ft louver)** | 0/24, 28/32, spandrel 60/12, 72/82, spandrel 154/16, 170/70 |
| W | P-3 12-16, **EY-1 66-110 (44 ft, 20 ft high)** | 0/12, 16/50, 110/70 |
| E | D-6 72-86, L-3 108-120 (louver), P-4 150-154 | 0/72, 86/22, spandrel 108/12, 120/30, 154/26 |

Panels are 10 ft nominal from the start of each segment with the remainder last (as in the record layout); louver segments are spandrels whose EI and GAv are factored by the solid height fraction 18/28 (DAP-2 s3).

Conflicts found and the reading taken:

* **risk category** - used: III (Ie = 1.25). Basis: SDC-02 Rev 2 s2 and OBD-CDDC-B s1.4 (county 911 emergency communications tenant). The Risk Category II in the A-101 cover-sheet code block (schematic issue) and the RC II USGS run are superseded.
* **site class** - used: D. Basis: GEO-2026-071 s4 (Vs,100 = 905 ft/s, boring B-204 on the Building B parcel). GEO-2019-118 (Site Class C) covers adjacent Parcel 4B under ASCE 7-16 and is superseded for Building B (SDC-02 s3).
* **ground motion parameters** - used: SDS = 0.44, SD1 = 0.24 (ASCE 7-22, RC III, Site Class D). Basis: USGS ASCE7-22 RiskCatIII SiteClassD output named in SDC-02 s3. The ASCE7-16 Site Class C file (SDS 0.407, SD1 0.149) is the 2019 Parcel 4B basis and does not apply.
* **seismic design category** - used: D. Basis: ASCE 7-22 s11.6: SDS = 0.44 gives SDC C (Table 11.6-1) but SD1 = 0.24 gives SDC D (Table 11.6-2); the more severe governs (SDC-02 s3). The s11.6 SDS-only exception is not available because the diaphragm is flexible and the vertical elements are more than 40 ft apart.
* **as built wall openings** - used: S: D-3 78.0-93.5 ft (15.5 ft), D-4 109.5-123.5 ft, pier D-4/D-5 = 14.5 ft; N: L-2 154-170 ft (16 ft); W: EY-1 66-110 ft (44 ft). Basis: RFI-041 (EOR: design to the erected geometry), ERL-2026-08 and the 7 Aug 2026 scan registered to the building grid with the four CP targets (CDDC-SV-2026-041). PC-101 Rev 2 / A-101 opening sizes are detailed (record) sizes only.
* **louver L2 panel mark** - used: L-2 16 ft wide starting at X = 154 ft. Basis: PCS-014 ticket N-12 Rev B gives the 16 ft width and the 2 ft westward move; the scan and ERL locate it at 154-170 ft. The panel mark in PCS-014 does not match the PC-101 numbering; the scan governs (RFI-041).
* **building plan dimensions** - used: 240.0 ft x 180.0 ft between inside faces of the precast panels (grid origin at inside face). Basis: CDDC-SV-2026-041 s3 grid definition and the registered scan (walls at X = 0/240, Y = 0/180). A-101 note 1 calls 240 x 180 out-to-out; the drawn wall line and scan show it is the inside-face dimension.
* **diaphragm idealisation** - used: envelope of flexible, rigid and semi-rigid (DAP-2). Basis: ASCE 7-22 s12.3.1.1 permits a flexible idealisation, but PR-07 Comment 7 (accepted, SDC-02 Rev 2 s10) requires the envelope computed by DAP-2 on the erected geometry.
* **collector overstrength** - used: Omega0 = 2.0 (2.5 - 0.5, footnote b); collectors also verified at 2.5. Basis: UFC 3-301-01 Table 3-1 footnote b (same as ASCE 7-22 Table 12.2-1) and SDC-02 s4: flexible-diaphragm structure. PR-07 governs force distribution, not the system classification.
* **diaphragm design method** - used: ASCE 7-22 s12.10.1 and s12.10.2. Basis: SDC-02 s5: s12.10.3 and s12.10.4 not used; the s12.10 exception for precast diaphragms does not apply to the bare steel deck.
* **wall tributary weight** - used: 1716 plf = 100 psf x 31^2/(2 x 28) (17.16 ft tributary height). Basis: SDC-02 s6 and FEMA P-2192-V1 s7.6.1 Step 1: the parapet lever action is included instead of the simple h/2 + parapet (1700 plf).
* **wall anchorage force** - used: Fp = 0.2 ka Ie Wp = 858 plf (governs over 0.4 SDS ka Ie Wp = 755 plf), ka = 2.0; steel anchorage elements x1.4. Basis: ASCE 7-22 s12.11.2.1 Eq. 12.11-1 with its minimum, Eq. 12.11-2 with Lf from UFC 3-301-01 Fig. 3-1 (240 ft for S/N, 180 ft for W/E), s12.11.2.2.2.
* **construction stage load** - used: 0.5 x permanent seismic load, deck east of X = 180 ft unfastened. Basis: ERC-07 s3 (ASCE 37-14, period < 1 yr) and s4; Ie, R and accidental torsion unchanged.
* **future rtus** - used: RTU-7F and RTU-8F (8 kips each) included in the future mass case. Basis: OBD-CDDC-B s2.2 and SDC-02 s8; M-601 Rev 3 positions. A-101 Rev 1 (without RTU-5/6) is superseded by Rev 3.
* **superseded and other building documents** - used: not used. Basis: T-2026-118: 90_archive documents are for record only. SM-2019-04 is Building A (RC II, ASCE 7-16, Site C); WM-2026-09 wind (138/184 kips) does not govern the seismic base shear.
* **structural height and period** - used: hn = 28 ft (roof diaphragm), Ta = 0.02 x 28^0.75 = 0.243 s. Basis: ASCE 7-22 s12.8.2.1; DAP-2 s3 (parapet is not part of the in-plane cantilever). hn = 28 ft <= 40 ft limit for intermediate precast in SDC D.
* **design format** - used: LRFD throughout (strength level E, phi factors). Basis: SDC-02 s9; BDS-2026-DT phi = 0.60; RPC-CAT-2026 phi = 0.75.

## 4. Analysis

DAP-2 Rev 1 was implemented exactly and verified against Appendix A (VP-1): k_seg = 1279.4 kip/in, joint shears 0.2630 / 0.2527 kip/kip, panel-1 base moment 88.91 kip-in/kip, axial 0.2630 kip/kip, isolated piers 769.2 kip/in - all reproduced.

* Stage A: each segment condensed to k_seg (Ec = 57,000 sqrt(6000) = 4415 ksi, Gc = Ec/2.4, I = 0.5 Ig, Av = 5/6 Ag, h = 28 ft). With JC0 every panel is an isolated cantilever pier; tie-down T = M_base/(0.8 L) + N.
* Stage B: 10 ft plane-stress mesh (392 elements, openings removed), D = diag(1740, 1740, G'zone) kip/in, 2x2 Gauss, chord/collector bars EA = 29,000 A, segment springs spread over the nodes in proportion to tributary length; RTUs at their own (nearest) nodes.
* Loads: Fpx/wpx x tributary mass; accidental torsion 0.05 x 180 ft (X) or 0.05 x 240 ft (Y) x applied force as a mass-proportional rotational field about the centre of mass, both signs; Ax from the rigid model = 1.00 in all cases (max/avg wall-line displacement ratio below 1.2).
* Idealisations: flexible simple beam (unit shear V/net depth, chord M/net depth, no torsion), rigid (membrane x 10^7) and semi-rigid; every force is the largest of the three; deflection/drift from semi-rigid; 100/30 cases add 0.30 x the companion case (DAP-2 s6.4).
* Robustness: besides the 12 SDC-02 cases, all 24 combinations (X/Y, +/-, base/future, single/100-30, final/erection) were checked, and the results were re-run with alternative protocol readings (torsion on total force, linear spring spreading, bilinear RTU spreading, merged spandrels, length-proportional own inertia, support-section flexible shear). Margins below hold for all of them.

## 5. Diaphragm and wall forces

Wall line loads F_x (kips, LRFD, envelope, own inertia of the parallel wall line included):

| Case | Dir | S | N | W | E | Ax | max zone v_u (plf) | Cd*delta/Ie (in) |
|---|---|---|---|---|---|---|---|---|
| S01 | X | 155.0 | 172.3 | 4.5 | 4.5 | 1.00 | 508 (Z11) | 1.53 |
| S02 | X | 155.6 | 164.2 | 12.7 | 12.7 | 1.00 | 513 (Z4) | 1.53 |
| S03 | Y | 8.5 | 8.5 | 155.6 | 166.2 | 1.00 | 809 (Z1) | 2.88 |
| S04 | Y | 10.2 | 10.2 | 162.6 | 156.6 | 1.00 | 864 (Z1) | 2.91 |
| S05 | X | 157.6 | 174.9 | 51.2 | 54.4 | 1.00 | 680 (Z4) | 1.59 |
| S06 | Y | 56.9 | 59.4 | 166.4 | 160.4 | 1.00 | 988 (Z1) | 2.97 |
| S07 | X | 155.7 | 173.8 | 4.6 | 4.6 | 1.00 | 515 (Z11) | 1.55 |
| S08 | Y | 8.4 | 8.4 | 155.9 | 167.9 | 1.00 | 815 (Z1) | 2.89 |
| S09 | X | 159.3 | 168.5 | 61.5 | 60.2 | 1.00 | 711 (Z4) | 1.62 |
| S10 | Y | 56.7 | 59.5 | 166.7 | 162.3 | 1.00 | 995 (Z1) | 2.98 |
| S11 | X | 52.1 | 56.5 | 0.0 | 0.0 | 1.00 | 206 (Z10) | 0.74 |
| S12 | Y | 36.2 | 36.2 | 105.4 | 0.0 | 1.00 | 679 (Z1) | 3.40 |

Deck attachment zones (DAP-2 s6.1 zone design shear, envelope of all 24 checked cases):

| Zone | Pattern | Net area (sf) | phiSn (plf) | Demand v_u (plf, all cases) | D/C | G' (kip/in) |
|---|---|---|---|---|---|---|
| Z1 | P5 (36/9, #12 TEK @ 9 in) | 3120 | 1101 | 995 | 0.90 | 61.0 |
| Z2 | P3 (36/7, #10 TEK @ 18 in) | 2480 | 663 | 523 | 0.79 | 38.0 |
| Z3 | P3 (36/7, #10 TEK @ 18 in) | 3600 | 663 | 497 | 0.75 | 38.0 |
| Z4 | P5 (36/9, #12 TEK @ 9 in) | 3600 | 1101 | 836 | 0.76 | 61.0 |
| Z5 | P4 (36/7, #10 TEK @ 12 in) | 3600 | 852 | 691 | 0.81 | 49.0 |
| Z6 | P4 (36/7, #10 TEK @ 12 in) | 3312 | 852 | 436 | 0.51 | 49.0 |
| Z7 | P2 (36/4, #10 TEK @ 18 in) | 3168 | 474 | 348 | 0.73 | 26.5 |
| Z8 | P4 (36/7, #10 TEK @ 12 in) | 3600 | 852 | 773 | 0.91 | 49.0 |
| Z9 | P5 (36/9, #12 TEK @ 9 in) | 3600 | 1101 | 822 | 0.75 | 61.0 |
| Z10 | P5 (36/9, #12 TEK @ 9 in) | 2928 | 1101 | 612 | 0.56 | 61.0 |
| Z11 | P4 (36/7, #10 TEK @ 12 in) | 2592 | 852 | 648 | 0.76 | 49.0 |
| Z12 | P4 (36/7, #10 TEK @ 12 in) | 3600 | 852 | 781 | 0.92 | 49.0 |

Maximum amplified deflection Cd delta/Ie = 3.79 in (governing: E_Y+1_o, erection-stage cantilever of the fastened deck) <= 4.0 in (SDC-02 s7); final-stage maximum 2.98 in. Storey drift of the wall lines is below 0.2 in amplified, far inside 0.015 hsx = 5.04 in (Table 12.12-1).

Chords, collectors and drag struts (all 24 cases):

| Line | Member | Demand (kips) | Amplified (Omega0=2.0 / 2.5) | phiPn (kips) |
|---|---|---|---|---|
| CH-S | C1 L4x4x3/8 | 56.7 | n/a (chord) | 92.7 |
| CH-N | C1 L4x4x3/8 | 56.4 | n/a (chord) | 92.7 |
| CH-W | C1 L4x4x3/8 | 25.9 | n/a (chord) | 92.7 |
| CH-E | C1 L4x4x3/8 | 25.2 | n/a (chord) | 92.7 |
| DR-S1 | C1 L4x4x3/8 | 4.1 | 8.3 / 10.4 | 92.7 |
| DR-S2 | C1 L4x4x3/8 | 3.5 | 7.0 / 8.7 | 92.7 |
| DR-N1 | C1 L4x4x3/8 | 2.8 | 5.5 / 6.9 | 92.7 |
| DR-N2 | C1 L4x4x3/8 | 2.8 | 5.7 / 7.1 | 92.7 |
| DR-W1 | C1 L4x4x3/8 | 4.0 | 8.1 / 10.1 | 92.7 |
| DR-W2 | C1 L4x4x3/8 | 4.5 | 8.9 / 11.2 | 92.7 |
| DR-E1 | C1 L4x4x3/8 | 2.5 | 4.9 / 6.1 | 92.7 |
| DR-E2 | C1 L4x4x3/8 | 2.2 | 4.4 / 5.5 | 92.7 |
| OP-1S | C1 L4x4x3/8 | 3.6 | n/a (chord) | 92.7 |
| OP-1N | C1 L4x4x3/8 | 5.1 | n/a (chord) | 92.7 |
| OP-1W | C1 L4x4x3/8 | 3.1 | n/a (chord) | 92.7 |
| OP-1E | C1 L4x4x3/8 | 3.1 | n/a (chord) | 92.7 |
| OP-2S | C1 L4x4x3/8 | 5.5 | n/a (chord) | 92.7 |
| OP-2N | C1 L4x4x3/8 | 6.1 | n/a (chord) | 92.7 |
| OP-2W | C1 L4x4x3/8 | 4.1 | n/a (chord) | 92.7 |
| OP-2E | C1 L4x4x3/8 | 4.6 | n/a (chord) | 92.7 |

## 6. Wall anchorage and the parapet cantilever

* Wp = 1716 plf per foot of wall (panel spans foundation-to-roof and cantilevers 3 ft; reaction at the roof = w H^2/(2h)). Parapet transfer (the part delivered by the wall above the deck) = 100 x 3 x (28 + 1.5)/28 = **316.1 plf** on every wall line.
* Lf from UFC 3-301-01 Fig. 3-1: 240 ft for the S and N walls, 180 ft for the W and E walls, so ka = 1 + Lf/100 capped at **2.0** both ways (Eq. 12.11-2).
* Fp = 0.4 SDS ka Ie Wp = 755 plf, but not less than 0.2 ka Ie Wp = 858 plf, so **Fp = 858 plf** (Eq. 12.11-1). Steel anchorage elements x 1.4 (s12.11.2.2.2) = 1201 plf.
* Anchors WA2 (embed plate + strap to subdiaphragm tie) at 10 ft on all four walls: demand 1.4 x 0.858 x 10 = 12.01 kips <= 0.75 x 18.6 = 13.95 kips. Panel flexure between anchors (spacing > 4 ft) is checked by the panel designer (s12.11.2.1).
* Continuous ties: N-S ties are the joist-girder lines at X = 40...200 ft (spliced for tension), E-W ties every 4th joist line (24 ft); the deck is not used as a tie perpendicular to its span (s12.11.2.2.4). Subdiaphragms: S/N 30 ft deep (sub-chords on the joists at Y = 30 and 150 ft, clear of RO-2 and RO-1) x 40 ft span between girder ties (ratio 1.33); W 36 ft deep (clear of RO-2) and E 40 ft deep x 24 ft span (ratios 0.67 and 0.60); all <= 2.5 (s12.11.2.2.1). Subdiaphragm unit shear 572 plf (S/N) and 286 plf (W/E) <= phiSn of every edge zone (min 663 plf).

## 7. Governing constraint per wall line

| Wall | Governing check | D/C | Tie-down max / phiTn (kips) | Anchor demand / phiTn (kips) | Subdiaphragm span/depth |
|---|---|---|---|---|---|
| S | diaphragm_shear: deck diaphragm shear in zone Z1 along the wall line (DAP-2 s6.1), D/C 0.90 (next: wall_anchorage 0.86, tie_down 0.79) | 0.90 | 52.2 / 66.0 | 12.01 / 13.95 | 40/30 = 1.33 <= 2.5 |
| N | diaphragm_shear: deck diaphragm shear in zone Z12 along the wall line (DAP-2 s6.1), D/C 0.92 (next: wall_anchorage 0.86, chord_collector 0.61) | 0.92 | 33.8 / 66.0 | 12.01 / 13.95 | 40/30 = 1.33 <= 2.5 |
| W | diaphragm_shear: deck diaphragm shear in zone Z1 along the wall line (DAP-2 s6.1), D/C 0.90 (next: wall_anchorage 0.86, tie_down 0.74) | 0.90 | 48.7 / 66.0 | 12.01 / 13.95 | 24/36 = 0.67 <= 2.5 |
| E | diaphragm_shear: deck diaphragm shear in zone Z12 along the wall line (DAP-2 s6.1), D/C 0.92 (next: wall_anchorage 0.86, tie_down 0.64) | 0.92 | 42.4 / 66.0 | 12.01 / 13.95 | 24/40 = 0.60 <= 2.5 |

Overall, the amplified diaphragm deflection in the erection condition (3.79 in vs 4.0 in) and the zone shears in Z1, Z8 and Z12 govern the deck (Z4 carries P5 for margin against alternative readings of the protocol); the 100/30 tie-down demand governs the BA2 selection on every wall (BA1 at 33 kips is exceeded on all four lines, N by a small margin).

## 8. Cost

PROC-114 Rev 2 rates and quantity basis:

| Item | Quantity | Cost (USD) |
|---|---|---|
| Deck attachment (net zone areas) | 39,200 sf | 77,814 |
| Chords, collectors, drag struts (C1 on all 20 lines) | 2,080 lf | 23,712 |
| Panel joint connectors (JC0) | 0 | 0 |
| Base tie-downs BA2 | 81 panels | 73,710 |
| Wall anchors WA2 @ 10 ft | 84 | 14,448 |
| SFRS premium, intermediate precast | 81 panels | 149,850 |
| **Total installed cost** | | **339,534** |
| Capital cap (PROC-114, OBD s5.6) | | 395,000 |

The lateral scope is $55,466 (14.0 %) under the cap.

## 9. Alternatives rejected

* Special precast / special RC shear walls (R = 5): exceeds the cap on the premium alone (s2). Ordinary precast: NP in SDC D.
* Joint connectors (JC1/JC2): they stiffen the segments (k_seg +20-80 %), attract more force in the rigid idealisation and, per the DAP-2 tie-down definition (base couple including the joint moments plus coupling axial force), raise the tie-down demand per kip by 15-35 %; with 58 joints they add $22k-$140k and do not allow BA1. JC0 (isolated panel piers) is cheaper on every line.
* BA1 tie-downs: demand 33.8-52.2 kips exceeds phiTn = 33 kips. BA3 unnecessary.
* WA1 joist-seat anchors: with Fp = 858 plf and the 1.4 steel-element factor they need 4 ft spacing ($20,160) vs WA2 @ 10 ft ($14,448); WA3 costs more.
* Uniform P1/P2 deck: fails zone shear in the end zones (rigid idealisation, up to ~1000 plf) and the 4.0 in deflection (5.4 in final, 6.9 in erection with P2 everywhere). The zoned layout above was found by a cost-driven search over all 12 zones against every case.
* Omitting drag struts at the louvers (L-1 12 ft, L-2 16 ft, L-3 12 ft): SDC-02 s5 requires a continuous drag strut across every wall opening 12 ft wide or wider, so DR-N1, DR-N2 and DR-E2 are provided (C1) even though the louvers do not reach the foundation; leaving them out would save $3,762 but would not satisfy the criterion.
* Heavier chords (C2-C4): the governing chord force (56.7 kips, flexible M/d at the RO-1/RO-2 section) is within phiPn of C1 (92.7 kips); drag-strut forces are small because the as-built piers are distributed along every line.
* ASD: phi/1.0 = 0.60 vs 1/(0.7 x 2.55) = 0.56 for the deck and 0.75 vs 0.71 for connectors - LRFD is more economical and is used throughout.
