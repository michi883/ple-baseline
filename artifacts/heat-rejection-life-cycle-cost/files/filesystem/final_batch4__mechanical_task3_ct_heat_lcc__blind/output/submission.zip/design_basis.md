# Design Basis - Condenser Water Heat Rejection Replacement, Papago Federal Center (95 % CD)

Prepared by the plant designer for the mechanical engineer of record. Criteria memorandum DC-02 Revision 3 governs the allocation of subject matter among the documents; EC-01 Revision 0 governs the life-cycle cost analysis.

## 1. Governing documents

- DC-02 Revision 3 (14 Aug 2026) - criteria, conventions, deliverable formats (supersedes Revision 2).
- UFC 3-410-01 (28 Jul 2025, Change 1) - outdoor design conditions for equipment sizing (2-4.2.4: 1.0 % WB + 5 F for open towers); IMC 908.5 amendment 3-2.8.2 (automatic blowdown and chemical feed).
- GSA PBS-P100 (2024) - plant configuration (5.3.2.3: matching cell per chiller, equalizing lines and automatic valves, VFDs, 4 ft roof-to-basin clearance), redundancy (5.1.3 cooling robustness), siting separations (Table 5.2: 25 ft to outdoor air intakes), materials (5.3.3.11: no galvanized water-contact surfaces), roof-mounted equipment (5.3.2.6).
- UFM 3-230-13 (5 Feb 2026) with WT-01 Revision 1 - water balance, cycles of concentration, scaling indices.
- 10 CFR 431 Subpart B (431.25(h) Table 5) - fan motor efficiency; 10 CFR 436 Subpart A - life-cycle cost method.
- EC-01 Revision 0 and the 2025 Annual Supplement data tables (NIST data release doi:10.18434/mds2-3848) - discount rate, UPV* factors.
- EnergyPlus reference implementation and data sets in vendor_data/ - YorkCalc variable-speed tower correlation and limits, tower fan/water-use logic, Chiller:Electric:EIR model, psychrometrics; CurveManager input clamping.
- Submittals VD-01 to VD-05; schedules M-601 Rev C, M-603, E-601 Rev C; drawings M-401 Revision C, S-401 Rev C, E-501 Rev C; site letters PW-LTR-014, PW-LTR-019, UT-01; WT-01; RFI-031 and RFI-034; Section 23 65 00.

Retained for reference only and not used as authority: UFC 3-230-13 (2023, superseded by UFM 3-230-13), UFC 3-400-02 (cancelled), NIST IR 85-3273-39 (2024 supplement; text consulted for method only, none of its numbers used), M-401 Revision B (superseded), DC-02 Revision 2, and the Tucson LCD record (not part of the POR).

## 2. Documented conflicts (DC-02 9.1)

CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE GSA PBS-P100 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 (5 February 2026) Chapter 5 and Appendix A | SET ASIDE UFC 3-230-13 (1 March 2023) Chapter 5 and Appendix A
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

Resolution notes: (1) DC-02 paragraph 2 allocates outdoor design conditions for equipment sizing to UFC 3-410-01, so tower selection uses the 1.0 % annual wet bulb + 5 F of 2-4.2.4 (and DC-02 5.2), not the P100 5.3.1 0.4 % dew point/MCDB basis; P100 still governs the cooling-robustness (redundancy) case through 5.1.3, as RFI-031 Response 1 confirms. (2) UFM 3-230-13 supersedes UFC 3-230-13 (DC-02 2, RFI-031 Response 3). (3) M-401 Revision C fixes the equipment zones and intake positions; Revision B is superseded (DC-02 2, RFI-031 Response 3, Rev B title block).

Other disagreements resolved: P100 5.3.5.3 TDS cap of 1,500 ppm does not govern the reclaimed supply (DC-02 2; chemistry by UFM 3-230-13 and WT-01). ANNEX annual allocation is 12,600 kgal per PW-LTR-019 (amending PW-LTR-014). MCC-R3 spare capacity is reduced per RFI-034 by the three exhaust fans (3 x 7.5 hp / 0.917 / 0.97 = 18.86 kW) to 641.14 kW. The 2025 data tables govern all rates and factors (EC-01 4). Chiller reference capacity is a normalising constant; available capacity uses the CAPFT curve (M-601 Note 5). UFC 3-410-01 2-18 discourages roof-mounted equipment, but DC-02 2 allocates roof-mounted equipment to P100, whose 5.3.2.6 permits cooling towers on the roof. Water quality: of the WQP visits, the 2023 visits are field-parameter-only; the most recent complete analysis (2022-07-26) is the analysis of record and the 2021 analysis is superseded (WT-01 2); dissolved results, Ca (not total hardness) and ROE TDS are used. Section 23 25 00 (excerpt) covers closed systems only; the condenser water programme is WT-01. Vendor standard offerings that do not comply are not selected: G-235 galvanised casing (P100 5.3.3.11), DE-1 eliminator (23 65 00 2.3), economy motors (10 CFR 431.25(h)). M-601 Rev C supersedes Rev B.

## 3. Climatic and property basis

- POR: NCEI LCD Phoenix Airport (72278023183) 2022, 2023, 2024; FM-15 and FM-16 rows only (27412 observations; 26527 with both dry and wet bulb). Suspect-flagged values (suffix s) are read at their numeric value; blank and "*" are missing.
- 1.0 % annual wet bulb = 75 F (value exceeded by 1 % of observations, single annual population). WEATHER BASIS (tower selection, design point, design approach, redundancy capacity check): UFC 3-410-01 paragraph 2-4.2.4 adder +5 F -> WBDESIGN = 80.0 F (DC-02 5.2, RFI-031 Response 1).
- Failure-case (cooling robustness) wet bulb: GSA PBS-P100 5.1.3 0.4 % evaporation wet bulb = 76 F + 5 F = 81.0 F (DC-02 5.2 and 6.3, RFI-031 Response 1). The YorkCalc object clamps inlet WB at 26.6667 C (80 F), so both the design point and the failure case are evaluated at the clamp (DC-02 6.8).
- 99.6 % annual dry bulb = 41 F > 32 F: basin heaters and heat-traced makeup are NOT required (DC-02 5.4) -> BASINHEATER NO.
- Barometric pressure = mean POR station pressure 28.722 inHg = 97264 Pa (DC-02 5.5). Water 8.33 lb/gal, 1.0 Btu/lb-F: Q (Btu/h) = 500 x gpm x range.
- Scenario bins: 2 F WB x 5 F DB bins with edges at multiples of the width from 0 F, mid-points as bin condition, DB raised to the WB mid-point where lower, counts scaled to 8760 h; 180 occupied bins. Block load from M-603 at the bin DB (linear, ends held).

## 4. Calculation methods

- Tower: CoolingTowerPerformance:YorkCalc (PerfCurves.idf), counterflow CTX Series C; water flow rate ratio = cell flow / VD-01 nominal flow (VD-01 1). Fan control per CondenserLoopTowers.cc calculateVariableSpeedTower: full speed when the setpoint cannot be met; free convection (air flow ratio 0.125, capacity fraction 0.125) when sufficient; cycling at 30 % speed (cycling ratio = (T_off - SP)/(T_off - T_min)); otherwise air flow ratio solved so the model approach equals SP - WB. Inlet WB clamped to the object limits. Bypass valve holds the supply at the setpoint, so the tower rejects the chiller condenser heat.
- Cell staging (DC-02 6.6): all cells unless per-cell flow < max(VD-01 minimum, 0.75 x nominal); fans of cells in service modulate together. Fan electric power = cells on x design bhp x 0.7457 / motor efficiency / VFD efficiency 0.97 x (air flow ratio)^3 (cycling: 0.3^3 x cycling ratio).
- Chillers: Chiller:Electric:EIR per ChillerElectricEIR.cc with the Chillers.idf curves named on M-601 (inputs clamped per CurveManager.cc); available capacity = reference capacity x CAPFT(CHWS, ECW); staging = smallest n with n x available capacity >= load, load split equally; condenser heat = Qevap + power + false load.
- Pumps: DC-02 6.4 head and efficiency; each running chiller runs its dedicated constant-speed pump at GPMTOTAL/N.
- Setpoint: SP = max(CWSMIN, WB + CWSOFFSET, chiller minimum ECW) (DC-02 6.7, RFI-031 Response 2). Chiller ECW = tower supply temperature.
- Design point (DC-02 6.9): 80 F WB, design block load, all chillers at GPMTOTAL, the cells in service under the DC-02 6.6 staging rule (all installed cells for these designs) at full speed; DesignPoint sheet reports the achieved CWS/CWR/range/approach; CWSDESIGN on the schedule is conservative (rounded up).
- Redundancy (DC-02 6.3): design load, GPMTOTAL through the remaining cells (cells - 1) at full speed at 81 F (evaluated at the 80 F clamp); the chillers' available capacity at the resulting ECW is reported as RedundancyCapacity_tons. As a check the approach was also added to the unclamped 81 F wet bulb; both cases meet the load below the 95 F machine maximum.
- EVAPORATION FORMULATION: SATURATED-EXIT (EnergyPlus calculateWaterUsage moist-air method; water density per DC-02 7) is used for the water balance, the allocation, peak-day and discharge checks, and (per EC-01 6) the priced water quantities. Drift = design flow x cells on/cells x certified drift x air flow ratio (VD-04). Blowdown = E/(COC-1) - drift; makeup = E + drift + blowdown (UFM 3-230-13 5-2.1.1, 5-2.1.3).
- Peak day (PW-LTR-014 2): 24 h at 80 F WB, the M-603 highest tabulated DB (112 F) and the design block load, plant controlled as scheduled.
- Chemistry (WT-01 2, 4, 4.1; UFM 3-230-13 Appendix A, 5-3.2.5): analysis of record 2022-07-26 (Ca 109 mg/L -> CaH 272.2 ppm as CaCO3; TDS 1720 mg/L ROE; SiO2 16.0 mg/L); circulating M-alkalinity 120 ppm; PSI = 2pHs - pHeq with pHs = 9.30 + A + B - (C + D), A = (log TDS - 1)/10, C = log CaH - 0.4, D = log 120, B by linear interpolation of Table A-2 at the design-point CWR the cells achieve, pHeq = 1.485 log TA + 4.54. Allowable COC = min(PSI >= 5.60 limit, silica 150/16.0 = 9.375). The scheduled COC is the allowable value at the achieved design CWR written to two decimals (CUP 4.1424 -> 4.14, ANNEX 4.0012 -> 4.00, LAB 3.8796 -> 3.88, i.e. rounded to the nearest 0.01).
- Life-cycle cost (EC-01, 10 CFR 436): base date 1 Oct 2025, DOE real rate 3.0 %, 1-yr construction, 25-yr service (longest admissible life: stainless), study period 26 yr. UPV* electricity (West/Mountain/Commercial) = 16.306097 - 0.970874 = 15.3352; non-fuel UPV (3 %) = 16.9060; water UPV* at real escalation 1.035/1.015 - 1 = 1.9704 % = 21.7770. Energy cost = kWh x 0.0712 + peak kW x 17.80 x 12. Water = makeup x 1.94 + blowdown x 3.20 per kgal; O&M = makeup x 0.42 per kgal + cells x routine maintenance. Investment = cells x (base x (1 + material adder) + eliminator + premium motor + 0.85 x operating weight + 14,000) + 60,000.

## 5. Selections

- CUP: 4 x CTX-0600-S, SS-304, DE-2, premium 91.7 % 20 hp motor, GPMTOTAL 1800.4 gpm (450.1 gpm/cell; 900.2 gpm per chiller), cells in service at design 4, CWS reset floor 65.5 F / offset 11.5 F, COC 4.14 (allowable 4.1424), scheduled CWSDESIGN 86.0 F (achieved 85.36 F), design range 12.66 F, CWR 98.02 F, redundancy capacity 918 tons at 87.86 F ECW. NS = 245745 USD; peak demand 515.1 kW (MCC spare 528.00 kW); annual makeup 9565 kgal (allocation 10300 kgal); peak-day makeup 49035 gal; peak-day blowdown 11816 gal.
- ANNEX: 4 x CTX-0600-S, SS-304, DE-2, premium 91.7 % 20 hp motor, GPMTOTAL 1800.4 gpm (450.1 gpm/cell; 900.2 gpm per chiller), cells in service at design 4, CWS reset floor 79.4 F / offset 11.51 F, COC 4.00 (allowable 4.0012), scheduled CWSDESIGN 86.5 F (achieved 85.70 F), design range 13.68 F, CWR 99.38 F, redundancy capacity 946 tons at 88.34 F ECW. NS = 261868 USD; peak demand 570.8 kW (MCC spare 590.00 kW); annual makeup 12588 kgal (allocation 12600 kgal); peak-day makeup 52960 gal; peak-day blowdown 13210 gal.
- LAB: 3 x CTX-0900-H, SS-304, DE-2, premium 91.7 % 20 hp motor, GPMTOTAL 2025.3 gpm (675.1 gpm/cell; 675.1 gpm per chiller), cells in service at design 3, CWS reset floor 57.4 F / offset 8.75 F, COC 3.88 (allowable 3.8796), scheduled CWSDESIGN 86.5 F (achieved 85.99 F), design range 14.60 F, CWR 100.58 F, redundancy capacity 1234 tons at 90.18 F ECW. NS = 297182 USD; peak demand 634.1 kW (MCC spare 641.14 kW); annual makeup 16944 kgal (allocation 17400 kgal); peak-day makeup 73477 gal; peak-day blowdown 18894 gal.

Selection reasoning: galvanized G-235 is prohibited (P100 5.3.3.11); SS-304 has the lowest life-cycle cost of the compliant materials (SS-316 costs more for the same life; FRP-PV is cheaper first but its 20-yr life forces a replacement in year 21). DE-1 (0.005 %) violates 23 65 00 2.3; DE-2 beats DE-3 (lower drift only shifts blowdown). Economy motors fall below 10 CFR 431.25(h) Table 5. CTX-1800-S exceeds 102 dB. Redundancy (gpm/(cells-1) <= VD-01 maximum) together with the VD-01/WFRR minimum, VD-03 per-machine flows, the 6-7 ft VD-01 clearances, the M-401 Rev C zones and the S-401 framing zones/allowable loads leave 4-cell CTX-0600-S or CTX-0900-S plants for CUP/ANNEX and 3-cell CTX-0900-S/H plants for LAB; the LCC analysis selects the lowest condenser flow the cell minimum allows (pump energy), and the reset that maximises NS within the MCC and water limits.

## 6. Governing constraints (DC-02 9)

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0245)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0010)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0110)

- CUP margins: water allocation 0.0714; electrical capacity 0.0245; roof area 0.1351; structural capacity 0.0250; condenser flow limit 0.2003; tower capability 0.1063
- ANNEX margins: water allocation 0.0010; electrical capacity 0.0326; roof area 0.1351; structural capacity 0.0565; condenser flow limit 0.2003; tower capability 0.1238
- LAB margins: water allocation 0.0262; electrical capacity 0.0110; roof area 0.0693; structural capacity 0.0162; condenser flow limit 0.2690; tower capability 0.0789

Margin definitions per DC-02 9: roof area uses (frame + 2 x clearance) per cell against the Rev C zone area; structural uses operating weight / frame area against the S-401 zone allowable; condenser flow limit uses the scheduled per-cell (GPMTOTAL/CELLS) and per-machine (GPMTOTAL/N) flows against the VD-01 and VD-03 limits; tower capability uses the scheduled APPROACHDESIGN against the recomputed design approach.

## 7. Margins and judgement calls

- GPMTOTAL is set just above the effective minimum per-cell flow (WFRR 0.75) so that partial-flow staging stays inside the validity envelope; this is the cost-optimal flow because pump energy dominates.
- COC is scheduled at the WT-01 allowable value at the achieved design CWR, written to two decimals; the PSI at the scheduled COC is reported as ScalingIndexAtCWR (5.60 to two decimals). Silica (9.375) does not control.
- The ANNEX plant is limited by its amended reclaimed-water allocation; its CWS floor is raised to limit fan-driven (adiabatic) evaporation in dry weather.
- CWSDESIGN is scheduled conservatively above the achieved design-point supply temperature; the achieved value is reported on the DesignPoint sheet.
- BASINCLR is scheduled at the P100 minimum of 4.0 ft; dunnage is hot-dip galvanised (not a water-contact surface, 23 65 00 2.2).
- Cells are placed with their frames inside single S-401 framing zones (0.5 ft off the zone line where adjacent), VD-01 clearances to each other and to the M-401 Rev C zone boundary, and more than 25 ft from every Rev C outdoor air intake.
