# Design Basis - EOR Review Corrections, Work Order 74213 (BP-2 and BP-3)

Prepared by the Designer of Record's document controller (Calder Ridge Engineering) for the Contracting Officer, NAVFAC Pacific (Code ACQ42). Covers both bid packages of Fleet Data Center Increment 2, Naval Support Activity Ventura Bay.

```json
{
 "packages": {
  "BP-2": {
   "issue_state": "AMENDMENT",
   "change_number": "0003",
   "overflow_option": 2,
   "revision_layers": [
    "Z-ANNO-REVC",
    "Z-ANNO-REVS"
   ],
   "n_bundles": 3,
   "production_days": 14,
   "delay_days": 1,
   "backcheck_window_days": 15,
   "ledger": {
    "bundles_usd": 14400,
    "sheets_usd": 18528.64,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 3600,
    "overflow_option_usd": 1760,
    "non_concurrence_usd": 2400,
    "delay_usd": 2740,
    "total_usd": 56228.64
   },
   "title_block_defects": [
    {
     "sheet": "S-301",
     "defect": "CHK_EQUALS_DRW"
    },
    {
     "sheet": "E-501",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    }
   ]
  },
  "BP-3": {
   "issue_state": "PRE_ADVERTISEMENT_REISSUE",
   "change_number": "",
   "overflow_option": "NONE",
   "revision_layers": [],
   "n_bundles": 2,
   "production_days": 11,
   "delay_days": 0,
   "backcheck_window_days": 30,
   "ledger": {
    "bundles_usd": 9600,
    "sheets_usd": 20053.04,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 0,
    "overflow_option_usd": 0,
    "non_concurrence_usd": 2400,
    "delay_usd": 0,
    "total_usd": 44853.04
   },
   "title_block_defects": [
    {
     "sheet": "A-501",
     "defect": "CHK_EQUALS_DES"
    },
    {
     "sheet": "M-101",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    }
   ]
  }
 },
 "governing_standards": [
  "FC 1-300-09N Navy and Marine Corps Design Procedures, 17 May 2024, with Change 1 dated 17 April 2025",
  "ERDC/ITL SR-24-3 A/E/C Computer-Aided Design (CAD) Standard, Release 6.2",
  "ERDC/ITL SR-23-1 A/E/C Graphics Standard, Release 2.2",
  "ER 1165-2-217 Civil Works Review Policy, 1 May 2021 (adopted by the Contracting Officer memorandum of 26 August 2026, paragraph 7, for the review comment, response, closure and location conventions only)",
  "ERDC/ITL SR-21-6 Record Package Guidance: Best Practices, August 2021 (adopted by the same memorandum for the markup colour convention only)",
  "ER 415-1-11 Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews, 1 January 2013 (the review regulation for comment-resolution and backcheck timing)",
  "48 CFR 52.236-25 Requirements for Registration of Designers (JUN 2003), FAR clause in the design contract"
 ],
 "rejected_standards": [
  "ERDC/ITL TR-12-6 A/E/C CAD Standard, Release 6.0 - superseded release; Release 6.2 (SR-24-3) is the current release in the folder",
  "UFC 1-300-09N Design Procedures (2005) with Change 7 - cancelled and replaced; FC 1-300-09N (2024, Change 1) is the current NAVFAC design procedures criteria",
  "GSA PBS CAD Standards (10 March 2021, owner legacy) - another agency's (GSA Public Buildings Service) owner standard; does not govern a NAVFAC solicitation",
  "ER 1110-1-8159 DrChecks (1 January 2015) - USACE command policy on the DrChecks system; not adopted by the Contracting Officer and sets no requirement applied to this issue (DrChecks use follows FC 1-300-09N paragraph 3-1.3)"
 ],
 "rate_parameters": {
  "production_start": "2026-08-31",
  "sheets_per_day": 4,
  "days_per_bundle": 3
 },
 "void_markups": [
  {
   "comment_id": "EOR-2-015",
   "reason": "Author M. Delacroix is registered in electrical engineering only (roster CA PE E-30877); the markup is on mechanical sheet M-301 (chilled water plant section), a field the reviewer is not registered in, so it cannot direct a mechanical design change."
  },
  {
   "comment_id": "EOR-2-017",
   "reason": "Author G. Halvorsen does not appear on the reviewer roster; no role, registration or discipline can be established for the markup, so it carries no review authority."
  },
  {
   "comment_id": "EOR-2-019",
   "reason": "The annotation on S-501 carries no creation or modification timestamp, so it cannot be shown to have been made within the EOR review period and is not a traceable review markup."
  },
  {
   "comment_id": "EOR-2-021",
   "reason": "Markup is drawn on the superseded 90 percent submittal print of S-102 (pre-renumbering), not on the current advertised issue against which changes are made."
  },
  {
   "comment_id": "EOR-2-027",
   "reason": "Author K. Aoyama is a construction representative with no professional registration (roster registration fields blank); an unregistered reviewer cannot direct a change to the design."
  },
  {
   "comment_id": "EOR-3-012",
   "reason": "Markup is drawn on the superseded 60 percent submittal print of T-501 (pre-renumbering), not on the current certified issue against which changes are made."
  },
  {
   "comment_id": "EOR-3-016",
   "reason": "Author M. Delacroix is registered in electrical engineering only; the markup is on architectural sheet A-501 (wall sections and details), a field the reviewer is not registered in, so it cannot direct the change."
  },
  {
   "comment_id": "EOR-3-018",
   "reason": "Author P. Okonjo is registered in civil engineering only; the markup is on architectural sheet A-502 (roof drain detail), outside the reviewer registration field, so it cannot direct the change."
  },
  {
   "comment_id": "EOR-3-020",
   "reason": "The annotation on S-501 carries no creation or modification timestamp, so it cannot be shown to have been made within the EOR review period and is not a traceable review markup."
  },
  {
   "comment_id": "EOR-3-022",
   "reason": "Author C. Ballantyne does not appear on the reviewer roster; no role, registration or discipline can be established for the markup, so it carries no review authority."
  }
 ]
}
```

## 1. Basis documents and how they were chosen

Governing: FC 1-300-09N (Change 1 of the May 2024 edition) is the NAVFAC design procedures criteria; its paragraph 12-3.3.4 names the latest DoD A/E/C CAD and Graphics Standards as the CAD standards that apply below its own Chapter 12, so the current releases in the folder - A/E/C CAD Standard Release 6.2 (SR-24-3, which states that it supersedes Release 6.1) and A/E/C Graphics Standard Release 2.2 (SR-23-1) - govern sheet identification, sheet order, revision marks and the Revision (Issue) block. ER 1165-2-217 and ERDC/ITL SR-21-6 apply only to the extent the Contracting Officer memorandum of 26 August 2026 (paragraph 7) adopted them: the four-part comment, the concur/non-concur response with every affected location, the elevated-closure convention, and the red/green/blue markup colours. ER 415-1-11 is the review regulation the memorandum (paragraph 3) points to for when comments must be resolved and when the backcheck runs. FAR clause 52.236-25 (with FC 1-300-09N paragraphs 2-5, 3-1.5 and 12-4.1) sets who may sign, seal, review and approve each discipline's work.

Not governing: A/E/C CAD Standard Release 6.0 (superseded release), the cancelled 2005 edition of UFC 1-300-09N (Change 7), the GSA PBS CAD Standards (another agency's owner standard), ER 1110-1-8159 (USACE system policy, not adopted). Reference-only material: the superseded 90% / 60% prints and the 90% index export (pre-renumbering), the FY23 record drawings (another contract), and the fire protection comment log (separate A-E task order, outside BP-2/BP-3 scope). Where the BP-3 advertisement date differs between the solicitation schedule export (2026-10-12) and the later Contracting Officer memorandum (9 November 2026), the memorandum controls.

## 2. Narrative (a) - revision-graphics layer conflict

The two shipped standards point the revision graphics at different layers. The A/E/C CAD Standard Release 6.2 general layer table (Appendix A, General, referenced from section 4.2.1) lists G-ANNO-REVC for revision clouds and G-ANNO-REVS for revision indicators and text; the current BP-2 sheet files carry those two layers. FC 1-300-09N paragraph 12-3.6.1 puts revision clouds on Z-ANNO-REVC and puts revision symbols, notes and the entries made in each sheet's revision block on Z-ANNO-REVS.

The clause that fixes the order of precedence is FC 1-300-09N paragraph 12-3.3.4 (CAD Standards), which ranks "the requirements of this Chapter" first, then "the latest versions" of the DoD A/E/C CAD and Graphics Standards, and the National CAD Standard last. Paragraph 12-3.6.1 is a Chapter 12 requirement, so it outranks the A/E/C CAD Standard layer table, and generic practice (re-using the G-ANNO revision layers already in the files) is not followed.

Layers actually used for the BP-2 Amendment 0003 graphics: Z-ANNO-REVC for every revision cloud and Z-ANNO-REVS for every triangle-3 revision indicator and for the new Revision (Issue) block entry (row placement explained under narrative (c) below). The G-ANNO-REVC and G-ANNO-REVS layers are left untouched. BP-3 is re-issued before advertisement, so it carries no clouds, indicators or new block entries and no revision layer is populated (revision_layers is empty for BP-3).

## 3. Narrative (b) - BP-3 issue state and the review window

Dates read from the contract documents: solicitation N40085-26-R-3018 is not advertised; the schedule export gives an advertisement of 2026-10-12, but the later Contracting Officer memorandum of 26 August 2026 (paragraph 3) schedules advertisement for 9 November 2026 and controls. Bid opening stays 2026-11-12 (schedule export; the memorandum does not move it). Production may start 2026-08-31 (memorandum paragraph 5; rate schedule).

The review regulation, ER 415-1-11 paragraph 6, gives two durations for the backcheck: under subparagraph g the backcheck is to begin "30 calendar days prior to advertising", with every comment resolved before bid opening; subparagraph e(4) allows "about 15 calendar days" for back-checking comments. Which one binds depends on the issue state:

* Pre-advertisement re-issue (memorandum course a): the corrections are incorporated in the design before the solicitation is advertised, so the corrected package must be complete when the backcheck starts, 30 calendar days before 2026-11-09, i.e. by 2026-10-10. The 30-day window binds; the 15-day window is irrelevant because no bid opening is pending against an issued solicitation.
* Amendment (memorandum course b): the advertisement goes out on 2026-11-09 and the corrections follow as Amendment 0001; then only the bid opening constrains the change, and the roughly 15-day backcheck must be finished before bid opening, so production would have to finish by 2026-10-28.

Decision: BP-3 is issued as a PRE_ADVERTISEMENT_REISSUE. Window applied: 30 calendar days (backcheck_window_days = 30), from subparagraph g, rather than the 15-day back-checking allowance of subparagraph e(4): in the pre-advertisement state the corrections must be in the design before the backcheck starts, and the backcheck must start 30 calendar days ahead of the 9 November 2026 advertisement; the 15-day allowance only controls a change issued against a pending bid opening, which does not exist until the solicitation is advertised. BP-3 production is 11 days (16 sheets at 4 per day = 4 days, 2 bundles at 3 days, 1 non-concurrence at 1 day), finishing 2026-09-11 against the 2026-10-10 deadline: D = 0, no extension cost, and the 9 November advertisement date does not move. The amendment course would meet its own deadline too but would add 14 revision marks ($3,360) and Revision (Issue) block overflow on A-001, A-101 and A-301 (cheapest option $1,560), i.e. $4,920 more, plus a change number, continuation sheet and amendment processing during a three-day advertisement window. Recommendation to the Contracting Officer: course a - incorporate the corrections in the design before advertisement; because production ends well inside the window, the 9 November 2026 advertisement does not have to be held. BP-3 total: $44,853.04. No change number is assigned and no continuation sheet is submitted (memorandum paragraph 2); added sheets take their proper numbers before advertisement (A/E/C CAD Standard section 2.4.4.1).

BP-2 has only one lawful state. Solicitation N40085-26-R-2041 was advertised on 2026-07-06, so any change before award is an amendment (FC 1-300-09N paragraph 18-1; A/E/C Graphics Standard section 7.1; A/E/C CAD Standard section 2.4.4.1). Two amendments are issued, so the Contracting Officer's next number in the criteria's four-digit form is 0003 (FC 1-300-09N paragraph 18-3; memorandum paragraph 1). The binding window is the 15-day backcheck ahead of the 2026-09-28 bid opening (ER 415-1-11 paragraph 6), giving a production deadline of 2026-09-13 (backcheck_window_days = 15).

## 4. Narrative (c) - BP-2 Revision (Issue) block overflow

Row capacity: the Revision (Issue) block "provides eight rows" (A/E/C Graphics Standard section 7.3; the first entry goes on the lowest line and later entries above it). Six BP-2 sheets in this issue already have all eight rows filled (A to F plus amendments 1 and 2): C-101, M-101, M-501, S-101, S-102, S-502. Mark 3 cannot fit on them without an overflow option.

Option taken: Option 2 (continue the new entry directly above the eighth row, ROW_POSITION 9), applied set-wide. Section 7.3 states that the chosen option "shall remain consistent across the entire drawing set", so the choice is made once for the whole BP-2 set, not sheet by sheet: every BP-2 sheet in the issue is recorded with OVERFLOW_OPTION 2; the six full sheets carry their mark-3 entry in row 9, the seven other replaced sheets take their next free row, and the two added sheets start on row 1.

Cost reason Option 1 was rejected: under the published rates Option 1 (replace the oldest entry and copy it outside the plotted area) costs $520 on each full sheet, 6 x $520 = $3,120. Option 2 costs $880 only on full sheets carrying three or more drawing blocks - M-501, S-502 (3 and 4 blocks) - because the other full sheets (C-101, M-101, S-101, S-102) each carry a single drawing block and leave the spill area unoccupied at no cost: 2 x $880 = $1,760. Option 1, although labelled preferred, would cost $1,360 more, so Option 2 is used.

## 5. Which markups cannot drive a change (void grounds)

Grounds worked out from the corpus and applied to every markup (10 void, 5 per package):

1. Markup drawn on a superseded submittal print: the drawings README states the 90%/60% prints predate the renumbering and are not the issue any change is made against (EOR-2-021 on the 90% S-102 print; EOR-3-012 on the 60% T-501 print).
2. Author absent from the reviewer roster: no role or registration can be traced (EOR-2-017 G. Halvorsen; EOR-3-022 C. Ballantyne). ER 1165-2-217 paragraph 5.8.1 relies on each reviewer entering his or her own comments for traceability.
3. Annotation with no timestamp: the markup cannot be placed inside the review period (comments entered 2026-08-11 to 2026-08-19, review closed 2026-08-24 per the review checklists), so it is not a traceable review markup (EOR-2-019 and EOR-3-020, both on S-501).
4. Reviewer not registered in the field of the work marked: FAR 52.236-25 and FC 1-300-09N paragraphs 2-5 and 3-1.5 reserve review and approval of each discipline's design to a professional registered in that field (EOR-2-015 and EOR-3-016, electrical reviewer on a mechanical and an architectural sheet; EOR-3-018, civil EOR on an architectural detail).
5. Author holds no professional registration at all (EOR-2-027, construction representative K. Aoyama).

Each void markup is closed in the disposition register with CLOSURE = VOID and its ground. The yellow "CHECKED - NO COMMENT" notes by K. Aoyama carry no comment number and no requested change; they are not review comments. Markup colours follow SR-21-6: green = addition, red = deletion, blue = clarification (CHANGE_KIND).

## 6. Disposition of the surviving comments

Directive comments (criteria, Design Analysis, coordination or dimensional basis) are incorporated: BP-2 EOR-2-001, -004, -006, -009, -023, -025; BP-3 EOR-3-002, -004, -006, -008, -010, -014, -024, -026. Preferential comments (reviewer opinion, "consider") are not directive under ER 1165-2-217 paragraph 5.8.5 and were priced both ways ($2,400 plus one production day for a documented non-concurrence against re-issue, markup-extent, mark and dependent-sheet charges):

* Incorporated because cheaper: EOR-2-013 (E-001, $1,728), EOR-2-029 (E-101 already re-issued, $249.60), EOR-2-031 (M-301 view 2, $1,556.40), EOR-3-028 (A-201, $1,378.80), EOR-3-032 (M-301, $1,344.48), EOR-3-034 (T-501, $1,321.60).
* Non-concurrence documented: EOR-2-011 (would re-issue C-501 and C-301, $2,956.80, and adds a production day through the sheet count) and EOR-3-030 (would re-issue S-301 and S-102 and push the second BP-3 bundle over 50 MB, forcing a third file). Each response gives the technical justification required by FC 1-300-09N paragraph 3-1.4 and is routed for reviewer backcheck.
* EOR-2-033 and EOR-3-036 were closed in the 60% review as elevated for resolution (ER 1165-2-217 paragraph 5.9.1.2) and that closure was not reopened; they are recorded as CLOSED_ELEVATED with no change.

### Disposition summary

| Comment | Validity | Response | Closure | Sheets changed | Sheets re-issued by reference |
|---|---|---|---|---|---|
| EOR-2-001 | VALID | CONCUR | INCORPORATED | S-101 | - |
| EOR-2-004 | VALID | CONCUR | INCORPORATED | S-502 | E-101;E-501;M-101;M-401;M-501;M-502;S-102;S-301 |
| EOR-2-006 | VALID | CONCUR | INCORPORATED | M-101 | - |
| EOR-2-009 | VALID | CONCUR | INCORPORATED | C-101 | - |
| EOR-2-011 | VALID | NON_CONCUR | NON_CONCUR_DOCUMENTED | - | - |
| EOR-2-013 | VALID | CONCUR | INCORPORATED | E-001 | - |
| EOR-2-015 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-2-017 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-2-019 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-2-021 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-2-023 | VALID | CONCUR | INCORPORATED | M-401;M-503 | E-101;M-101 |
| EOR-2-025 | VALID | CONCUR | INCORPORATED | S-101;S-202 | - |
| EOR-2-027 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-2-029 | VALID | CONCUR | INCORPORATED | E-101 | - |
| EOR-2-031 | VALID | CONCUR | INCORPORATED | M-301 | - |
| EOR-2-033 | VALID | NOT_APPLICABLE | CLOSED_ELEVATED | - | - |
| EOR-3-002 | VALID | CONCUR | INCORPORATED | A-501 | A-101;A-301 |
| EOR-3-004 | VALID | CONCUR | INCORPORATED | S-501 | A-101;A-301;A-501;E-102;E-501;S-101 |
| EOR-3-006 | VALID | CONCUR | INCORPORATED | A-502 | A-102 |
| EOR-3-008 | VALID | CONCUR | INCORPORATED | M-101 | - |
| EOR-3-010 | VALID | CONCUR | INCORPORATED | E-501 | E-102 |
| EOR-3-012 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-3-014 | VALID | CONCUR | INCORPORATED | A-001 | - |
| EOR-3-016 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-3-018 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-3-020 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-3-022 | VOID | NOT_APPLICABLE | VOID | - | - |
| EOR-3-024 | VALID | CONCUR | INCORPORATED | A-101;A-402 | - |
| EOR-3-026 | VALID | CONCUR | INCORPORATED | M-101;M-502 | - |
| EOR-3-028 | VALID | CONCUR | INCORPORATED | A-201 | A-101 |
| EOR-3-030 | VALID | NON_CONCUR | NON_CONCUR_DOCUMENTED | - | - |
| EOR-3-032 | VALID | CONCUR | INCORPORATED | M-301 | M-101 |
| EOR-3-034 | VALID | CONCUR | INCORPORATED | T-501 | - |
| EOR-3-036 | VALID | NOT_APPLICABLE | CLOSED_ELEVATED | - | - |

## 7. Reference sweep

The reference graph was read from the callout bubbles drawn inside each drawing block (README: a bubble belongs to its block). A change to a view re-issues every sheet whose block calls it out, transitively and across disciplines. BP-2: deleting the cast-in anchor in A/S-502 reaches A/E-501, A/M-501, A/M-502 and 2/S-301, then 1/E-101, 1/M-101, 1/M-401 and 1/S-102; the new callout in 1/M-401 reaches 1/M-101 and 1/E-101. BP-3: the base plate change in A/S-501 reaches A/A-501, A/E-501 and 1/S-101, then 1/A-101, 1/A-301 and 1/E-102; A/A-501 reaches 1/A-101 and 1/A-301; A/A-502 reaches 1/A-102; A/E-501 reaches 1/E-102; 1/A-201 reaches 1/A-101; 1/M-301 reaches 1/M-101. Sheets whose callouts point only at untouched blocks (for example M-301 block 1 calling C/M-501, or S-501 block C) are not re-issued.

Issue sets: BP-2 15 sheets (C-101, E-001, E-101, E-501, M-101, M-301, M-401, M-501, M-502, M-503, S-101, S-102, S-202, S-301, S-502); BP-3 16 sheets (A-001, A-101, A-102, A-201, A-301, A-402, A-501, A-502, E-102, E-501, M-101, M-301, M-502, S-101, S-501, T-501).

## 8. Added sheets and callout coupling

Added sheets take the next free sequence number in the sheet-type series that matches the callout that will point at them (A/E/C CAD Standard section 2.4.4 and Table 2-4: 2 = elevations, 4 = large-scale views, 5 = details). The A/E/C Graphics Standard couples each callout symbol to a sheet type: an elevation indicator must point to an XX2NN sheet (section 4.2.4.2), a section indicator to an XX3NN sheet (section 4.2.4.3), and a detail indicator to an XX5NN sheet, or to an XX4NN sheet for an enlarged area (section 4.2.4.4). Every existing callout on the current sheets already obeys this coupling. None is inserted between two consecutive existing sheets, so no supplemental letter designator (section 2.4.4.1) is needed, and existing sheet numbers are not changed (FC 1-300-09N paragraph 18-5.1):

* BP-2 S-202 BRACED BAY FRAMING ELEVATIONS - elevation callout from 1/S-101 (after S-201).
* BP-2 M-503 CHILLER PAD ANCHORAGE DETAILS - detail callout from 1/M-401 (after M-502).
* BP-3 A-402 TELECOM ENTRANCE ROOM ENLARGED PLAN - enlarged-plan callout from 1/A-101 (after A-401).
* BP-3 M-502 CONTAINMENT WALL DUCT PENETRATION DETAILS - detail callout from 1/M-101 (after M-501).

The sample numbers in FC 1-300-09N Figure 18-1 are illustrations only and were not copied. NAVFAC drawing numbers for the added sheets come from the reserve requested under FC 1-300-09N paragraph 7-4.

## 9. Sheet index order

Per A/E/C CAD Standard section 2.4.4.2 and Table 2-3, disciplines run G-, GI, C-, S-, A-, M-, E-, T-, and within each discipline the general notes, abbreviations and legend sheets come before all other sheets (so GI-002 precedes GI-001, M-003 precedes M-001, E-004 precedes E-001 and A-002 precedes A-001); the authoring tool's alphabetical SORT_ORDER is not used.

## 10. Revision marks and block entries (BP-2)

Amendment changes are clouded and flagged with an equilateral triangle holding the sequential amendment number 3 (A/E/C Graphics Standard sections 7.2 and 7.3; FC 1-300-09N paragraph 18-5.1). Every sheet issued with the amendment receives the same brief entry "REVISED IN ACCORDANCE WITH AMDT 0003" dated "SEP 2026" (MMM YYYY), the month the amendment is released. The added sheets S-202 and M-503 carry that mark-3 entry on the lowest row of their empty blocks and a triangle 3 beside the sheet title (no cloud, the whole sheet being new), matching the revision number shown for them in Document 00 01 15.

## 11. Title blocks of the re-issued sheets

Checked against FC 1-300-09N paragraph 12-4.1 (CHK initials must differ from DES and DRW; the seal must be that of the discipline responsible for the sheet) and paragraph 2-5:

* BP-2 S-301: drawn by RCM and checked by RCM - CHK_EQUALS_DRW.
* BP-2 E-501: electrical details sheet sealed "REGISTERED PROFESSIONAL - MECHANICAL" - SEAL_DISCIPLINE_MISMATCH.
* BP-3 A-501: designed by HGB and checked by HGB - CHK_EQUALS_DES.
* BP-3 M-101: mechanical CRAH plan sealed "REGISTERED PROFESSIONAL - ELECTRICAL" - SEAL_DISCIPLINE_MISMATCH.

These four are corrected (new checker / correct discipline seal) before the sheets are signed. For information only, C-102 (BP-2, CHK = DES) and T-101 (BP-3, CHK = DRW) have the same kind of defect but are not part of this issue.

The PPI/RFI log (PPI-2-001 to PPI-2-003, RFI-3-001) was also checked under FC 1-300-09N paragraphs 18-1 and 18-2: every response is marked as needing no amendment, so no PPI or RFI change is folded into this issue. A detailed construction cost estimate accompanies Amendment 0003 (paragraph 18-4).

## 12. Packaging and schedule

Each delivered PDF is held to 50 MB and 50 sheets (FC 1-300-09N paragraph 12-3.5.1) and complete discipline sets are kept together (paragraph 12-3.5.2.1); plot sizes are the PLOT_PDF_MB values of the sheet-index exports, 5.5 MB for an added sheet.

* BP-2 (116.9 MB, so at least three files): 74213Amend0003dwg1of3.pdf = C + E (32.6 MB); 74213Amend0003dwg2of3.pdf = S (38.3 MB); 74213Amend0003dwg3of3.pdf = M (46.0 MB). Continuation sheet 74213Amend0003.pdf (FC 1-300-09N paragraph 12-3.5.6 and Figure 12-5 multi-file suffix).
* BP-3 (89.5 MB): 74213dwg1of2.pdf = S + M + E + T (45.7 MB); 74213dwg2of2.pdf = A (43.8 MB).

Production days = ceiling(sheets / 4) + 3 per bundle + 1 per non-concurrence, starting 2026-08-31:

* BP-2: ceiling(15/4) = 4, plus 3 x 3 = 9, plus 1 = 14 days; finish 2026-09-14 against the 2026-09-13 deadline: D = 1, extension $2,600 x 1 + $140 x 1 = $2,740. Fourteen days is the floor for BP-2: three files are unavoidable, and incorporating EOR-2-011 instead of non-concurring would raise the sheet count to 17 (5 days) for the same 14-day total at higher cost.
* BP-3: ceiling(16/4) = 4, plus 2 x 3 = 6, plus 1 = 11 days; finish 2026-09-11 against 2026-10-10: D = 0.

## 13. Cost ledgers (published rates)

| Line | BP-2 | BP-3 |
|---|---|---|
| Bundles ($4,800 each) | $14,400.00 | $9,600.00 |
| Sheets ($1,150 per re-issued existing sheet + $26/sq in of incorporated markup) | $18,528.64 (13 sheets + 137.64 sq in) | $20,053.04 (14 sheets + 152.04 sq in) |
| Added sheets ($6,400 each) | $12,800.00 | $12,800.00 |
| Revision marks ($240 per sheet carrying mark 3) | $3,600.00 | $0.00 |
| Overflow option | $1,760.00 (Option 2) | $0.00 |
| Non-concurrence ($2,400 each) | $2,400.00 | $2,400.00 |
| Solicitation extension | $2,740.00 (D = 1) | $0.00 (D = 0) |
| Total | $56,228.64 | $44,853.04 |

Markup extent is measured from each incorporated annotation's drawn rectangle or polygon (inside the border allowance), in square inches at full ANSI D size.
