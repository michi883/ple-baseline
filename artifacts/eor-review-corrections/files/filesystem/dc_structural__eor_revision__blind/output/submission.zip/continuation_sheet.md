# CONTINUATION SHEET - AMENDMENT 0003

Solicitation N40085-26-R-2041 - BP-2 Central Utility Plant and Site Utilities
eProjects Work Order 74213 - Fleet Data Center Increment 2 - Naval Support Activity Ventura Bay, California
Continuation sheet file: 74213Amend0003.pdf. Attached drawings (one drawing attachment split only to respect the 50 MB file limit, complete discipline sets per file, each sheet bookmarked): 74213Amend0003dwg1of3.pdf (C-101, E-001, E-101, E-501), 74213Amend0003dwg2of3.pdf (S-101, S-102, S-202, S-301, S-502), 74213Amend0003dwg3of3.pdf (M-101, M-301, M-401, M-501, M-502, M-503).
Prepared by the Designer of Record for the Contracting Officer, Code ACQ42; SF 30 block 14: "EOR design review corrections - drawings replaced and added; see continuation sheet." A detailed construction cost estimate of the change accompanies this amendment as a separate file (FC 1-300-09N paragraph 18-4). The PPI/RFI log was checked: none of its responses requires an amendment, so nothing from it is folded into Amendment 0003.

DRAWINGS:

                On NAVFAC Drawing No. 74213-GI001 (GI-001)

ADD the following drawings to the DRAWING INDEX, each filed under its own discipline and sheet number. Both drawings are attached to Amendment 0003:

S-202 74213-S202 BRACED BAY FRAMING ELEVATIONS - ADDED SHEET

M-503 74213-M503 CHILLER PAD ANCHORAGE DETAILS - ADDED SHEET

REPLACE the following drawings in the DRAWING INDEX at their existing discipline and sheet number positions. Each replacement drawing is attached to Amendment 0003:

C-101 74213-C101 SITE UTILITY PLAN - REPLACED SHEET

S-101 74213-S101 CUP FOUNDATION PLAN - REPLACED SHEET

S-102 74213-S102 CUP ROOF FRAMING PLAN - REPLACED SHEET

S-301 74213-S301 CUP BUILDING SECTIONS - REPLACED SHEET

S-502 74213-S502 FRAMING DETAILS - REPLACED SHEET

M-101 74213-M101 CUP CHILLED WATER PLAN - REPLACED SHEET

M-301 74213-M301 CHILLED WATER PLANT SECTIONS - REPLACED SHEET

M-401 74213-M401 CHILLER BAY ENLARGED PLAN - REPLACED SHEET

M-501 74213-M501 PIPING DETAILS - REPLACED SHEET

M-502 74213-M502 EQUIPMENT ANCHORAGE DETAILS - REPLACED SHEET

E-001 74213-E001 ELECTRICAL PANEL SCHEDULES - REPLACED SHEET

E-101 74213-E101 CUP POWER PLAN - REPLACED SHEET

E-501 74213-E501 ELECTRICAL DETAILS - REPLACED SHEET

Each replaced drawing shows its changes inside revision clouds flagged with triangle 3; every replaced and added drawing carries the entry "3 / REVISED IN ACCORDANCE WITH AMDT 0003 / SEP 2026" in its Revision (Issue) block. Sheet numbers are unchanged. No change is made by narrative only.

SPECIFICATIONS:

PROJECT TABLE OF CONTENTS
No specification section is added or replaced by this Amendment.

DOCUMENT 00 01 15 LIST OF DRAWINGS
1.2 Contract Drawings
ADD the following drawings. They are attached to this Amendment.

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
|---|---|---|---|
| S-202 | 3 | 74213-S202 | BRACED BAY FRAMING ELEVATIONS |
| M-503 | 3 | 74213-M503 | CHILLER PAD ANCHORAGE DETAILS |

DELETE and REPLACE the following drawings as of 14 September 2026. The replacement drawings are attached to this Amendment.

| DRAWING NO. | REVISION NO. | NAVFAC DWG NO. | TITLE |
|---|---|---|---|
| C-101 | 3 | 74213-C101 | SITE UTILITY PLAN |
| S-101 | 3 | 74213-S101 | CUP FOUNDATION PLAN |
| S-102 | 3 | 74213-S102 | CUP ROOF FRAMING PLAN |
| S-301 | 3 | 74213-S301 | CUP BUILDING SECTIONS |
| S-502 | 3 | 74213-S502 | FRAMING DETAILS |
| M-101 | 3 | 74213-M101 | CUP CHILLED WATER PLAN |
| M-301 | 3 | 74213-M301 | CHILLED WATER PLANT SECTIONS |
| M-401 | 3 | 74213-M401 | CHILLER BAY ENLARGED PLAN |
| M-501 | 3 | 74213-M501 | PIPING DETAILS |
| M-502 | 3 | 74213-M502 | EQUIPMENT ANCHORAGE DETAILS |
| E-001 | 3 | 74213-E001 | ELECTRICAL PANEL SCHEDULES |
| E-101 | 3 | 74213-E101 | CUP POWER PLAN |
| E-501 | 3 | 74213-E501 | ELECTRICAL DETAILS |

--End of Amendment--

---

# BP-3 - DATA HALL 210 SHELL AND INTERIORS (Solicitation N40085-26-R-3018)

No continuation sheet is submitted for BP-3. Its EOR review corrections are incorporated in the design before the solicitation is advertised (pre-advertisement re-issue, Contracting Officer memorandum of 26 August 2026, paragraphs 2 and 3, course a), so they are not a change to a solicitation: no amendment number is assigned, no revision clouds, triangles or Revision (Issue) block entries are made, and the corrected sheets (including added sheets A-402 and M-502) are delivered as 74213dwg1of2.pdf and 74213dwg2of2.pdf for advertisement on 9 November 2026.
