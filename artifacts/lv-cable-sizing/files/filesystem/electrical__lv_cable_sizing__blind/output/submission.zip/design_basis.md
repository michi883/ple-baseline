```json
{
 "project": "P-4210, Building 4210 Consolidated Support Facility, NSA Whitmore Ridge",
 "sheet": "E-621 Low-voltage wire schedule",
 "codes_of_record": {
  "nfpa70_edition": 2023,
  "ibc_edition": 2024,
  "adopted_by": "UFC 1-200-01 DoD Building Code (1 September 2022, Change 4 of 17 December 2024) - adopts the IBC 2024 and directs NFPA 70 references to UFC 3-501-01, which cites NFPA 70",
  "precedence": "Where two documents set different limits for the same thing, the most restrictive requirement governs (EDS-26 Rev 4 para 1.1; G-001 order of precedence); where EDS-26 is silent the UFC governs",
  "codes_fixed": "14 July 2025 (start of design, sheet G-001)",
  "criteria": [
   "UFC 1-200-01 (Chg 4, 17 Dec 2024)",
   "UFC 3-501-01 (27 Nov 2024)",
   "UFC 3-520-01 (16 Jan 2025)",
   "NFPA 70 (NEC) 2023",
   "IBC 2024",
   "UFC 1-200-02 / ASHRAE 90.1 (energy)",
   "EDS-26 Rev 4 (12 Jun 2026)"
  ],
  "not_used": [
   "EDS-26 Rev 2 (superseded)",
   "E-601 Rev A one-line (superseded)",
   "Meridian Cable datasheet (not the basis of design)"
  ]
 },
 "environment": {
  "outdoor_design_dry_bulb_c": 42,
  "roof_ambient_c": 46,
  "earth_ambient_c": 27.45,
  "soil_thermal_resistivity_k_m_w": 0.6,
  "solar_irradiance_w_m2": 1030,
  "encasement_thermal_resistivity_k_m_w": 0.55,
  "native_soil_resistivity_rejected_k_m_w": 0.95,
  "interior_ambients_c": {
   "ceiling cavity / E-611, E-612, E-616 circuits": 40,
   "mechanical room 121 / fire pump room 105 circuits (F-01, F-03, B-11..B-15)": 45,
   "Building 4212 shop": 40
  }
 },
 "sources": {
  "outdoor_design_dry_bulb_c": "NOAA 1991-2020 daily normals, USW00003145 (site/NOAA_daily_normals_1991-2020_USW00003145.csv): max DLY-TMAX-NORMAL 106.8 F = 41.56 C rounded up (EDS-26 Rev 4 para 5.4)",
  "roof_ambient_c": "EDS-26 Rev 4 para 5.4: outdoor design dry-bulb + 4 K (confirmed by M-501-C)",
  "earth_ambient_c": "NOAA station record: annual mean DLY-TAVG-NORMAL 76.00 F = 24.45 C + 3 K (EDS-26 Rev 4 para 5.3.2); GEO-4210-T ground logs not used (para 2.4)",
  "soil_thermal_resistivity_k_m_w": "GEO-4210-T para 2.2 thermal backfill 0.60 K.m/W (native SP-SM 0.95 K.m/W of para 2.1 rejected - trench fully backfilled with thermal backfill)",
  "encasement_thermal_resistivity_k_m_w": "GEO-4210-T para 2.3 (0.55 K.m/W)",
  "solar_irradiance_w_m2": "EDS-26 Rev 4 para 5.4 (S = 1030 W/m2, alpha_s = 0.6)",
  "interior_ambients_c": "M-501-C ambient temperature coordination memorandum (2 June 2026)"
 },
 "voltage_drop": {
  "start_point": "T-1 secondary lugs - point of government ownership (WRPU-2026-0412; UFC 3-501-01 3-2.7.4.2), nominal 480 V assumed there",
  "transformer_reset": false,
  "transformer_reset_basis": "UFC 3-501-01 3-2.7 restarts the count only where the voltage is raised above 1000 V; 3-2.7.4.5.3 zero drop through transformers - the percentage at K-13 primary and at the DP-3 transformer section carries to the secondary",
  "feeder_chain_pct": {
   "MSB-1": 1.043,
   "MCC-1": 2.575,
   "DP-2": 1.406,
   "K-13": 1.546,
   "LP-1": 2.747,
   "DP-3": 2.581,
   "ATS-1": 2.777
  },
  "feeder_chain_paths": {
   "MSB-1": "SE-1",
   "MCC-1": "SE-1 + F-01",
   "DP-2": "SE-1 + F-02",
   "K-13": "SE-1 + F-02 + F-06",
   "LP-1": "SE-1 + F-02 + F-06 + F-07",
   "DP-3": "SE-1 + F-05",
   "ATS-1": "SE-1 + F-10"
  },
  "feeder_chain_max_pct": 2.777,
  "feeder_limit_pct": 3.0,
  "branch_limit_pct": 3.0,
  "total_limit_pct": 5.0,
  "fire_pump_limits_pct": {
   "locked_rotor": 15.0,
   "running": 5.0,
   "achieved_locked_rotor": 2.713,
   "achieved_running": 1.339
  },
  "service_entrance_vd_load_a": 1600,
  "branch_circuits_inheriting_upstream_budget": 18,
  "branch_circuits_downstream_of_a_transformer": 13
 },
 "service_entrance": {
  "design_current_a": 2000,
  "basis": "MSB-1 main bus 2000 A (UFC 3-501-01 3-2.3.3; EDS-26 2.2), not the 1600 A main device",
  "selection": "6 sets 500 kcmil CU XHHW-2, 4/0 CU EGC per duct, DB-1"
 },
 "cost": {
  "conductor_usd": 93220.94,
  "conductor_gross_usd": 99171.21,
  "termination_usd": 9777.7,
  "raceway_usd": 48366.6,
  "material_usd": 97081.25,
  "labor_usd": 54283.99,
  "total_usd": 151365.24,
  "quantity_break_applied": true,
  "total_conductor_ft": 41136
 },
 "duct_assignment": {
  "SE-1": [
   "D1",
   "D2",
   "D5",
   "D6",
   "D9",
   "D10"
  ],
  "F-10": [
   "D4",
   "D8"
  ],
  "F-05": [
   "E1",
   "E2",
   "E3"
  ]
 },
 "mutual_heating_rise_k": 31.09,
 "mutual_heating_rise_by_duct_k": {
  "D1": 25.64,
  "D2": 27.08,
  "D4": 21.34,
  "D5": 29.62,
  "D6": 31.09,
  "D8": 23.53,
  "D9": 27.88,
  "D10": 29.03,
  "E1": 1.54,
  "E2": 1.42,
  "E3": 1.45
 },
 "distinct_large_sizes": [
  "4/0",
  "300 kcmil",
  "500 kcmil",
  "600 kcmil"
 ]
}
```

# Design basis - Low-voltage wire schedule, sheet E-621
Project P-4210, Building 4210 Consolidated Support Facility, Naval Support Activity Whitmore Ridge

## 1. Codes of record, adopting document and precedence

The codes of record were fixed at the start of design (14 July 2025) and are listed on sheet G-001. The design was prepared against:

* **UFC 1-200-01, DoD Building Code** (1 September 2022, Change 4 of 17 December 2024) - **the adopting document**. It adopts the **International Building Code, 2024 edition**, and directs every IBC reference to NFPA 70 to UFC 3-501-01, which cites NFPA 70.
* **NFPA 70, National Electrical Code, 2023 edition** - the edition in effect at the start of design (cited by name and article; not reproduced in the project record).
* **UFC 3-501-01 Electrical Engineering** (27 November 2024) and **UFC 3-520-01 Interior Electrical Systems** (16 January 2025) - Department requirements.
* **UFC 1-200-02** (energy, citing ASHRAE 90.1).
* **NSA Whitmore Ridge EDS-26 Electrical Design Standard, Rev 4** (12 June 2026) - installation requirements. Rev 4 supersedes Rev 2 in its entirety; Rev 2 (7 distinct sizes, 4 sets, 5 ft allowances, 20 C earth, 2 %/3 % drop at connected load) was **not used**. E-601 Rev A (superseded one-line) was **not used**; loads and device ratings are from E-601 Rev C and the connected load schedule. The Meridian Cable datasheet is not the basis of design and its ampacities were not used; the data of record is Cascadia Engineering Data Section 4, issue 2026-1 (Section 26 05 19 para 1.3).

**Order of precedence:** where two of these documents set different limits for the same thing, the **most restrictive requirement governs** (EDS-26 para 1.1, G-001); where EDS-26 is silent, the UFC governs. Example applied: NFPA 70 treats voltage drop only in informational notes; UFC 3-501-01 3-2.7 makes 3 %/3 %/5 % mandatory, so the UFC limits were applied.

## 2. Environmental parameters and provenance

| Parameter | Value | Source |
|---|---|---|
| Outdoor design dry-bulb | 42 C | NOAA 1991-2020 normals USW00003145: highest DLY-TMAX-NORMAL 106.8 F = 41.56 C, rounded up (EDS-26 5.4) |
| Roof ambient (tray CT-R1) | 46 C | 42 C + 4 K (EDS-26 5.4); agrees with M-501-C |
| Earth ambient at duct-bank depth | 27.45 C | annual mean DLY-TAVG-NORMAL 76.00 F = 24.45 C + 3 K (EDS-26 5.3.2). GEO-4210-T ground logs (22.1-28.4 C, Apr-Jun) not used (para 2.4) |
| Earth (backfill) thermal resistivity | 0.60 K.m/W | GEO-4210-T 2.2 - both banks are encased and surrounded full width by fluidised thermal backfill (also E-619 note) |
| Native soil resistivity (rejected) | 0.95 K.m/W | GEO-4210-T 2.1 - considered and rejected: the native soil does not enter the earth or mutual-heating terms |
| Encasement concrete resistivity | 0.55 K.m/W | GEO-4210-T 2.3 |
| Solar irradiance / absorptivity | 1030 W/m2 / 0.6 | EDS-26 5.4 (tray in open air on the roof) |
| Interior ambients | 40 C ceiling cavity (all E-611/E-612/E-616 circuits incl. F-02, F-06, F-07, F-09, F-11 and the DP-3 branches); 45 C for F-01, F-03 and B-11..B-15 | M-501-C (highest ambient on the route, UFC 3-520-01 3-6.3.2); all above the 25 C floor |
| Load factor | 100 % | UFC 3-501-01 3-2.3.3, applied to every duct-bank circuit (EDS-26 5.3) |

## 3. Ampacity basis

Every ampacity is **calculated under engineering supervision as permitted by NFPA 70 (2023) 310.14(B)** (EDS-26 5.1); NFPA 70 tables are not the basis of design. Raceway: 90 C raceway column of Cascadia table 4.2/4.3 x k_a = sqrt((90-Ta)/60) (k_g = 1, three or two current-carrying conductors per raceway; no 120 V neutrals in scope). Tray CT-R1: EDS-26 5.4 heat balance with Rth = 1/(pi De h), h = 14, solar rise alpha_s S De Rth = 14.05 K, k_t = 1 + 0.06 (N-3) with N = 18 (six three-phase sets in the tray). Duct banks: EDS-26 5.3 simplified Neher-McGrath, Tc = 90 C, rho_i 3.5, rho_pvc 6.0, air space 0.40, rho_e 0.60, rho_c 0.55, L to bank centre, Db = sqrt(4WH/pi), mutual heating from every loaded duct at connected load / sets, LF = 1.0. Every corrected ampacity is then limited to the termination column (EDS-26 5.5): 60 C where the device is 100 A or less or the lugs are 60 C (LP-1, WH-1, DW-1, SEC-1, lighting and receptacle outlets - so F-07 is held to the 60 C column), 75 C otherwise; raceway table for duct banks, free-air table for the tray. Where the printed table and the vendor heat balance differ by rounding, the lower value was used for feasibility and the higher value to establish the size "ampacity alone would give" for EGC scaling (both conservative).

Design currents: feeders 125 % of continuous load but not less than the device (EDS-26 2.1, the device governs for F-01, F-02, F-05, F-10); lighting, receptacle and hard-wired branch circuits not less than the branch device; motor, A/C, ASD, elevator, fire-pump and transformer circuits 125 % of FLA / RLA / maximum input / rated transformer current with the device **not** a floor (EDS-26 2.1.1). The 15 % spare capacity of UFC 3-520-01 3-2.1 / UFC 3-501-01 3-2.3.3 is confirmed on every bus (e.g. MSB-1 1732 A x 1.15 = 1992 A <= 2000 A bus; MCC-1 523 A <= 600 A; DP-2 340 A <= 400 A; DP-3 323 A <= 400 A; LP-1 719 A <= 800 A; ATS-1 497 A <= 600 A).

## 4. Service-entrance sizing decision

SE-1 is sized for a continuous current of **2000 A, the ampacity of the MSB-1 main bus**, not the 1600 A main device and not the 1732 A connected load (UFC 3-501-01 3-2.3.3; EDS-26 2.2); this also covers the 15 % spare-capacity demand (1732 A x 1.15 = 1992 A). Terminals at T-1 and MSB-1 accept six sets of up to 600 kcmil and EDS-26 3.4.4 allows six sets, so at least 333.3 A per set is needed. In DB-1 (Neher-McGrath, 100 % load factor, backfill 0.60 K.m/W, earth 27.45 C) aluminium 600 kcmil reaches only 278 A per set and 6 x 400 kcmil CU 323 A, so both were rejected; five sets would need 600 kcmil CU (412.8 A against 400 A). **Six sets of 500 kcmil CU XHHW-2** were selected - 348.1 A per set in the worst duct (D6) against 333.3 A, 75 C raceway limit 403 A - because, with F-10 in the same bank, this pair (6 x 500 CU + 2 x 500 AL) is the cheapest compliant combination for the bank and its downstream voltage-drop budget. Each SE-1 duct carries a 4/0 CU conductor sized from NFPA 70 Table 250.122 on the 1600 A main device (EDS-26 5.7), priced and counted as an EGC. For voltage drop the service-entrance load is taken as **1600 A, the rating of the service device** (UFC 3-501-01 3-2.7.4.3.1 reading, accepted by EDS-26 2.3 and stated on E-621); SE-1 spends 1.043 %.

## 5. Voltage-drop budget allocation

The calculation **starts at the T-1 secondary lugs**, the point of government ownership (WRPU-2026-0412; UFC 3-501-01 3-2.7.4.2), at nominal 480 V; transformer taps are not used (3-2.7.4.1, 3-2.7.4.5.3). Drops use Rac at 75 C and the reactance for steel raceway (interior) or non-metallic duct/tray, at the scheduled power factor, Vd = k I L (R cos phi + X sin phi)/sets (EDS-26 5.6). Loads: SE-1 1600 A; feeders the device rating (3-2.7.4.3.1); K-13 secondary 225 kVA nominal (624.5 A) and primary the same plus 6 % (286.9 A); motor, A/C, ASD and elevator feeders their FLA / RLA / maximum input current, counted as **branch circuits** for compliance (3-2.7.4.3.2 b-e); lighting the full connected load; receptacles 80 % of 20 A; hard-wired appliances their connected load; the fire pump to NFPA 70 Art 695 as adopted (15 % locked rotor, 5 % running, from T-1).

**The count does not restart at the low-voltage transformer.** UFC 3-501-01 3-2.7 restarts only where the voltage is raised above 1000 V and transformed back down; K-13 (480-208Y/120 V) and the DP-3 transformer section are both below 1000 V, and 3-2.7.4.5.3 carries the primary percentage to the secondary with zero drop through the transformer. Consequently **all 18 branch circuits (B-01..B-18) inherit the budget spent upstream of their panel**, 13 of them through a transformer (10 on LP-1 via K-13, 3 on DP-3 via its integral transformer).

Feeder chains (cumulative at the panel, limit 3 %): MSB-1 1.043 %; MCC-1 2.575 %; DP-2 1.406 %; K-13 1.546 %; LP-1 2.747 %; DP-3 2.581 %; ATS-1 2.777 %. Allocation logic: SE-1 is fixed by ampacity (1.04 %). On the LP-1 chain F-07 is fixed by ampacity at the 60 C lugs of LP-1 (3 x 500 kcmil AL, 1.20 %) and F-02/F-06 are short, so LP-1 sits at 2.75 % and every 208 V branch circuit may spend up to 2.25 %; buying that budget back upstream (copper F-07) costs more than the copper added to the long lighting/receptacle branches, so the long branches (B-01..B-08) were upsized to #8 or #6 and the short ones were not. On the MCC-1 chain the 480 V motor branches are short and stay below 1 %. On the DP-3 chain the binding load is CMP-1 (B-17): 125 % FLA forces #6 CU and CMP-1 accepts nothing larger, so B-17 spends 2.347 % and **MSB-1 + F-05 must not exceed 2.65 %** - F-05 (716 ft) was therefore upsized for voltage drop to 3 x 600 kcmil AL (1.538 %, DP-3 at 2.581 %, CMP-1 at 4.928 %). Fire pump: running 1.339 %, locked rotor 2.71 % (limits 5 % / 15 %). Highest totals at the load: B-17 4.928 %, B-06 4.841 %, B-09 4.832 %.

## 6. Duct-bank assignment and thermal consequence

DB-1 (service duct bank, 4 x 3 array of 5 in EPC-40) has 12 ducts; D11 (owner reserve) and D12 (existing site-lighting feeder) are reserved, so **10 ducts were available** to the two circuits of the bank. F-10 needs 2 (ATS-1 has 2 terminals per phase; 600 A device floor, 300 A per set), so **8 ducts were available to the service entrance**; SE-1 takes 6 (six terminals at T-1 and MSB-1, and the six-set limit of EDS-26 3.4.4), leaving two ducts empty. All 1260 placements of 6 + 2 sets in the 10 available ducts were evaluated and the one maximising the smaller of the two thermal margins was selected: **SE-1 in D1, D2, D5, D6, D9, D10** (the two west columns), **F-10 in D4 and D8** (east column, top and middle row, the ducts with the shortest heat path and farthest from the SE-1 group), and **D3 and D7 left empty** as a thermal buffer between the two circuits. The mutual-heating rise is 31.09 K in D6 (the governing SE-1 duct) and 21.3-29.6 K in the other loaded ducts (front sheet). The thermal consequence for the other circuit in the bank: the six SE-1 sets (1732 A connected, 288.7 A per set) raise the F-10 conductors by 23.5 K (D8) of the 62.6 K available, cutting the F-10 ampacity from 368 A per set (F-10 alone in the bank) to 302.2 A per set - below the 314 A 75 C limit of 500 kcmil AL, so for F-10 the duct bank and not the termination governs, with a 0.7 % margin over its 300 A per set requirement; 500 kcmil is the largest conductor ATS-1 accepts, so this placement (F-10 at the east edge, two empty buffer ducts) is what makes aluminium feasible for F-10. SE-1 in turn is held to 348.1 A per set in D6 by the combined heat of its own sets and F-10. DB-2: F-05 in E1, E2, E3 (E4 communications, left empty); with 94 A per set the mutual rise is about 1.5 K and the ampacity is held by the 75 C raceway limit (336 A per set).

## 7. Material and standardisation decisions

* Copper for every conductor #6 and smaller (UFC 3-520-01 3-6.3.1); aluminium (1350-H19, XHHW-2) used as the value-engineering option only at #4 and larger with AL/CU terminations (EDS-26 3.2): F-01 (500 kcmil), F-02 (300 kcmil), F-04 (4/0), F-05 (600 kcmil), F-07 (500 kcmil), F-08 (4/0), F-09 (300 kcmil), F-10 (500 kcmil), F-12 (4/0), F-13 (4/0). Copper is kept where it is cheaper or required: SE-1 (aluminium 600 kcmil cannot carry 333 A per set in DB-1), F-06 (standard-size set) and every circuit #1 AWG and smaller. EGCs are copper THHN/THWN-2.
* **Size standardisation (EDS-26 3.4.2): the limit is five distinct phase sizes larger than #1 AWG; this design uses four sizes** - 4/0, 300, 500 and 600 kcmil - which are also only five distinct size/material pairs (4/0 AL, 300 AL, 500 CU, 500 AL, 600 AL), so the limit is met on either reading. Project-level choices made for this reason rather than the circuit's own economics: F-06 uses 500 kcmil CU (400 kcmil CU would carry 338.75 A but is outside the standard set; its EGC is scaled by the 1.25 cmil ratio to #2), and F-02 uses 300 kcmil AL rather than 250 kcmil AL.
* F-02 (MSB-1 to DP-2) is 2 sets of 300 kcmil AL (230 A per set, 460 A): the 400 A device governs, but the selection also carries the DP-2 demand with the 15 % spare capacity of EDS-26 2.4 at 125 % (296 A x 1.15 x 1.25 = 425.5 A), which a single 500 kcmil CU (403 A) would not - chosen for that project reason at +$0.3 k.
* Roof tray: F-04 and F-12 two sets each and F-08, F-13 one set each of 4/0 AL - N = 18 current-carrying conductors (k_t = 1.90), ampacity 171.9 A per set against 155 A / 151.25 A; tray fill 12.21 in (phase + EGC) against 16.2 in.
* Parallel sets: none below 1/0, none above six, never more than the terminals provided; each set in its own raceway or duct.
* Minimum conductor #12 (B-10). No conductor exceeds the largest size its terminals accept, so no termination reductions (UFC 3-520-01 3-6.3.2) are needed.
* EGC: NFPA 70 Table 250.122 on the device rating, increased in the circular-mil ratio wherever the phase conductor exceeds the size ampacity alone would give (250.122(B); UFC 3-501-01 3-2.7; EDS-26 5.7) - e.g. F-05 3 x 250 kcmil CU (ratio 4.51), B-02/B-06 #6, B-08 #4.
* Raceway: rigid steel conduit at the Cascadia reference trade size for the conductor (EDS-26 6.1), checked for 40 % fill and the 2.8-3.2 jam band; never reduced below the reference size.

## 8. Cost ledger

Unit prices: Cascadia Wire price list 2026 (conductor and terminations, per set per end) and the P-4210 unit price book 2026 (rigid steel conduit per set over the circuit length); duct banks and tray are existing (no cost). Total conductor installed is 41,136 ft (phase + EGC), above the 38,000 ft threshold, so the **campus quantity break (-6 % on conductor material and labour)** is applied as its own ledger line.

| Item | Material USD | Labour USD | Installed USD |
|---|---|---|---|
| Conductor (phase + EGC), gross | 74,608.35 | 24,562.86 | 99,171.21 |
| Campus quantity break -6 % | -4,476.50 | -1,473.77 | -5,950.27 |
| Terminations | 5,192.92 | 4,584.78 | 9,777.70 |
| Rigid steel conduit | 21,756.48 | 26,610.12 | 48,366.60 |
| **Total** | **97,081.25** | **54,283.99** | **151,365.24** |

Net conductor cost 93,220.94 USD; material 97,081.25 USD and labour 54,283.99 USD add to the installed total 151,365.24 USD (calc_book.xlsx, sheet cost_ledger).

## 9. Schedule summary

| Circuit | Phase conductors | EGC | Raceway / ducts | Design A | Ampacity A/set | VD % | Cum. VD % |
|---|---|---|---|---|---|---|---|
| B-01 | 1 x 8 CU | 8 | 1 | 20 | 39.9 | 1.885 | 4.632 |
| B-02 | 1 x 6 CU | 6 | 1.25 | 20 | 54 | 1.647 | 4.394 |
| B-03 | 1 x 8 CU | 8 | 1 | 20 | 39.9 | 2.002 | 4.749 |
| B-04 | 1 x 8 CU | 8 | 1 | 20 | 39.9 | 1.652 | 4.399 |
| B-05 | 1 x 8 CU | 8 | 1 | 20 | 39.9 | 1.675 | 4.422 |
| B-06 | 1 x 6 CU | 6 | 1.25 | 20 | 54 | 2.094 | 4.841 |
| B-07 | 1 x 6 CU | 6 | 1.25 | 40 | 54 | 1.930 | 4.677 |
| B-08 | 1 x 8 CU | 4 | 1 | 17.75 | 39.9 | 1.634 | 4.381 |
| B-09 | 1 x 4 CU | 10 | 1.5 | 60 | 73.6 | 2.085 | 4.832 |
| B-10 | 1 x 12 CU | 12 | 0.75 | 20 | 22 | 1.619 | 4.366 |
| B-11 | 1 x 4 CU | 6 | 1.5 | 81.25 | 85.7 | 0.526 | 3.101 |
| B-12 | 1 x 4 CU | 6 | 1.5 | 81.25 | 85.7 | 0.645 | 3.220 |
| B-13 | 1 x 6 CU | 8 | 1.25 | 50 | 54 | 0.303 | 2.878 |
| B-14 | 1 x 6 CU | 8 | 1.25 | 50 | 54 | 0.366 | 2.941 |
| B-15 | 1 x 4 CU | 8 | 1.5 | 65 | 73.6 | 0.937 | 3.512 |
| B-16 | 1 x 2 CU | 8 | 2 | 100 | 102 | 1.639 | 4.220 |
| B-17 | 1 x 6 CU | 10 | 1.25 | 43.25 | 54 | 2.347 | 4.928 |
| B-18 | 1 x 8 CU | 8 | 1 | 20 | 39.9 | 1.966 | 4.547 |
| F-01 | 2 x 500 kcmil AL | 1 | 4 | 600 | 306.6 | 1.532 | 2.575 |
| F-02 | 2 x 300 kcmil AL | 2 | 3 | 400 | 230 | 0.362 | 1.406 |
| F-03 | 1 x 1 CU | 4 | 2 | 120 | 134.2 | 0.295 | 1.339 |
| F-04 | 2 x 4/0 AL | 3 | tray | 310 | 171.9 | 1.247 | 2.290 |
| F-05 | 3 x 600 kcmil AL | 250 kcmil | E1;E2;E3 | 400 | 335.9 | 1.538 | 2.581 |
| F-06 | 1 x 500 kcmil CU | 2 | 4 | 338.75 | 403 | 0.140 | 1.546 |
| F-07 | 3 x 500 kcmil AL | 1/0 | 4 | 781.25 | 263 | 1.201 | 2.747 |
| F-08 | 1 x 4/0 AL | 6 | tray | 151.25 | 171.9 | 0.661 | 2.066 |
| F-09 | 1 x 300 kcmil AL | 4 | 3 | 211.25 | 230 | 0.969 | 2.374 |
| F-10 | 2 x 500 kcmil AL | 1 | D4;D8 | 600 | 302.2 | 1.734 | 2.777 |
| F-11 | 1 x 3 CU | 6 | 1.5 | 97.5 | 99 | 1.162 | 2.206 |
| F-12 | 2 x 4/0 AL | 3 | tray | 310 | 171.9 | 1.577 | 2.620 |
| F-13 | 1 x 4/0 AL | 6 | tray | 151.25 | 171.9 | 1.113 | 2.518 |
| SE-1 | 6 x 500 kcmil CU | 4/0 | D1;D2;D5;D6;D9;D10 | 2000 | 348.1 | 1.043 | 1.043 |
